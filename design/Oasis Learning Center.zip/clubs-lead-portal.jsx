// clubs-lead-portal.jsx — Clubs Lead portal
// A scoped staff role: only sees clubs they're assigned to, and within those
// can record Behaviour (Merit/Demerit/General), mark Attendance, and post
// Notices that appear in parents' My Clubs tab.

const CLUB_NAV = [
  { id:'overview',    label:'Overview',    icon:'M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6' },
  { id:'behaviour',   label:'Behaviour',   icon:'M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z' },
  { id:'attendance',  label:'Attendance',  icon:'M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4' },
  { id:'noticeboard', label:'Noticeboard', icon:'M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9' },
];

// Clubs Lead palette — distinct from navy (admin) and crimson (parent)
const CL = {
  forest:      '#0E5C3A',
  forestMid:   '#136846',
  forestLight: '#1A7A4A',
  forestSurface:'#E8F3EE',
  forestRim:   '#B7DCC7',
};

const CLNavIcon = ({ path, active }) => (
  <svg width={18} height={18} viewBox="0 0 24 24" fill="none" stroke={active?'#fff':'rgba(255,255,255,0.55)'} strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" style={{ flexShrink:0 }}>
    <path d={path} />
  </svg>
);

// ── Club Switcher ────────────────────────────────────────────────────────────
// Lets a clubs lead toggle between the clubs they've been assigned to.
const ClubSwitcher = ({ myClubs, activeId, onChange, mobile }) => (
  <div style={{ display:'flex', gap:8, flexWrap:'wrap', marginBottom: mobile ? 16 : 20 }}>
    {myClubs.map(c => {
      const active = c.id === activeId;
      return (
        <button key={c.id} onClick={()=>onChange(c.id)} style={{
          padding: mobile ? '10px 12px' : '11px 16px', borderRadius:12, cursor:'pointer', fontFamily:'inherit',
          background: active ? '#fff' : C.surface,
          border: `2px solid ${active ? c.accent : C.border}`,
          boxShadow: active ? `0 2px 0 ${c.accent}` : 'none',
          display:'flex', alignItems:'center', gap:10, transition:'all 0.15s',
        }}>
          <div style={{ width:32, height:32, borderRadius:9, background: active ? c.accent : C.bg, color: active ? '#fff' : c.accent, display:'flex', alignItems:'center', justifyContent:'center', fontSize:18 }}>{c.emoji}</div>
          <div style={{ textAlign:'left' }}>
            <p style={{ fontSize:13, fontWeight:700, color: active ? c.accent : C.navy, margin:0, lineHeight:1.1 }}>{c.name}</p>
            <p style={{ fontSize:11, color: C.textSecondary, margin:0, marginTop:2 }}>{c.day} · {c.memberIds.length} members</p>
          </div>
        </button>
      );
    })}
  </div>
);

// ── Clubs Lead Overview ──────────────────────────────────────────────────────
const ClubsLeadOverview = ({ mobile, activeClub, setPage }) => {
  const members = STUDENTS.filter(s => activeClub.memberIds.includes(s.id));
  const lastAtt = CLUB_ATTENDANCE[activeClub.id] || {};
  const present = Object.values(lastAtt.statuses || {}).filter(v => v === 'Present').length;
  const totalMarked = Object.keys(lastAtt.statuses || {}).length;
  const meritsThisTerm = CLUB_BEHAVIOUR_ENTRIES.filter(e => e.clubId === activeClub.id && e.type === 'Merit').reduce((a,b)=>a+b.delta,0);
  const demeritsThisTerm = CLUB_BEHAVIOUR_ENTRIES.filter(e => e.clubId === activeClub.id && e.type === 'Demerit').length;
  const noticesCount = CLUB_NOTICES.filter(n => n.clubId === activeClub.id).length;

  return (
    <div className="page-fade">
      {/* Hero */}
      <Card style={{ marginBottom:20, borderColor:'transparent', background:`linear-gradient(130deg, ${activeClub.accent} 0%, ${CL.forest} 100%)`, color:'#fff' }} padding={mobile?18:24}>
        <div style={{ display:'flex', alignItems:'center', gap:14, flexWrap:'wrap' }}>
          <div style={{ width:mobile?52:64, height:mobile?52:64, borderRadius:14, background:'rgba(255,255,255,0.18)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:mobile?28:34, flexShrink:0 }}>{activeClub.emoji}</div>
          <div style={{ flex:1, minWidth:0 }}>
            <p style={{ fontSize:11, color:'rgba(255,255,255,0.7)', fontWeight:700, letterSpacing:'0.6px', textTransform:'uppercase', margin:0 }}>You are the Clubs Lead for</p>
            <h2 style={{ fontSize:mobile?20:26, fontWeight:800, color:'#fff', margin:0, marginTop:2 }}>{activeClub.name}</h2>
            <p style={{ fontSize:13, color:'rgba(255,255,255,0.8)', marginTop:4 }}>{activeClub.day} · {activeClub.time} · {activeClub.room}</p>
          </div>
          <div style={{ textAlign:'right' }}>
            <p style={{ fontSize:11, color:'rgba(255,255,255,0.65)', margin:0 }}>Next session</p>
            <p style={{ fontSize:14, fontWeight:700, color:'#fff', margin:0, marginTop:2 }}>{activeClub.nextSession}</p>
          </div>
        </div>
      </Card>

      {/* Stat cards */}
      <div style={{ display:'grid', gridTemplateColumns: mobile?'1fr 1fr':'repeat(4,1fr)', gap:12, marginBottom:20 }}>
        <StatCard label="Members" value={members.length} sub={`${activeClub.capacity - members.length} spaces left`} accent={activeClub.accent} />
        <StatCard label={`Last session`} value={totalMarked ? `${present}/${totalMarked}` : '—'} sub={lastAtt.sessionLabel || 'Not yet marked'} accent={C.success} />
        <StatCard label="Merits awarded" value={`+${meritsThisTerm}`} sub={`${demeritsThisTerm} demerit${demeritsThisTerm===1?'':'s'} logged`} accent={C.blue} />
        <StatCard label="Notices live" value={noticesCount} sub="Visible to parents" accent={C.crimson} />
      </div>

      {/* Quick actions + members preview */}
      <div style={{ display:'grid', gridTemplateColumns: mobile?'1fr':'1.4fr 1fr', gap:16 }}>
        <Card>
          <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:14 }}>
            <p style={{ fontWeight:700, fontSize:14, color:C.navy }}>Members</p>
            <p style={{ fontSize:12, color:C.textMuted }}>{members.length} students</p>
          </div>
          <div style={{ display:'flex', flexDirection:'column', gap:6 }}>
            {members.map(s => {
              const last = CLUB_BEHAVIOUR_ENTRIES.filter(e => e.clubId===activeClub.id && e.studentId===s.id).slice(-1)[0];
              const status = (lastAtt.statuses||{})[s.id];
              return (
                <div key={s.id} style={{ display:'flex', alignItems:'center', gap:12, padding:'10px 12px', borderRadius:9, background:C.bg }}>
                  <Avatar initials={s.initials} size={32} color={s.color} />
                  <div style={{ flex:1, minWidth:0 }}>
                    <p style={{ fontSize:13, fontWeight:600, color:C.navy, margin:0 }}>{s.name}</p>
                    <p style={{ fontSize:11, color:C.textSecondary, margin:0, marginTop:1 }}>{s.year} · {last ? `Last: ${last.category}` : 'No entries yet'}</p>
                  </div>
                  {status && <Badge variant={status==='Present'?'green':status==='Late'?'amber':'red'}>{status}</Badge>}
                </div>
              );
            })}
          </div>
        </Card>

        <div style={{ display:'flex', flexDirection:'column', gap:16 }}>
          <Card>
            <p style={{ fontWeight:700, fontSize:14, color:C.navy, marginBottom:12 }}>Quick actions</p>
            <div style={{ display:'flex', flexDirection:'column', gap:8 }}>
              {[['Log a merit',   'behaviour',  C.success],
                ['Log a demerit', 'behaviour',  C.danger],
                ['Mark attendance','attendance',C.blue],
                ['Post a notice', 'noticeboard',C.crimson]].map(([l, p, col]) => (
                <button key={l} onClick={()=>setPage(p)} style={{ padding:'10px 14px', background:C.bg, borderRadius:9, fontSize:13, fontWeight:600, color:C.navy, cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'space-between', border:'none', fontFamily:'inherit' }}>
                  <span style={{ display:'flex', alignItems:'center', gap:10 }}>
                    <span style={{ width:6, height:6, borderRadius:'50%', background:col }} />
                    {l}
                  </span>
                  <span style={{ color:col, fontSize:16 }}>→</span>
                </button>
              ))}
            </div>
          </Card>

          <Card style={{ borderLeft:`4px solid ${activeClub.accent}` }}>
            <p style={{ fontSize:11, fontWeight:700, color:C.textSecondary, letterSpacing:'0.5px', textTransform:'uppercase', marginBottom:6 }}>Your access</p>
            <p style={{ fontSize:13, color:C.textPrimary, lineHeight:1.55 }}>
              You can record behaviour, mark attendance and post notices for <strong>{activeClub.name}</strong>.
              Other portal areas — fees, PACE, leaderboard, school-wide messages — are not part of your role.
            </p>
          </Card>
        </div>
      </div>
    </div>
  );
};

// ── Clubs Lead Behaviour ─────────────────────────────────────────────────────
const ClubsLeadBehaviour = ({ mobile, activeClub }) => {
  const [type, setType]           = React.useState('Merit');
  const [studentId, setStudentId] = React.useState(String(activeClub.memberIds[0]));
  const [category, setCategory]   = React.useState('Leadership');
  const [note, setNote]           = React.useState('');
  const [pointsDelta, setPoints]  = React.useState(5);
  const [pointsRaw, setPointsRaw] = React.useState('5'); // input string so user can clear/type freely
  const [justSaved, setJustSaved] = React.useState(false);

  // Re-pick a valid student when club changes
  React.useEffect(()=>{ setStudentId(String(activeClub.memberIds[0])); }, [activeClub.id]);

  const members = STUDENTS.filter(s => activeClub.memberIds.includes(s.id));
  const meritCategories = ['Leadership','Creativity','Teamwork','Sportsmanship','Character','Effort','Helpfulness'];
  const demeritCategories = ['Punctuality','Conduct','Disrespect','Negligence'];
  const generalCategories = ['Tournament','Casting','Role','Achievement','Note to file'];

  const categoriesFor = (t) => t==='Merit' ? meritCategories : t==='Demerit' ? demeritCategories : generalCategories;

  React.useEffect(()=>{
    setCategory(categoriesFor(type)[0]);
    if (type === 'General') { setPoints(0); setPointsRaw('0'); }
    else if (pointsDelta === 0) { setPoints(5); setPointsRaw('5'); }
  }, [type]);

  const applyPoints = (n) => {
    const clamped = Math.max(0, Math.min(100, n));
    setPoints(clamped);
    setPointsRaw(String(clamped));
  };

  const handleSave = () => {
    if (!note.trim()) return;
    setJustSaved(true);
    setTimeout(()=>setJustSaved(false), 2200);
    setNote('');
  };

  const recent = CLUB_BEHAVIOUR_ENTRIES.filter(e => e.clubId === activeClub.id).slice().reverse();

  const typeMeta = {
    Merit:   { bg:C.success, label:'Merit',   sign:'+', actionLabel:'merit' },
    Demerit: { bg:C.danger,  label:'Demerit', sign:'−', actionLabel:'demerit' },
    General: { bg:C.navy,    label:'General', sign:'',  actionLabel:'general note' },
  };
  const tm = typeMeta[type];

  return (
    <div className="page-fade">
      <div style={{ marginBottom:18 }}>
        <h2 style={{ fontSize:mobile?18:22, fontWeight:800, color:C.navy }}>Behaviour log</h2>
        <p style={{ fontSize:13, color:C.textSecondary, marginTop:2 }}>{activeClub.name} · {members.length} members in scope</p>
      </div>

      <div style={{ display:'grid', gridTemplateColumns: mobile?'1fr':'1fr 1.4fr', gap:16, alignItems:'start' }}>
        <Card>
          <p style={{ fontWeight:700, fontSize:14, color:C.navy, marginBottom:14 }}>Log new entry</p>

          {/* Type segmented */}
          <div style={{ display:'flex', background:C.bg, borderRadius:9, padding:4, marginBottom:14, gap:4 }}>
            {['Merit','Demerit','General'].map(t => (
              <button key={t} onClick={()=>setType(t)} style={{ flex:1, padding:'8px', borderRadius:7, border:'none', background:type===t?typeMeta[t].bg:'transparent', color:type===t?'#fff':C.textSecondary, fontWeight:700, fontSize:13, cursor:'pointer', fontFamily:'inherit', transition:'all 0.15s' }}>{t}</button>
            ))}
          </div>

          <Select label="Student" value={studentId} onChange={e=>setStudentId(e.target.value)} options={members.map(s=>({ value:String(s.id), label:s.name }))} style={{ marginBottom:12 }} />
          <Select label="Category" value={category} onChange={e=>setCategory(e.target.value)} options={categoriesFor(type).map(c=>({ value:c, label:c }))} style={{ marginBottom:12 }} />

          {/* Points — Merit / Demerit only. General is a note with no point change. */}
          {type !== 'General' && (
            <div style={{ marginBottom:12 }}>
              <div style={{ display:'flex', justifyContent:'space-between', alignItems:'baseline', marginBottom:6 }}>
                <label style={{ fontSize:12, fontWeight:600, color:C.textSecondary }}>Points</label>
                <span style={{ fontSize:11, color:C.textMuted }}>0–100</span>
              </div>
              <div style={{ display:'flex', gap:8, alignItems:'stretch' }}>
                {/* Stepper / numeric input */}
                <div style={{ display:'flex', flex:1, border:`1.5px solid ${C.border}`, borderRadius:8, overflow:'hidden', background:C.surface }}>
                  <button
                    type="button"
                    onClick={()=>applyPoints(pointsDelta - 1)}
                    style={{ width:36, border:'none', borderRight:`1px solid ${C.border}`, background:C.bg, color:C.navy, fontSize:18, fontWeight:700, cursor:'pointer', fontFamily:'inherit' }}
                    aria-label="decrease"
                  >−</button>
                  <div style={{ flex:1, display:'flex', alignItems:'center', justifyContent:'center', gap:4, padding:'0 8px' }}>
                    <span style={{ fontSize:18, fontWeight:800, color: type==='Merit' ? C.success : C.danger }}>{tm.sign}</span>
                    <input
                      type="number"
                      min={0} max={100}
                      value={pointsRaw}
                      onChange={e => {
                        setPointsRaw(e.target.value);
                        const n = parseInt(e.target.value, 10);
                        if (!isNaN(n)) setPoints(Math.max(0, Math.min(100, n)));
                        else setPoints(0);
                      }}
                      onBlur={() => {
                        const n = parseInt(pointsRaw, 10);
                        setPointsRaw(String(isNaN(n) ? 0 : Math.max(0, Math.min(100, n))));
                      }}
                      style={{
                        width:64, textAlign:'center', padding:'10px 0',
                        border:'none', outline:'none', background:'transparent',
                        fontSize:18, fontWeight:800,
                        color: type==='Merit' ? C.success : C.danger,
                        fontFamily:'inherit',
                      }}
                    />
                  </div>
                  <button
                    type="button"
                    onClick={()=>applyPoints(pointsDelta + 1)}
                    style={{ width:36, border:'none', borderLeft:`1px solid ${C.border}`, background:C.bg, color:C.navy, fontSize:18, fontWeight:700, cursor:'pointer', fontFamily:'inherit' }}
                    aria-label="increase"
                  >+</button>
                </div>
              </div>
              {/* Quick chips */}
              <div style={{ display:'flex', gap:6, marginTop:8, flexWrap:'wrap' }}>
                {[1,2,5,10,15,20].map(p => {
                  const active = pointsDelta === p;
                  return (
                    <button
                      key={p} type="button" onClick={()=>applyPoints(p)}
                      style={{
                        padding:'5px 11px', borderRadius:14,
                        border:`1.5px solid ${active ? tm.bg : C.border}`,
                        background: active ? (type==='Merit' ? C.successBg : C.dangerBg) : 'transparent',
                        color: active ? tm.bg : C.textSecondary,
                        fontWeight:700, fontSize:12, cursor:'pointer', fontFamily:'inherit',
                      }}
                    >{tm.sign}{p}</button>
                  );
                })}
              </div>
            </div>
          )}

          {type === 'General' && (
            <div style={{ marginBottom:12, padding:'10px 12px', background:C.bg, borderRadius:8, fontSize:12, color:C.textSecondary, lineHeight:1.5 }}>
              General notes don't change a student's merit balance — use them for tournament selections, casting, or things to flag for parents.
            </div>
          )}

          <div style={{ marginBottom:14 }}>
            <label style={{ fontSize:12, fontWeight:600, color:C.textSecondary, display:'block', marginBottom:5 }}>Notes</label>
            <textarea value={note} onChange={e=>setNote(e.target.value)} placeholder="What happened? Parents can see this." rows={3} style={{ width:'100%', padding:'9px 12px', border:`1.5px solid ${C.border}`, borderRadius:8, fontSize:13, fontFamily:'inherit', color:C.textPrimary, resize:'vertical', outline:'none' }} />
          </div>

          <Btn onClick={handleSave} variant={type==='Demerit'?'primary':type==='Merit'?'navy':'secondary'} style={{ width:'100%', justifyContent:'center', background: type==='Merit' ? C.success : type==='Demerit' ? C.crimson : C.navy, color:'#fff', border:'none' }}>
            Record {tm.actionLabel}
            {type !== 'General' && pointsDelta > 0 ? ` (${tm.sign}${pointsDelta} merit${pointsDelta===1?'':'s'})` : ''}
          </Btn>
          {justSaved && (
            <div style={{ marginTop:10, padding:'8px 12px', background:CL.forestSurface, border:`1px solid ${CL.forestRim}`, borderRadius:8, fontSize:12, fontWeight:600, color:CL.forest }}>
              ✓ Entry recorded — parents will be notified.
            </div>
          )}
        </Card>

        <div>
          <p style={{ fontWeight:700, fontSize:14, color:C.navy, marginBottom:12 }}>Recent entries · {activeClub.name}</p>
          <div style={{ display:'flex', flexDirection:'column', gap:10 }}>
            {recent.length === 0
              ? <Card><p style={{ fontSize:13, color:C.textMuted }}>No entries logged for this club yet.</p></Card>
              : recent.map(e => {
                const s = STUDENTS.find(s => s.id === e.studentId);
                const variant = e.type === 'Merit' ? 'green' : e.type === 'Demerit' ? 'red' : 'blue';
                return (
                  <Card key={e.id} padding={14}>
                    <div style={{ display:'flex', alignItems:'flex-start', gap:12 }}>
                      <Avatar initials={s?.initials} size={34} color={s?.color} />
                      <div style={{ flex:1, minWidth:0 }}>
                        <div style={{ display:'flex', gap:6, alignItems:'center', flexWrap:'wrap', marginBottom:4 }}>
                          <span style={{ fontWeight:700, fontSize:13, color:C.navy }}>{e.studentName}</span>
                          <Badge variant={variant}>
                            {e.type === 'General' ? 'General' : `${e.delta>0?'+':''}${e.delta} merits`}
                          </Badge>
                          <Badge variant="grey">{e.category}</Badge>
                        </div>
                        <p style={{ fontSize:12, color:C.textPrimary, lineHeight:1.55 }}>{e.note}</p>
                        <p style={{ fontSize:11, color:C.textMuted, marginTop:5 }}>by {e.recordedBy} · {e.time}</p>
                      </div>
                    </div>
                  </Card>
                );
              })
            }
          </div>
        </div>
      </div>
    </div>
  );
};

// ── Clubs Lead Attendance ────────────────────────────────────────────────────
const ClubsLeadAttendance = ({ mobile, activeClub }) => {
  const prior = CLUB_ATTENDANCE[activeClub.id] || { statuses:{}, sessionLabel:'New session', marked:false };
  const [att, setAtt] = React.useState({});
  const [saved, setSaved] = React.useState(false);
  React.useEffect(()=>{ setAtt({}); setSaved(false); }, [activeClub.id]);

  const mark = (id, status) => { setAtt(a => ({...a, [id]:status})); setSaved(false); };
  const markAllPresent = () => {
    const next = {};
    activeClub.memberIds.forEach(id => next[id]='Present');
    setAtt(next); setSaved(false);
  };
  const save = () => setSaved(true);

  const members = STUDENTS.filter(s => activeClub.memberIds.includes(s.id));
  const statuses = ['Present','Late','Absent'];
  const statusColor = { Present:C.success, Late:C.warning, Absent:C.danger };
  const statusBg    = { Present:C.successBg, Late:C.warningBg, Absent:C.dangerBg };
  const counts = { Present:0, Late:0, Absent:0, Unmarked:0 };
  members.forEach(s => { const v = att[s.id]; if (v) counts[v]++; else counts.Unmarked++; });

  // Generate a default session label for today
  const today = "Today's session";

  return (
    <div className="page-fade">
      <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:18, flexWrap:'wrap', gap:12 }}>
        <div>
          <h2 style={{ fontSize:mobile?18:22, fontWeight:800, color:C.navy }}>Mark attendance</h2>
          <p style={{ fontSize:13, color:C.textSecondary, marginTop:2 }}>{activeClub.name} · {today} · {members.length} students</p>
        </div>
        <div style={{ display:'flex', gap:8, alignItems:'center', flexWrap:'wrap' }}>
          {saved && <Badge variant="green">Saved ✓</Badge>}
          <Btn variant="secondary" size="sm" onClick={markAllPresent}>Mark all present</Btn>
          <Btn variant="primary" onClick={save}>Save register</Btn>
        </div>
      </div>

      {/* Counts bar */}
      <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:10, marginBottom:14 }}>
        {[['Present',counts.Present,C.success,C.successBg],['Late',counts.Late,C.warning,C.warningBg],['Absent',counts.Absent,C.danger,C.dangerBg],['Unmarked',counts.Unmarked,C.textSecondary,C.bg]].map(([l,v,col,bg])=>(
          <div key={l} style={{ background:bg, borderRadius:9, padding:'10px 4px', textAlign:'center' }}>
            <p style={{ fontSize:22, fontWeight:800, color:col, lineHeight:1 }}>{v}</p>
            <p style={{ fontSize:11, color:col, fontWeight:600, marginTop:4 }}>{l}</p>
          </div>
        ))}
      </div>

      <Card padding={0}>
        {members.map((s,i)=>{
          const current = att[s.id];
          return (
            <div key={s.id} style={{ display:'flex', alignItems:'center', gap:12, padding:'12px 16px', borderBottom:i<members.length-1?`1px solid ${C.border}`:'none', background: current==='Absent'?'#FFF8F8' : current==='Late'?'#FFFBF0':'' }}>
              <Avatar initials={s.initials} size={34} color={s.color} />
              <div style={{ flex:1, minWidth:0 }}>
                <p style={{ fontWeight:600, fontSize:13, color:C.navy }}>{s.name}</p>
                <p style={{ fontSize:11, color:C.textMuted }}>{s.year} · last session: {prior.statuses?.[s.id] || '—'}</p>
              </div>
              <div style={{ display:'flex', gap:6 }}>
                {statuses.map(st => (
                  <button key={st} onClick={()=>mark(s.id, st)} style={{
                    padding: mobile ? '6px 10px' : '7px 14px', borderRadius:7,
                    border:`1.5px solid ${current===st?statusColor[st]:C.border}`,
                    background:current===st?statusBg[st]:'transparent',
                    color:current===st?statusColor[st]:C.textSecondary,
                    fontWeight:700, fontSize:mobile?11:12, cursor:'pointer', fontFamily:'inherit',
                    transition:'all 0.1s',
                  }}>{mobile ? st.charAt(0) : st}</button>
                ))}
              </div>
            </div>
          );
        })}
      </Card>

      {/* Prior session info */}
      <Card style={{ marginTop:14 }}>
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', flexWrap:'wrap', gap:10 }}>
          <div>
            <p style={{ fontSize:12, fontWeight:700, color:C.textSecondary, textTransform:'uppercase', letterSpacing:'0.5px' }}>Previous session</p>
            <p style={{ fontSize:14, fontWeight:700, color:C.navy, marginTop:3 }}>{prior.sessionLabel}</p>
            <p style={{ fontSize:12, color:C.textSecondary, marginTop:2 }}>
              {Object.values(prior.statuses||{}).filter(v=>v==='Present').length} present · {Object.values(prior.statuses||{}).filter(v=>v==='Absent').length} absent · {Object.values(prior.statuses||{}).filter(v=>v==='Late').length} late
            </p>
          </div>
          <Badge variant={prior.marked?'green':'grey'}>{prior.marked ? 'Register filed' : 'Not filed'}</Badge>
        </div>
      </Card>
    </div>
  );
};

// ── Clubs Lead Noticeboard ───────────────────────────────────────────────────
const ClubsLeadNoticeboard = ({ mobile, activeClub }) => {
  const [title, setTitle] = React.useState('');
  const [body, setBody]   = React.useState('');
  const [pinned, setPinned] = React.useState(false);
  const [drafts, setDrafts] = React.useState([]); // locally-added notices, prepended on top
  const [posted, setPosted] = React.useState(false);

  React.useEffect(()=>{ setDrafts([]); setPosted(false); }, [activeClub.id]);

  const handlePost = () => {
    if (!title.trim() || !body.trim()) return;
    const newNotice = {
      id: Date.now(), clubId: activeClub.id, title:title.trim(), body:body.trim(),
      author: `${ME_CLUB_LEAD.firstName.charAt(0)}. ${ME_CLUB_LEAD.lastName}`,
      posted:'Just now', pinned, draft:true,
    };
    setDrafts(d => [newNotice, ...d]);
    setTitle(''); setBody(''); setPinned(false);
    setPosted(true);
    setTimeout(()=>setPosted(false), 2200);
  };

  const existing = CLUB_NOTICES.filter(n => n.clubId === activeClub.id);
  const allNotices = [...drafts, ...existing];
  // pinned first, then by id desc
  allNotices.sort((a,b)=> (b.pinned?1:0) - (a.pinned?1:0) || b.id - a.id);

  return (
    <div className="page-fade">
      <div style={{ marginBottom:18 }}>
        <h2 style={{ fontSize:mobile?18:22, fontWeight:800, color:C.navy }}>Noticeboard</h2>
        <p style={{ fontSize:13, color:C.textSecondary, marginTop:2 }}>{activeClub.name} · Posts appear in parents' <strong>My Clubs</strong> tab</p>
      </div>

      <div style={{ display:'grid', gridTemplateColumns: mobile?'1fr':'1fr 1.4fr', gap:16, alignItems:'start' }}>
        <Card>
          <p style={{ fontWeight:700, fontSize:14, color:C.navy, marginBottom:14 }}>Post a notice</p>
          <Input label="Title" value={title} onChange={e=>setTitle(e.target.value)} placeholder="e.g. Costume request for showcase" style={{ marginBottom:12 }} />
          <div style={{ marginBottom:12 }}>
            <label style={{ fontSize:12, fontWeight:600, color:C.textSecondary, display:'block', marginBottom:5 }}>Message</label>
            <textarea value={body} onChange={e=>setBody(e.target.value)} placeholder="What do parents need to know?" rows={5} style={{ width:'100%', padding:'10px 12px', border:`1.5px solid ${C.border}`, borderRadius:8, fontSize:13, fontFamily:'inherit', resize:'vertical', outline:'none' }} />
          </div>
          {/* Pin toggle */}
          <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', padding:'10px 12px', background:C.bg, borderRadius:8, marginBottom:14 }}>
            <div>
              <p style={{ fontSize:12, fontWeight:600, color:C.navy }}>Pin to top</p>
              <p style={{ fontSize:11, color:C.textMuted, marginTop:2 }}>Pinned notices show first for parents.</p>
            </div>
            <button onClick={()=>setPinned(p=>!p)} style={{ width:40, height:22, borderRadius:11, border:'none', background:pinned?C.success:C.border, position:'relative', cursor:'pointer', flexShrink:0 }}>
              <div style={{ width:16, height:16, borderRadius:'50%', background:'#fff', position:'absolute', top:3, left:pinned?21:3, transition:'left 0.15s' }} />
            </button>
          </div>
          {/* Audience preview */}
          <div style={{ display:'flex', alignItems:'center', gap:8, padding:'10px 12px', background:CL.forestSurface, border:`1px solid ${CL.forestRim}`, borderRadius:8, marginBottom:14 }}>
            <span style={{ fontSize:14 }}>👥</span>
            <p style={{ fontSize:12, color:CL.forest, lineHeight:1.45 }}>
              Sent to <strong>{activeClub.memberIds.length} parent accounts</strong> linked to {activeClub.name} members.
            </p>
          </div>
          <Btn variant="primary" onClick={handlePost} style={{ width:'100%', justifyContent:'center' }} disabled={!title.trim() || !body.trim()}>Post notice</Btn>
          {posted && (
            <div style={{ marginTop:10, padding:'8px 12px', background:CL.forestSurface, border:`1px solid ${CL.forestRim}`, borderRadius:8, fontSize:12, fontWeight:600, color:CL.forest }}>
              ✓ Notice posted — parents will see it next time they open the portal.
            </div>
          )}
        </Card>

        <div>
          <div style={{ display:'flex', alignItems:'baseline', justifyContent:'space-between', marginBottom:12 }}>
            <p style={{ fontWeight:700, fontSize:14, color:C.navy }}>Posted notices · {activeClub.name}</p>
            <p style={{ fontSize:12, color:C.textMuted }}>{allNotices.length} total</p>
          </div>
          <div style={{ display:'flex', flexDirection:'column', gap:12 }}>
            {allNotices.length === 0
              ? <Card><p style={{ fontSize:13, color:C.textMuted }}>No notices posted yet.</p></Card>
              : allNotices.map(n => (
                <Card key={n.id} style={{ borderLeft: n.pinned ? `4px solid ${activeClub.accent}` : `1px solid ${C.border}` }}>
                  <div style={{ display:'flex', alignItems:'flex-start', justifyContent:'space-between', gap:10, marginBottom:6 }}>
                    <div style={{ flex:1 }}>
                      <div style={{ display:'flex', gap:6, alignItems:'center', flexWrap:'wrap', marginBottom:4 }}>
                        {n.pinned && <Badge variant="amber">📌 Pinned</Badge>}
                        {n.draft && <Badge variant="green">New</Badge>}
                      </div>
                      <p style={{ fontWeight:700, fontSize:14, color:C.navy }}>{n.title}</p>
                    </div>
                    <p style={{ fontSize:11, color:C.textMuted, whiteSpace:'nowrap' }}>{n.posted}</p>
                  </div>
                  <p style={{ fontSize:13, color:C.textSecondary, lineHeight:1.6, marginBottom:8 }}>{n.body}</p>
                  <p style={{ fontSize:11, color:C.textMuted }}>by {n.author} · sent to {activeClub.memberIds.length} parents</p>
                </Card>
              ))
            }
          </div>
        </div>
      </div>
    </div>
  );
};

// ── Clubs Lead Profile Badge ─────────────────────────────────────────────────
const ClubsLeadProfileBadge = ({ active }) => (
  <div style={{
    width:'100%', display:'flex', alignItems:'center', gap:10,
    padding:'10px 12px', background:'rgba(255,255,255,0.08)',
    border:'1.5px solid rgba(255,255,255,0.12)', borderRadius:10, marginBottom:8,
  }}>
    <Avatar initials={ME_CLUB_LEAD.initials} size={32} color="rgba(255,255,255,0.18)" />
    <div style={{ flex:1, textAlign:'left', minWidth:0 }}>
      <p style={{ fontSize:12, fontWeight:700, color:'#fff', margin:0, whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }}>{ME_CLUB_LEAD.firstName} {ME_CLUB_LEAD.lastName}</p>
      <p style={{ fontSize:10, color:'rgba(255,255,255,0.55)', margin:0 }}>Clubs Lead</p>
    </div>
  </div>
);

// ── Clubs Lead Portal Shell ──────────────────────────────────────────────────
const ClubsLeadPortal = ({ onLogout, mobileMode }) => {
  const [page, setPage] = React.useState('overview');
  const myClubs = CLUBS.filter(c => ME_CLUB_LEAD.clubIds.includes(c.id));
  const [activeClubId, setActiveClubId] = React.useState(myClubs[0]?.id);
  const activeClub = myClubs.find(c => c.id === activeClubId) || myClubs[0];

  const pages = {
    overview:    ClubsLeadOverview,
    behaviour:   ClubsLeadBehaviour,
    attendance:  ClubsLeadAttendance,
    noticeboard: ClubsLeadNoticeboard,
  };
  const PageComp = pages[page] || ClubsLeadOverview;

  const content = (mobile) => (
    <>
      {myClubs.length > 1 && <ClubSwitcher myClubs={myClubs} activeId={activeClubId} onChange={setActiveClubId} mobile={mobile} />}
      <PageComp mobile={mobile} activeClub={activeClub} setPage={setPage} />
    </>
  );

  if (mobileMode) {
    return (
      <div style={{ display:'flex', flexDirection:'column', height:'100%', background:C.bg, overflow:'hidden' }}>
        {/* Header */}
        <div style={{ background:CL.forest, padding:'12px 16px', display:'flex', alignItems:'center', justifyContent:'space-between', flexShrink:0 }}>
          <div style={{ display:'flex', alignItems:'center', gap:10 }}>
            <img src="assets/oasis-logo.png" alt="Oasis" style={{ height:28, filter:'brightness(0) invert(1)' }} />
            <div>
              <p style={{ fontSize:10, color:'rgba(255,255,255,0.7)', margin:0, letterSpacing:'0.4px', textTransform:'uppercase' }}>Clubs Lead</p>
              <p style={{ fontSize:13, fontWeight:700, color:'#fff', margin:0 }}>{ME_CLUB_LEAD.firstName} {ME_CLUB_LEAD.lastName}</p>
            </div>
          </div>
          <button onClick={onLogout} style={{ background:'rgba(255,255,255,0.12)', border:'none', borderRadius:6, padding:'6px 10px', color:'#fff', fontSize:11, fontWeight:600, cursor:'pointer', fontFamily:'inherit' }}>Sign out</button>
        </div>
        {/* Content */}
        <div style={{ flex:1, overflowY:'auto', padding:14 }}>
          {content(true)}
        </div>
        {/* Bottom nav */}
        <div style={{ background:CL.forest, display:'flex', flexShrink:0, borderTop:'1px solid rgba(255,255,255,0.1)' }}>
          {CLUB_NAV.map(n => (
            <button key={n.id} onClick={()=>setPage(n.id)} style={{ flex:1, padding:'10px 4px 8px', border:'none', background:'none', cursor:'pointer', display:'flex', flexDirection:'column', alignItems:'center', gap:3 }}>
              <CLNavIcon path={n.icon} active={page===n.id} />
              <span style={{ fontSize:9, color: page===n.id ? '#fff' : 'rgba(255,255,255,0.55)', fontWeight:600, fontFamily:'inherit' }}>{n.label}</span>
            </button>
          ))}
        </div>
      </div>
    );
  }

  // Desktop layout — sidebar
  return (
    <div style={{ display:'flex', height:'100vh', background:C.bg, overflow:'hidden' }}>
      <div style={{ width:220, background:CL.forest, display:'flex', flexDirection:'column', flexShrink:0, overflowY:'auto' }}>
        <div style={{ padding:'20px 16px 14px', borderBottom:'1px solid rgba(255,255,255,0.08)' }}>
          <img src="assets/oasis-logo.png" alt="Oasis" style={{ height:40, display:'block', margin:'0 auto 10px', filter:'brightness(0) invert(1)' }} />
          <p style={{ fontSize:10, color:'rgba(255,255,255,0.55)', margin:'0 0 10px', letterSpacing:'0.5px', textTransform:'uppercase', textAlign:'center' }}>Clubs Lead Portal</p>
          <ClubsLeadProfileBadge />
        </div>
        <nav style={{ flex:1, padding:'12px 8px' }}>
          {CLUB_NAV.map(n => {
            const isActive = page === n.id;
            return (
              <button key={n.id} onClick={()=>setPage(n.id)} style={{
                width:'100%', display:'flex', alignItems:'center', gap:10, padding:'10px 10px',
                borderRadius:8, border:'none',
                background:isActive ? 'rgba(255,255,255,0.15)' : 'transparent',
                cursor:'pointer', marginBottom:2,
                borderLeft: isActive ? '3px solid #fff' : '3px solid transparent',
                fontFamily:'inherit',
              }}>
                <CLNavIcon path={n.icon} active={isActive} />
                <span style={{ fontSize:13, fontWeight:isActive?700:500, color:isActive?'#fff':'rgba(255,255,255,0.7)' }}>{n.label}</span>
              </button>
            );
          })}
        </nav>
        <div style={{ padding:'10px 14px', borderTop:'1px solid rgba(255,255,255,0.08)' }}>
          <p style={{ fontSize:10, color:'rgba(255,255,255,0.55)', letterSpacing:'0.4px', textTransform:'uppercase', marginBottom:8 }}>Assigned to</p>
          {myClubs.map(c => (
            <div key={c.id} style={{ display:'flex', alignItems:'center', gap:8, padding:'6px 0', fontSize:12, color:'rgba(255,255,255,0.85)' }}>
              <span style={{ fontSize:14 }}>{c.emoji}</span>
              <span>{c.name}</span>
            </div>
          ))}
        </div>
        <div style={{ padding:'12px 14px', borderTop:'1px solid rgba(255,255,255,0.08)' }}>
          <button onClick={onLogout} style={{ width:'100%', padding:'9px', background:'rgba(255,255,255,0.08)', border:'none', borderRadius:8, color:'rgba(255,255,255,0.8)', fontSize:12, fontWeight:600, cursor:'pointer', fontFamily:'inherit' }}>Sign out</button>
        </div>
      </div>
      <div style={{ flex:1, overflowY:'auto', padding:'28px 32px' }}>
        {content(false)}
      </div>
    </div>
  );
};

Object.assign(window, { ClubsLeadPortal });
