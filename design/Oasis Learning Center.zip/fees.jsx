// fees.jsx — Invoices & School Fees. Admin (Head) + Parent views.

(() => {
  const { useState, useEffect, useRef, useMemo } = React;
  const fmt = n => '£' + n.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',');

  // ── Status helpers ─────────────────────────────────────────────────────────
  const STATUS_META = {
    Paid:    { badge:'green',  fg:C.success, bg:C.successBg, dot:C.success },
    Unpaid:  { badge:'amber',  fg:C.warning, bg:C.warningBg, dot:C.warning },
    Overdue: { badge:'red',    fg:C.danger,  bg:C.dangerBg,  dot:C.danger  },
  };
  // Parent-facing label mapping (Unpaid → "Due", everything else same)
  const parentLabel = s => s === 'Unpaid' ? 'Due' : s === 'Overdue' ? 'Late' : 'Paid';

  // ── Small re-used SVG icons ────────────────────────────────────────────────
  const SvgIcon = ({ d, size=16, stroke=2, color='currentColor', fill='none' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill={fill} stroke={color} strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round">
      <path d={d} />
    </svg>
  );

  // PDF / document tile used everywhere
  const PdfTile = ({ size=44 }) => (
    <div style={{
      width:size, height:size, borderRadius:8, flexShrink:0,
      background:'linear-gradient(150deg, #FCE8EA 0%, #F3D6DA 100%)',
      display:'flex', alignItems:'center', justifyContent:'center',
      border:`1px solid ${C.crimsonLight}`, color:C.crimson, fontWeight:800,
      fontSize:size*0.22, letterSpacing:'0.5px',
    }}>PDF</div>
  );

  // ── Upload Modal ───────────────────────────────────────────────────────────
  // Mocks PDF parsing — drag/drop or click → fake "Extracting…" → editable lines → save.
  const UploadInvoiceModal = ({ onClose, onSave, defaultStudentId }) => {
    const [stage, setStage]       = useState('drop');     // drop | parsing | review
    const [fileName, setFileName] = useState('');
    const [fileSize, setFileSize] = useState('');
    const [dragOver, setDragOver] = useState(false);
    const overlayRef = useRef(null);
    const inputRef = useRef(null);

    // Editable parsed state
    const [studentId, setStudentId]   = useState(String(defaultStudentId || STUDENTS[0].id));
    const [invoiceNo, setInvoiceNo]   = useState('');
    const [issued, setIssued]         = useState('2026-04-24');
    const [due, setDue]               = useState('2026-05-15');
    const [items, setItems]           = useState([]);
    const total = useMemo(() => items.reduce((sum, it) => sum + (Number(it.qty)||0) * (Number(it.unit)||0), 0), [items]);

    // Mocked "OCR" — picks a plausible line-item set based on year group
    const mockParse = (student) => {
      const tuition = student.year === 'Y10' ? 445 : student.year === 'Y7' ? 395 : 420;
      const base = [
        { desc:`Spring Term 2 tuition — ${student.year}`, qty:1, unit:tuition },
      ];
      const extras = [
        { desc:'PACE workbooks (×5)',          qty:5, unit:7.50 },
        { desc:'Lunch programme — half term',  qty:1, unit:65.00 },
        { desc:'Stationery resupply',          qty:1, unit:12.00 },
      ];
      // pick 1-2 extras at random-ish but deterministic per student
      const pick = (student.id % 3) + 1;
      return [...base, ...extras.slice(0, pick)];
    };

    useEffect(() => {
      const h = e => { if (e.key === 'Escape') onClose(); };
      window.addEventListener('keydown', h);
      return () => window.removeEventListener('keydown', h);
    }, []);

    const handleFile = (file) => {
      if (!file) return;
      setFileName(file.name || 'Invoice.pdf');
      const kb = file.size ? Math.max(1, Math.round(file.size/1024)) : Math.round(150 + Math.random()*80);
      setFileSize(`${kb} KB`);
      setStage('parsing');
      // Simulate parse
      setTimeout(() => {
        const student = STUDENTS.find(s => String(s.id) === studentId) || STUDENTS[0];
        setItems(mockParse(student));
        // Auto invoice number
        setInvoiceNo('INV-2026-' + String(70 + Math.floor(Math.random()*30)).padStart(3,'0'));
        setStage('review');
      }, 1700);
    };

    const onDrop = (e) => {
      e.preventDefault(); setDragOver(false);
      const f = e.dataTransfer?.files?.[0];
      handleFile(f || { name:'Invoice.pdf', size: 180000 });
    };

    const onPick = () => inputRef.current?.click();
    const onFileChange = (e) => {
      const f = e.target.files?.[0];
      handleFile(f || { name:'Invoice.pdf', size: 180000 });
    };

    const setItem = (i, k, v) => setItems(arr => arr.map((it,idx)=>idx===i?{...it,[k]:v}:it));
    const removeItem = i => setItems(arr => arr.filter((_,idx)=>idx!==i));
    const addItem = () => setItems(arr => [...arr, { desc:'', qty:1, unit:0 }]);

    const handleSave = () => {
      const student = STUDENTS.find(s => String(s.id) === studentId);
      const formatDate = d => {
        const dt = new Date(d);
        return dt.toLocaleDateString('en-GB', { day:'2-digit', month:'short', year:'numeric' });
      };
      onSave({
        id: invoiceNo,
        studentId: student.id,
        issued: formatDate(issued),
        due: formatDate(due),
        paidOn: null,
        fileName, fileSize,
        status: 'Unpaid',
        term: 'Spring Term 2',
        items: items.map(it => ({ ...it, qty:Number(it.qty)||0, unit:Number(it.unit)||0, amount:(Number(it.qty)||0)*(Number(it.unit)||0) })),
        total,
      });
    };

    return (
      <div ref={overlayRef} onClick={e => { if (e.target === overlayRef.current) onClose(); }}
        style={{ position:'fixed', inset:0, zIndex:9000, background:'rgba(10,18,40,0.55)', backdropFilter:'blur(4px)',
          display:'flex', alignItems:'center', justifyContent:'center', padding:20, animation:'pageFadeIn 0.18s ease' }}>
        <div style={{ width:'100%', maxWidth:640, background:C.surface, borderRadius:18,
          boxShadow:'0 32px 80px rgba(0,0,0,0.32)', overflow:'hidden', display:'flex', flexDirection:'column', maxHeight:'calc(100vh - 48px)' }}>

          {/* Header */}
          <div style={{ background:`linear-gradient(130deg, ${C.navy} 0%, ${C.navyMid} 100%)`, padding:'20px 24px',
            display:'flex', alignItems:'center', gap:14, flexShrink:0 }}>
            <div style={{ width:42, height:42, borderRadius:12, background:'rgba(255,255,255,0.12)',
              display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0 }}>
              <SvgIcon size={22} color="#fff" stroke={1.8} d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
            </div>
            <div style={{ flex:1 }}>
              <p style={{ fontSize:17, fontWeight:800, color:'#fff', margin:0 }}>Upload Invoice</p>
              <p style={{ fontSize:12, color:'rgba(255,255,255,0.65)', margin:0, marginTop:4 }}>
                {stage==='drop' && 'Drop a PDF invoice — line items extract automatically'}
                {stage==='parsing' && 'Extracting line items…'}
                {stage==='review' && 'Review and confirm extracted details'}
              </p>
            </div>
            <button onClick={onClose} style={{ width:32, height:32, borderRadius:8, background:'rgba(255,255,255,0.12)',
              border:'none', display:'flex', alignItems:'center', justifyContent:'center', cursor:'pointer', color:'#fff' }}>
              <SvgIcon size={16} stroke={2.5} d="M18 6L6 18M6 6l12 12" />
            </button>
          </div>

          {/* Stage progress */}
          <div style={{ display:'flex', padding:'12px 24px 0', gap:8, flexShrink:0 }}>
            {['Upload', 'Extract', 'Review'].map((label, i) => {
              const stageIdx = stage==='drop'?0:stage==='parsing'?1:2;
              const active = i <= stageIdx;
              return (
                <div key={label} style={{ flex:1, display:'flex', flexDirection:'column', gap:6 }}>
                  <div style={{ height:3, borderRadius:2, background: active ? C.crimson : C.border, transition:'background 0.25s' }} />
                  <p style={{ fontSize:10, fontWeight:700, color: active ? C.crimson : C.textMuted, textTransform:'uppercase', letterSpacing:'0.5px' }}>{label}</p>
                </div>
              );
            })}
          </div>

          {/* Body */}
          <div style={{ overflowY:'auto', padding:'20px 24px 24px', flex:1 }}>

            {stage === 'drop' && (
              <div
                onDragOver={e => { e.preventDefault(); setDragOver(true); }}
                onDragLeave={() => setDragOver(false)}
                onDrop={onDrop}
                onClick={onPick}
                style={{
                  border:`2px dashed ${dragOver ? C.crimson : C.border}`,
                  borderRadius:14, padding:'40px 20px', textAlign:'center',
                  background: dragOver ? C.crimsonLight : C.bg,
                  cursor:'pointer', transition:'all 0.15s',
                }}>
                <div style={{ width:56, height:56, margin:'0 auto 14px', borderRadius:14,
                  background:'#fff', border:`1px solid ${C.border}`,
                  display:'flex', alignItems:'center', justifyContent:'center', color:C.crimson }}>
                  <SvgIcon size={26} stroke={1.8} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M9 19l3-3m0 0l3 3m-3-3v6" />
                </div>
                <p style={{ fontSize:14, fontWeight:700, color:C.navy, margin:0 }}>Drop a PDF invoice here</p>
                <p style={{ fontSize:12, color:C.textSecondary, marginTop:4 }}>or <span style={{ color:C.crimson, fontWeight:700 }}>browse from your computer</span></p>
                <p style={{ fontSize:11, color:C.textMuted, marginTop:14 }}>PDF · max 10 MB · we'll pull out line items & total automatically</p>
                <input ref={inputRef} type="file" accept="application/pdf" onChange={onFileChange} style={{ display:'none' }} />
              </div>
            )}

            {stage === 'parsing' && (
              <div style={{ padding:'20px 0' }}>
                <div style={{ display:'flex', alignItems:'center', gap:14, padding:14, background:C.bg, borderRadius:10, marginBottom:18 }}>
                  <PdfTile />
                  <div style={{ flex:1, minWidth:0 }}>
                    <p style={{ fontSize:13, fontWeight:700, color:C.navy, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{fileName}</p>
                    <p style={{ fontSize:11, color:C.textMuted, marginTop:2 }}>{fileSize} · uploaded</p>
                  </div>
                  <Badge variant="green">✓ Received</Badge>
                </div>
                <div style={{ textAlign:'center', padding:'20px 0 8px' }}>
                  <div style={{ width:40, height:40, margin:'0 auto 14px', border:`3px solid ${C.border}`, borderTopColor:C.crimson, borderRadius:'50%', animation:'spin 0.8s linear infinite' }} />
                  <p style={{ fontSize:13, fontWeight:700, color:C.navy }}>Reading invoice…</p>
                  <p style={{ fontSize:12, color:C.textSecondary, marginTop:4 }}>Pulling out line items, quantities and totals</p>
                </div>
                <style>{`@keyframes spin{to{transform:rotate(360deg);}}`}</style>
              </div>
            )}

            {stage === 'review' && (
              <div>
                {/* File chip */}
                <div style={{ display:'flex', alignItems:'center', gap:12, padding:'10px 12px', background:C.bg, borderRadius:10, marginBottom:16 }}>
                  <PdfTile size={36} />
                  <div style={{ flex:1, minWidth:0 }}>
                    <p style={{ fontSize:12, fontWeight:700, color:C.navy, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{fileName}</p>
                    <p style={{ fontSize:11, color:C.textMuted }}>{fileSize}</p>
                  </div>
                  <Badge variant="green">{items.length} items found</Badge>
                </div>

                {/* Meta row */}
                <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:12, marginBottom:14 }}>
                  <div>
                    <label style={{ fontSize:11, fontWeight:700, color:C.textSecondary, display:'block', marginBottom:5, textTransform:'uppercase', letterSpacing:'0.4px' }}>Bill to (Parent of)</label>
                    <select value={studentId} onChange={e=>setStudentId(e.target.value)}
                      style={{ width:'100%', padding:'9px 12px', border:`1.5px solid ${C.border}`, borderRadius:8, fontSize:13, fontFamily:'inherit', color:C.textPrimary, background:C.surface, outline:'none' }}>
                      {STUDENTS.map(s => <option key={s.id} value={s.id}>{s.name} ({s.year})</option>)}
                    </select>
                  </div>
                  <div>
                    <label style={{ fontSize:11, fontWeight:700, color:C.textSecondary, display:'block', marginBottom:5, textTransform:'uppercase', letterSpacing:'0.4px' }}>Invoice no.</label>
                    <input value={invoiceNo} onChange={e=>setInvoiceNo(e.target.value)}
                      style={{ width:'100%', padding:'9px 12px', border:`1.5px solid ${C.border}`, borderRadius:8, fontSize:13, fontFamily:'inherit', color:C.textPrimary, outline:'none' }} />
                  </div>
                  <div>
                    <label style={{ fontSize:11, fontWeight:700, color:C.textSecondary, display:'block', marginBottom:5, textTransform:'uppercase', letterSpacing:'0.4px' }}>Issued</label>
                    <input type="date" value={issued} onChange={e=>setIssued(e.target.value)}
                      style={{ width:'100%', padding:'9px 12px', border:`1.5px solid ${C.border}`, borderRadius:8, fontSize:13, fontFamily:'inherit', color:C.textPrimary, outline:'none' }} />
                  </div>
                  <div>
                    <label style={{ fontSize:11, fontWeight:700, color:C.textSecondary, display:'block', marginBottom:5, textTransform:'uppercase', letterSpacing:'0.4px' }}>Due date</label>
                    <input type="date" value={due} onChange={e=>setDue(e.target.value)}
                      style={{ width:'100%', padding:'9px 12px', border:`1.5px solid ${C.border}`, borderRadius:8, fontSize:13, fontFamily:'inherit', color:C.textPrimary, outline:'none' }} />
                  </div>
                </div>

                {/* Line items */}
                <div style={{ marginBottom:8 }}>
                  <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:8 }}>
                    <p style={{ fontSize:11, fontWeight:700, color:C.textSecondary, textTransform:'uppercase', letterSpacing:'0.4px' }}>Extracted items</p>
                    <button onClick={addItem} style={{ background:'none', border:'none', color:C.blue, fontSize:12, fontWeight:700, cursor:'pointer', fontFamily:'inherit' }}>+ Add row</button>
                  </div>
                  <div style={{ border:`1px solid ${C.border}`, borderRadius:10, overflow:'hidden' }}>
                    <div style={{ display:'grid', gridTemplateColumns:'1fr 60px 90px 90px 32px', gap:0, padding:'8px 12px', background:C.bg, fontSize:10, fontWeight:700, color:C.textSecondary, textTransform:'uppercase', letterSpacing:'0.5px' }}>
                      <span>Description</span><span style={{ textAlign:'center' }}>Qty</span><span style={{ textAlign:'right' }}>Unit</span><span style={{ textAlign:'right' }}>Amount</span><span></span>
                    </div>
                    {items.map((it, i) => {
                      const amt = (Number(it.qty)||0) * (Number(it.unit)||0);
                      return (
                        <div key={i} style={{ display:'grid', gridTemplateColumns:'1fr 60px 90px 90px 32px', gap:0, padding:'6px 12px', borderTop:`1px solid ${C.borderLight}`, alignItems:'center' }}>
                          <input value={it.desc} onChange={e=>setItem(i,'desc',e.target.value)} placeholder="Item description"
                            style={{ padding:'6px 8px', border:`1px solid transparent`, borderRadius:6, fontSize:12, fontFamily:'inherit', color:C.textPrimary, outline:'none', background:'transparent' }}
                            onFocus={e=>e.target.style.border=`1px solid ${C.border}`} onBlur={e=>e.target.style.border='1px solid transparent'} />
                          <input type="number" value={it.qty} onChange={e=>setItem(i,'qty',e.target.value)} min="0"
                            style={{ padding:'6px 8px', border:`1px solid transparent`, borderRadius:6, fontSize:12, fontFamily:'inherit', color:C.textPrimary, outline:'none', textAlign:'center', background:'transparent' }}
                            onFocus={e=>e.target.style.border=`1px solid ${C.border}`} onBlur={e=>e.target.style.border='1px solid transparent'} />
                          <input type="number" value={it.unit} onChange={e=>setItem(i,'unit',e.target.value)} step="0.01" min="0"
                            style={{ padding:'6px 8px', border:`1px solid transparent`, borderRadius:6, fontSize:12, fontFamily:'inherit', color:C.textPrimary, outline:'none', textAlign:'right', background:'transparent' }}
                            onFocus={e=>e.target.style.border=`1px solid ${C.border}`} onBlur={e=>e.target.style.border='1px solid transparent'} />
                          <span style={{ fontSize:12, fontWeight:700, color:C.navy, textAlign:'right' }}>{fmt(amt)}</span>
                          <button onClick={()=>removeItem(i)} style={{ background:'none', border:'none', color:C.textMuted, cursor:'pointer', padding:0, display:'flex', justifyContent:'center', alignItems:'center' }} title="Remove row">
                            <SvgIcon size={14} stroke={2} d="M18 6L6 18M6 6l12 12" />
                          </button>
                        </div>
                      );
                    })}
                    <div style={{ display:'flex', justifyContent:'flex-end', alignItems:'center', gap:14, padding:'10px 14px', background:C.bg, borderTop:`1px solid ${C.border}` }}>
                      <span style={{ fontSize:11, fontWeight:700, color:C.textSecondary, textTransform:'uppercase', letterSpacing:'0.4px' }}>Total</span>
                      <span style={{ fontSize:20, fontWeight:800, color:C.navy }}>{fmt(total)}</span>
                    </div>
                  </div>
                </div>
                <p style={{ fontSize:11, color:C.textMuted, marginTop:6 }}>Edit any row above — totals recalculate automatically.</p>
              </div>
            )}
          </div>

          {/* Footer */}
          {stage === 'review' && (
            <div style={{ display:'flex', justifyContent:'flex-end', gap:8, padding:'14px 24px', borderTop:`1px solid ${C.border}`, background:C.bg, flexShrink:0 }}>
              <Btn variant="secondary" onClick={onClose}>Cancel</Btn>
              <Btn variant="primary" onClick={handleSave} disabled={!items.length || !invoiceNo}>Save & Send to Parent</Btn>
            </div>
          )}
        </div>
      </div>
    );
  };

  // ── Invoice Detail Drawer (admin) ──────────────────────────────────────────
  const InvoiceDetailDrawer = ({ inv, onClose, onTogglePaid, onDelete }) => {
    useEffect(() => {
      const h = e => { if (e.key === 'Escape') onClose(); };
      window.addEventListener('keydown', h);
      return () => window.removeEventListener('keydown', h);
    }, []);
    if (!inv) return null;
    const student = STUDENTS.find(s => s.id === inv.studentId);
    const meta = STATUS_META[inv.status];

    return (
      <div onClick={onClose} style={{ position:'fixed', inset:0, zIndex:9000, background:'rgba(10,18,40,0.45)', backdropFilter:'blur(2px)', display:'flex', justifyContent:'flex-end', animation:'pageFadeIn 0.15s ease' }}>
        <div onClick={e=>e.stopPropagation()} style={{ width:'100%', maxWidth:520, height:'100%', background:C.surface, boxShadow:'-24px 0 80px rgba(0,0,0,0.25)', display:'flex', flexDirection:'column' }}>
          {/* Header */}
          <div style={{ padding:'18px 24px', borderBottom:`1px solid ${C.border}`, display:'flex', alignItems:'center', justifyContent:'space-between', flexShrink:0 }}>
            <div>
              <p style={{ fontSize:11, color:C.textMuted, fontWeight:700, letterSpacing:'0.4px', textTransform:'uppercase' }}>Invoice</p>
              <p style={{ fontSize:18, fontWeight:800, color:C.navy }}>{inv.id}</p>
            </div>
            <button onClick={onClose} style={{ width:32, height:32, borderRadius:8, background:C.bg, border:'none', cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center', color:C.textSecondary }}>
              <SvgIcon size={16} stroke={2.5} d="M18 6L6 18M6 6l12 12" />
            </button>
          </div>

          {/* Body */}
          <div style={{ flex:1, overflowY:'auto', padding:'20px 24px' }}>
            {/* Status banner */}
            <div style={{ padding:'12px 14px', background:meta.bg, border:`1px solid ${meta.fg}30`, borderRadius:10, marginBottom:18, display:'flex', alignItems:'center', justifyContent:'space-between' }}>
              <div style={{ display:'flex', alignItems:'center', gap:10 }}>
                <div style={{ width:8, height:8, borderRadius:'50%', background:meta.dot }} />
                <div>
                  <p style={{ fontSize:13, fontWeight:800, color:meta.fg }}>{inv.status}</p>
                  <p style={{ fontSize:11, color:meta.fg, opacity:0.85 }}>
                    {inv.status==='Paid' ? `Paid on ${inv.paidOn}` : inv.status==='Overdue' ? `Was due ${inv.due}` : `Due ${inv.due}`}
                  </p>
                </div>
              </div>
              <button onClick={()=>onTogglePaid(inv)} style={{
                padding:'7px 14px', borderRadius:8, border:'none', cursor:'pointer', fontFamily:'inherit',
                fontSize:12, fontWeight:700,
                background: inv.status==='Paid' ? C.surface : C.success, color: inv.status==='Paid' ? meta.fg : '#fff',
                boxShadow: inv.status==='Paid' ? `inset 0 0 0 1.5px ${meta.fg}` : 'none',
              }}>
                {inv.status==='Paid' ? 'Mark as Unpaid' : 'Mark as Paid'}
              </button>
            </div>

            {/* Bill to */}
            <div style={{ display:'flex', alignItems:'center', gap:12, marginBottom:18 }}>
              <Avatar initials={student.initials} size={44} color={student.color} />
              <div>
                <p style={{ fontSize:11, fontWeight:700, color:C.textMuted, letterSpacing:'0.4px', textTransform:'uppercase' }}>Bill to · Parent of</p>
                <p style={{ fontSize:15, fontWeight:800, color:C.navy }}>{student.name}</p>
                <p style={{ fontSize:12, color:C.textSecondary }}>{student.year} · Supervisor: {student.tutor}</p>
              </div>
            </div>

            {/* Meta grid */}
            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:8, marginBottom:18 }}>
              {[['Issued',inv.issued], ['Due',inv.due], ['Term',inv.term]].map(([l,v]) => (
                <div key={l} style={{ background:C.bg, borderRadius:8, padding:'10px 12px' }}>
                  <p style={{ fontSize:10, fontWeight:700, color:C.textMuted, letterSpacing:'0.4px', textTransform:'uppercase' }}>{l}</p>
                  <p style={{ fontSize:12, fontWeight:700, color:C.navy, marginTop:3 }}>{v}</p>
                </div>
              ))}
            </div>

            {/* File chip */}
            <div style={{ display:'flex', alignItems:'center', gap:12, padding:'12px 14px', border:`1px solid ${C.border}`, borderRadius:10, marginBottom:18 }}>
              <PdfTile size={36} />
              <div style={{ flex:1, minWidth:0 }}>
                <p style={{ fontSize:12, fontWeight:700, color:C.navy, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{inv.fileName}</p>
                <p style={{ fontSize:11, color:C.textMuted }}>{inv.fileSize} · original upload</p>
              </div>
              <Btn variant="secondary" size="sm">Download</Btn>
            </div>

            {/* Line items */}
            <p style={{ fontSize:11, fontWeight:700, color:C.textSecondary, textTransform:'uppercase', letterSpacing:'0.5px', marginBottom:8 }}>Line items</p>
            <div style={{ border:`1px solid ${C.border}`, borderRadius:10, overflow:'hidden', marginBottom:14 }}>
              {inv.items.map((it, i) => (
                <div key={i} style={{ display:'flex', alignItems:'center', justifyContent:'space-between', padding:'11px 14px', borderTop: i ? `1px solid ${C.borderLight}` : 'none' }}>
                  <div style={{ flex:1, minWidth:0 }}>
                    <p style={{ fontSize:13, fontWeight:600, color:C.textPrimary }}>{it.desc}</p>
                    {it.qty > 1 && <p style={{ fontSize:11, color:C.textMuted, marginTop:2 }}>{it.qty} × {fmt(it.unit)}</p>}
                  </div>
                  <span style={{ fontSize:13, fontWeight:700, color:C.navy }}>{fmt(it.amount)}</span>
                </div>
              ))}
              <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', padding:'12px 14px', borderTop:`1px solid ${C.border}`, background:C.bg }}>
                <span style={{ fontSize:12, fontWeight:700, color:C.textSecondary, textTransform:'uppercase', letterSpacing:'0.4px' }}>Total</span>
                <span style={{ fontSize:20, fontWeight:800, color:C.navy }}>{fmt(inv.total)}</span>
              </div>
            </div>
          </div>

          {/* Footer actions */}
          <div style={{ padding:'14px 24px', borderTop:`1px solid ${C.border}`, background:C.bg, display:'flex', gap:8, justifyContent:'space-between', flexShrink:0 }}>
            <button onClick={()=>{ onDelete(inv); onClose(); }} style={{ padding:'9px 14px', background:'transparent', border:'none', color:C.danger, fontWeight:600, fontSize:12, cursor:'pointer', fontFamily:'inherit' }}>Delete invoice</button>
            <div style={{ display:'flex', gap:8 }}>
              <Btn variant="secondary" size="sm">Send reminder</Btn>
              <Btn variant="secondary" size="sm">Download PDF</Btn>
            </div>
          </div>
        </div>
      </div>
    );
  };

  // ── Admin Fees Page ────────────────────────────────────────────────────────
  const AdminFees = ({ mobile }) => {
    const [invoices, setInvoices] = useState(INVOICES);
    const [filter, setFilter]     = useState('all');
    const [search, setSearch]     = useState('');
    const [uploadOpen, setUploadOpen] = useState(false);
    const [detail, setDetail]     = useState(null);

    const stats = useMemo(() => {
      const outstanding = invoices.filter(i => i.status !== 'Paid').reduce((a,b)=>a+b.total,0);
      const overdueAmt  = invoices.filter(i => i.status === 'Overdue').reduce((a,b)=>a+b.total,0);
      const paidTerm    = invoices.filter(i => i.status === 'Paid').reduce((a,b)=>a+b.total,0);
      const counts = { all: invoices.length, Unpaid:0, Overdue:0, Paid:0 };
      invoices.forEach(i => counts[i.status]++);
      return { outstanding, overdueAmt, paidTerm, counts };
    }, [invoices]);

    const filtered = useMemo(() => {
      let list = invoices;
      if (filter !== 'all') list = list.filter(i => i.status === filter);
      if (search.trim()) {
        const q = search.toLowerCase();
        list = list.filter(i => {
          const student = STUDENTS.find(s => s.id === i.studentId);
          return i.id.toLowerCase().includes(q) || (student && student.name.toLowerCase().includes(q));
        });
      }
      return list;
    }, [invoices, filter, search]);

    const togglePaid = (inv) => {
      setInvoices(arr => arr.map(i => {
        if (i.id !== inv.id) return i;
        if (i.status === 'Paid') return { ...i, status:'Unpaid', paidOn:null };
        return { ...i, status:'Paid', paidOn: new Date().toLocaleDateString('en-GB', { day:'2-digit', month:'short', year:'numeric' }) };
      }));
      setDetail(d => d && d.id === inv.id ? { ...d, status: inv.status==='Paid'?'Unpaid':'Paid', paidOn: inv.status==='Paid'?null:new Date().toLocaleDateString('en-GB',{day:'2-digit',month:'short',year:'numeric'}) } : d);
    };

    const handleSave = (inv) => {
      setInvoices(arr => [inv, ...arr]);
      setUploadOpen(false);
    };

    const handleDelete = (inv) => setInvoices(arr => arr.filter(i => i.id !== inv.id));

    const FILTERS = [
      ['all',     `All`,      stats.counts.all,     C.navy],
      ['Unpaid',  `Due`,      stats.counts.Unpaid,  C.warning],
      ['Overdue', `Overdue`,  stats.counts.Overdue, C.danger],
      ['Paid',    `Paid`,     stats.counts.Paid,    C.success],
    ];

    return (
      <div className="page-fade">
        {/* Heading */}
        <div style={{ display:'flex', alignItems:'flex-start', justifyContent:'space-between', marginBottom:20, gap:14, flexWrap:'wrap' }}>
          <div>
            <h2 style={{ fontSize:mobile?18:22, fontWeight:800, color:C.navy }}>Invoices &amp; School Fees</h2>
            <p style={{ fontSize:13, color:C.textSecondary, marginTop:3 }}>Upload invoices and parents see them instantly · Spring Term 2026</p>
          </div>
          <Btn variant="primary" onClick={()=>setUploadOpen(true)}>
            <SvgIcon size={14} stroke={2.4} d="M12 4v16m8-8H4" />
            Upload Invoice
          </Btn>
        </div>

        {/* Stat cards */}
        <div style={{ display:'grid', gridTemplateColumns:mobile?'1fr 1fr':'repeat(4,1fr)', gap:12, marginBottom:18 }}>
          <StatCard label="Outstanding" value={fmt(stats.outstanding)} sub={`${stats.counts.Unpaid + stats.counts.Overdue} invoices to chase`} accent={C.warning} />
          <StatCard label="Overdue"     value={fmt(stats.overdueAmt)}  sub={`${stats.counts.Overdue} past due date`} accent={C.danger} />
          <StatCard label="Collected"   value={fmt(stats.paidTerm)}    sub={`${stats.counts.Paid} paid this term`} accent={C.success} />
          <StatCard label="Total Issued" value={invoices.length}       sub="invoices on file" accent={C.blue} />
        </div>

        {/* Filter pills + search */}
        <div style={{ display:'flex', alignItems:'center', gap:10, marginBottom:14, flexWrap:'wrap' }}>
          <div style={{ display:'flex', gap:4, background:C.bg, borderRadius:10, padding:4, flexWrap:'wrap' }}>
            {FILTERS.map(([id, label, count, col]) => (
              <button key={id} onClick={()=>setFilter(id)} style={{
                padding:'7px 14px', borderRadius:7, border:'none',
                background: filter===id ? '#fff' : 'transparent',
                color: filter===id ? C.navy : C.textSecondary,
                boxShadow: filter===id ? '0 1px 3px rgba(0,0,0,0.08)' : 'none',
                fontWeight:700, fontSize:12, cursor:'pointer', fontFamily:'inherit',
                display:'flex', alignItems:'center', gap:7,
              }}>
                <span>{label}</span>
                <span style={{ background: filter===id ? col : 'transparent', color: filter===id ? '#fff' : C.textMuted, fontSize:10, padding:'1px 7px', borderRadius:10, fontWeight:700,
                  border: filter===id ? 'none' : `1px solid ${C.border}` }}>{count}</span>
              </button>
            ))}
          </div>
          <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search invoice no. or parent…"
            style={{ flex:1, minWidth:200, padding:'9px 14px', border:`1.5px solid ${C.border}`, borderRadius:8, fontSize:13, fontFamily:'inherit', color:C.navy, outline:'none', background:'#fff' }} />
        </div>

        {/* Invoices list */}
        {filtered.length === 0 ? (
          <Card style={{ textAlign:'center', padding:'40px 20px' }}>
            <p style={{ fontSize:14, fontWeight:700, color:C.navy }}>No invoices found</p>
            <p style={{ fontSize:12, color:C.textMuted, marginTop:4 }}>Try a different filter, or upload a new invoice.</p>
          </Card>
        ) : mobile ? (
          <div style={{ display:'flex', flexDirection:'column', gap:10 }}>
            {filtered.map(inv => {
              const student = STUDENTS.find(s => s.id === inv.studentId);
              const meta = STATUS_META[inv.status];
              return (
                <Card key={inv.id} padding={14} style={{ cursor:'pointer', borderLeft:`4px solid ${meta.dot}` }}>
                  <div onClick={()=>setDetail(inv)}>
                    <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:8 }}>
                      <div>
                        <p style={{ fontSize:11, color:C.textMuted, fontWeight:700, letterSpacing:'0.3px' }}>{inv.id}</p>
                        <p style={{ fontSize:14, fontWeight:700, color:C.navy, marginTop:2 }}>{student.name}</p>
                      </div>
                      <Badge variant={meta.badge}>{inv.status}</Badge>
                    </div>
                    <p style={{ fontSize:11, color:C.textSecondary, marginBottom:10 }}>
                      {inv.items.length} items · Due {inv.due}
                    </p>
                    <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between' }}>
                      <span style={{ fontSize:18, fontWeight:800, color:C.navy }}>{fmt(inv.total)}</span>
                      <button onClick={e=>{ e.stopPropagation(); togglePaid(inv); }} style={{
                        padding:'5px 10px', borderRadius:6, border:'none', fontSize:11, fontWeight:700, cursor:'pointer', fontFamily:'inherit',
                        background: inv.status==='Paid' ? C.bg : C.success, color: inv.status==='Paid' ? C.textSecondary : '#fff',
                      }}>{inv.status==='Paid' ? 'Unpaid' : 'Mark Paid'}</button>
                    </div>
                  </div>
                </Card>
              );
            })}
          </div>
        ) : (
          <Card padding={0}>
            <table style={{ width:'100%', borderCollapse:'collapse', fontSize:13 }}>
              <thead>
                <tr style={{ background:C.bg }}>
                  {['Invoice','Parent of','Items','Issued','Due','Total','Status','Action'].map(h => (
                    <th key={h} style={{ padding:'10px 14px', textAlign: h==='Total' || h==='Status' || h==='Action' ? 'right' : 'left', fontSize:11, fontWeight:700, color:C.textSecondary, textTransform:'uppercase', letterSpacing:'0.5px' }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtered.map((inv, idx) => {
                  const student = STUDENTS.find(s => s.id === inv.studentId);
                  return (
                    <tr key={inv.id} style={{ borderTop:`1px solid ${C.border}`, cursor:'pointer' }}
                      onClick={()=>setDetail(inv)}
                      onMouseEnter={e=>e.currentTarget.style.background=C.bg}
                      onMouseLeave={e=>e.currentTarget.style.background=''}>
                      <td style={{ padding:'12px 14px' }}>
                        <div style={{ display:'flex', alignItems:'center', gap:10 }}>
                          <PdfTile size={32} />
                          <div>
                            <p style={{ fontWeight:700, color:C.navy, fontSize:13 }}>{inv.id}</p>
                            <p style={{ fontSize:11, color:C.textMuted }}>{inv.term}</p>
                          </div>
                        </div>
                      </td>
                      <td style={{ padding:'12px 14px' }}>
                        <div style={{ display:'flex', alignItems:'center', gap:8 }}>
                          <Avatar initials={student.initials} size={28} color={student.color} />
                          <div>
                            <p style={{ fontWeight:600, color:C.navy, fontSize:13 }}>{student.name}</p>
                            <p style={{ fontSize:11, color:C.textMuted }}>{student.year}</p>
                          </div>
                        </div>
                      </td>
                      <td style={{ padding:'12px 14px', color:C.textSecondary, fontSize:12 }}>
                        <p>{inv.items[0].desc}</p>
                        {inv.items.length > 1 && <p style={{ fontSize:11, color:C.textMuted, marginTop:2 }}>+ {inv.items.length - 1} more</p>}
                      </td>
                      <td style={{ padding:'12px 14px', color:C.textSecondary, fontSize:12, whiteSpace:'nowrap' }}>{inv.issued}</td>
                      <td style={{ padding:'12px 14px', color: inv.status==='Overdue' ? C.danger : C.textSecondary, fontWeight: inv.status==='Overdue' ? 700 : 400, fontSize:12, whiteSpace:'nowrap' }}>{inv.due}</td>
                      <td style={{ padding:'12px 14px', textAlign:'right', fontWeight:800, color:C.navy, whiteSpace:'nowrap' }}>{fmt(inv.total)}</td>
                      <td style={{ padding:'12px 14px', textAlign:'right' }}>
                        <Badge variant={STATUS_META[inv.status].badge}>{inv.status}</Badge>
                      </td>
                      <td style={{ padding:'12px 14px', textAlign:'right', whiteSpace:'nowrap' }}>
                        <button onClick={e=>{ e.stopPropagation(); togglePaid(inv); }} style={{
                          padding:'6px 12px', borderRadius:7, border: inv.status==='Paid' ? `1.5px solid ${C.border}` : 'none',
                          background: inv.status==='Paid' ? '#fff' : C.success,
                          color: inv.status==='Paid' ? C.textSecondary : '#fff',
                          fontSize:11, fontWeight:700, cursor:'pointer', fontFamily:'inherit',
                        }}>{inv.status==='Paid' ? 'Mark Unpaid' : 'Mark Paid'}</button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </Card>
        )}

        {uploadOpen && <UploadInvoiceModal onClose={()=>setUploadOpen(false)} onSave={handleSave} />}
        {detail && <InvoiceDetailDrawer inv={detail} onClose={()=>setDetail(null)} onTogglePaid={togglePaid} onDelete={handleDelete} />}
      </div>
    );
  };

  // ── Parent Fees Page ───────────────────────────────────────────────────────
  // Parent only sees invoices for MY_CHILD.
  const ParentFees = ({ mobile }) => {
    const child = MY_CHILD;
    const myInvoices = useMemo(() => INVOICES.filter(i => i.studentId === child.id), [child.id]);
    const [filter, setFilter] = useState('all');
    const [expanded, setExpanded] = useState(myInvoices.find(i => i.status === 'Unpaid')?.id || null);

    const outstanding = myInvoices.filter(i => i.status !== 'Paid').reduce((a,b)=>a+b.total,0);
    const nextDue = myInvoices.filter(i => i.status === 'Unpaid').sort((a,b)=>new Date(a.due)-new Date(b.due))[0];
    const overdue = myInvoices.filter(i => i.status === 'Overdue');
    const counts = { all: myInvoices.length, Unpaid:0, Overdue:0, Paid:0 };
    myInvoices.forEach(i => counts[i.status]++);

    const filtered = filter === 'all' ? myInvoices : myInvoices.filter(i => i.status === filter);

    const FILTERS = [
      ['all',     'All',     counts.all,     C.navy],
      ['Unpaid',  'Due',     counts.Unpaid,  C.warning],
      ['Overdue', 'Late',    counts.Overdue, C.danger],
      ['Paid',    'Paid',    counts.Paid,    C.success],
    ];

    return (
      <div className="page-fade">
        <h2 style={{ fontSize:mobile?18:22, fontWeight:800, color:C.navy, marginBottom:4 }}>School Fees</h2>
        <p style={{ fontSize:13, color:C.textSecondary, marginBottom:20 }}>{child.name} · invoices issued by Oasis Learning Centre</p>

        {/* Hero summary card */}
        <Card style={{ background:`linear-gradient(135deg, ${C.crimson} 0%, #9B2235 100%)`, border:'none', marginBottom:20, color:'#fff' }} padding={mobile?18:24}>
          <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', gap:16, flexWrap:'wrap' }}>
            <div>
              <p style={{ fontSize:12, color:'rgba(255,255,255,0.7)', fontWeight:700, letterSpacing:'0.4px', textTransform:'uppercase' }}>Outstanding balance</p>
              <p style={{ fontSize:mobile?32:42, fontWeight:800, color:'#fff', marginTop:6, lineHeight:1 }}>{fmt(outstanding)}</p>
              {nextDue && (
                <p style={{ fontSize:12, color:'rgba(255,255,255,0.85)', marginTop:10 }}>
                  Next payment <strong style={{ color:'#fff' }}>{fmt(nextDue.total)}</strong> due {nextDue.due}
                </p>
              )}
              {!nextDue && outstanding === 0 && (
                <p style={{ fontSize:12, color:'rgba(255,255,255,0.85)', marginTop:10 }}>All fees up to date — thank you!</p>
              )}
            </div>
            <div style={{ display:'flex', gap:10, flexWrap:'wrap' }}>
              {overdue.length > 0 && (
                <div style={{ background:'rgba(0,0,0,0.18)', padding:'10px 14px', borderRadius:10, border:`1px solid rgba(255,255,255,0.15)` }}>
                  <p style={{ fontSize:10, color:'rgba(255,255,255,0.7)', fontWeight:700, letterSpacing:'0.4px', textTransform:'uppercase' }}>⚠ Late payments</p>
                  <p style={{ fontSize:18, fontWeight:800, color:'#fff', marginTop:4 }}>{overdue.length}</p>
                </div>
              )}
              <div style={{ background:'rgba(255,255,255,0.12)', padding:'10px 14px', borderRadius:10 }}>
                <p style={{ fontSize:10, color:'rgba(255,255,255,0.7)', fontWeight:700, letterSpacing:'0.4px', textTransform:'uppercase' }}>Paid this year</p>
                <p style={{ fontSize:18, fontWeight:800, color:'#fff', marginTop:4 }}>{fmt(myInvoices.filter(i=>i.status==='Paid').reduce((a,b)=>a+b.total,0))}</p>
              </div>
            </div>
          </div>
        </Card>

        {/* Filter pills */}
        <div style={{ display:'flex', gap:4, background:C.bg, borderRadius:10, padding:4, marginBottom:14, width:'fit-content', flexWrap:'wrap' }}>
          {FILTERS.map(([id, label, count, col]) => (
            <button key={id} onClick={()=>setFilter(id)} style={{
              padding:'7px 14px', borderRadius:7, border:'none',
              background: filter===id ? '#fff' : 'transparent',
              color: filter===id ? C.navy : C.textSecondary,
              boxShadow: filter===id ? '0 1px 3px rgba(0,0,0,0.08)' : 'none',
              fontWeight:700, fontSize:12, cursor:'pointer', fontFamily:'inherit',
              display:'flex', alignItems:'center', gap:7,
            }}>
              <span>{label}</span>
              <span style={{ background: filter===id ? col : 'transparent', color: filter===id ? '#fff' : C.textMuted, fontSize:10, padding:'1px 7px', borderRadius:10, fontWeight:700,
                border: filter===id ? 'none' : `1px solid ${C.border}` }}>{count}</span>
            </button>
          ))}
        </div>

        {/* Invoice list — accordion cards */}
        {filtered.length === 0 ? (
          <Card style={{ textAlign:'center', padding:'40px 20px' }}>
            <p style={{ fontSize:14, fontWeight:700, color:C.navy }}>No invoices in this view</p>
            <p style={{ fontSize:12, color:C.textMuted, marginTop:4 }}>Try a different filter.</p>
          </Card>
        ) : (
          <div style={{ display:'flex', flexDirection:'column', gap:10 }}>
            {filtered.map(inv => {
              const meta = STATUS_META[inv.status];
              const open = expanded === inv.id;
              const label = parentLabel(inv.status);
              return (
                <Card key={inv.id} padding={0} style={{ borderLeft:`4px solid ${meta.dot}`, overflow:'hidden' }}>
                  {/* Row */}
                  <div onClick={()=>setExpanded(open ? null : inv.id)} style={{
                    padding:mobile?'14px':'14px 18px', cursor:'pointer',
                    display:'flex', alignItems:'center', gap:14,
                  }}>
                    <PdfTile size={mobile?38:42} />
                    <div style={{ flex:1, minWidth:0 }}>
                      <div style={{ display:'flex', alignItems:'center', gap:8, flexWrap:'wrap' }}>
                        <p style={{ fontSize:14, fontWeight:800, color:C.navy }}>{inv.id}</p>
                        <Badge variant={meta.badge}>{label}{inv.status==='Paid' && inv.paidOn ? ` · ${inv.paidOn}` : ''}</Badge>
                      </div>
                      <p style={{ fontSize:12, color:C.textSecondary, marginTop:3 }}>
                        {inv.term} · {inv.items.length} item{inv.items.length>1?'s':''}
                        {inv.status==='Overdue' && <span style={{ color:C.danger, fontWeight:700 }}> · was due {inv.due}</span>}
                        {inv.status==='Unpaid' && <span style={{ color:C.warning, fontWeight:700 }}> · due {inv.due}</span>}
                      </p>
                    </div>
                    <div style={{ textAlign:'right' }}>
                      <p style={{ fontSize:mobile?16:18, fontWeight:800, color:C.navy }}>{fmt(inv.total)}</p>
                      <p style={{ fontSize:10, color:C.textMuted, marginTop:2 }}>{open?'Hide':'View'} details</p>
                    </div>
                    <SvgIcon size={16} stroke={2.2} color={C.textMuted} d={open ? 'M18 15l-6-6-6 6' : 'M6 9l6 6 6-6'} />
                  </div>

                  {/* Expanded */}
                  {open && (
                    <div style={{ borderTop:`1px solid ${C.border}`, background:C.bg, padding:mobile?'14px':'16px 18px' }}>
                      {/* Meta row */}
                      <div style={{ display:'grid', gridTemplateColumns:mobile?'1fr 1fr':'repeat(3,1fr)', gap:8, marginBottom:14 }}>
                        {[['Issued',inv.issued], ['Due date',inv.due], [inv.status==='Paid'?'Paid on':'Status', inv.status==='Paid'?inv.paidOn:label]].map(([l,v]) => (
                          <div key={l} style={{ background:'#fff', borderRadius:8, padding:'9px 12px', border:`1px solid ${C.border}` }}>
                            <p style={{ fontSize:10, fontWeight:700, color:C.textMuted, letterSpacing:'0.4px', textTransform:'uppercase' }}>{l}</p>
                            <p style={{ fontSize:12, fontWeight:700, color:l==='Status'?meta.fg:C.navy, marginTop:3 }}>{v}</p>
                          </div>
                        ))}
                      </div>

                      {/* Line items */}
                      <div style={{ background:'#fff', borderRadius:10, border:`1px solid ${C.border}`, overflow:'hidden', marginBottom:12 }}>
                        {inv.items.map((it, i) => (
                          <div key={i} style={{ display:'flex', alignItems:'center', justifyContent:'space-between', padding:'10px 14px', borderTop: i ? `1px solid ${C.borderLight}` : 'none' }}>
                            <div style={{ flex:1, minWidth:0 }}>
                              <p style={{ fontSize:13, color:C.textPrimary, fontWeight:500 }}>{it.desc}</p>
                              {it.qty > 1 && <p style={{ fontSize:11, color:C.textMuted, marginTop:1 }}>{it.qty} × {fmt(it.unit)}</p>}
                            </div>
                            <span style={{ fontSize:13, fontWeight:700, color:C.navy }}>{fmt(it.amount)}</span>
                          </div>
                        ))}
                        <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', padding:'11px 14px', borderTop:`1px solid ${C.border}`, background:C.bg }}>
                          <span style={{ fontSize:12, fontWeight:700, color:C.textSecondary, textTransform:'uppercase', letterSpacing:'0.4px' }}>Total</span>
                          <span style={{ fontSize:18, fontWeight:800, color:C.navy }}>{fmt(inv.total)}</span>
                        </div>
                      </div>

                      {/* Actions */}
                      <div style={{ display:'flex', gap:8, flexWrap:'wrap' }}>
                        <Btn variant="navy" size="sm">
                          <SvgIcon size={13} stroke={2.2} d="M4 16v2a2 2 0 002 2h12a2 2 0 002-2v-2M7 10l5 5 5-5M12 15V3" />
                          Download PDF
                        </Btn>
                        {inv.status !== 'Paid' && (
                          <Btn variant="primary" size="sm">Pay Online</Btn>
                        )}
                        <Btn variant="secondary" size="sm">Message office</Btn>
                      </div>
                    </div>
                  )}
                </Card>
              );
            })}
          </div>
        )}

        {/* Footer note */}
        <p style={{ fontSize:11, color:C.textMuted, marginTop:18, textAlign:'center' }}>
          Need to query an invoice? Contact the office on 0121 555 0188 or message the Head of Centre.
        </p>
      </div>
    );
  };

  Object.assign(window, { AdminFees, ParentFees });
})();
