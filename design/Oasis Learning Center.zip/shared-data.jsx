// shared-data.jsx — Mock data + shared UI primitives

const C = {
  navy: '#1B2B5E',
  navyMid: '#243570',
  navyLight: '#2D3F72',
  blue: '#5B90C5',
  blueLight: '#D4E5F5',
  blueMid: '#A8C8E8',
  crimson: '#7D1C2C',
  crimsonLight: '#FCE8EA',
  bg: '#EEF2F9',
  surface: '#FFFFFF',
  border: '#DDE3F0',
  borderLight: '#EEF2F9',
  textPrimary: '#1B2B5E',
  textSecondary: '#5A6A8A',
  textMuted: '#8899BB',
  success: '#166534',
  successBg: '#DCFCE7',
  successMid: '#86EFAC',
  warning: '#92400E',
  warningBg: '#FEF3C7',
  danger: '#991B1B',
  dangerBg: '#FEE2E2',
  dangerMid: '#FCA5A5',
};

const STUDENTS = [
  { id: 1, name: 'Joshua Johnson',  initials: 'JJ', year: 'Y9',  tutor: 'Mrs Thompson', merits: { spend: 142, saving: 80,  investment: 95  }, tithe: 10, pacesCompleted: 8,  color: '#5B90C5' },
  { id: 2, name: 'Grace Williams',  initials: 'GW', year: 'Y8',  tutor: 'Mrs Thompson', merits: { spend: 238, saving: 150, investment: 200 }, tithe: 15, pacesCompleted: 12, color: '#7D3C98' },
  { id: 3, name: 'Samuel Okafor',   initials: 'SO', year: 'Y10', tutor: 'Mr Osei',      merits: { spend: 56,  saving: 20,  investment: 10  }, tithe: 10, pacesCompleted: 6,  color: '#1A7A4A' },
  { id: 4, name: 'Ruth Chen',       initials: 'RC', year: 'Y7',  tutor: 'Mrs Thompson', merits: { spend: 189, saving: 100, investment: 145 }, tithe: 20, pacesCompleted: 10, color: '#B45309' },
  { id: 5, name: 'Daniel Patel',    initials: 'DP', year: 'Y9',  tutor: 'Mr Osei',      merits: { spend: 67,  saving: 40,  investment: 0   }, tithe: 10, pacesCompleted: 7,  color: '#7D1C2C' },
  { id: 6, name: 'Esther Brown',    initials: 'EB', year: 'Y8',  tutor: 'Mrs Thompson', merits: { spend: 312, saving: 200, investment: 280 }, tithe: 15, pacesCompleted: 14, color: '#0E7490' },
  { id: 7, name: 'Caleb Smith',     initials: 'CS', year: 'Y10', tutor: 'Mr Osei',      merits: { spend: 94,  saving: 60,  investment: 45  }, tithe: 10, pacesCompleted: 9,  color: '#4338CA' },
  { id: 8, name: 'Hannah Davies',   initials: 'HD', year: 'Y7',  tutor: 'Mrs Thompson', merits: { spend: 175, saving: 120, investment: 160 }, tithe: 15, pacesCompleted: 11, color: '#BE185D' },
  { id: 9, name: 'Joseph Taylor',   initials: 'JT', year: 'Y9',  tutor: 'Mr Osei',      merits: { spend: 43,  saving: 15,  investment: 0   }, tithe: 10, pacesCompleted: 5,  color: '#065F46' },
  { id: 10,name: 'Faith Mensah',    initials: 'FM', year: 'Y8',  tutor: 'Mrs Thompson', merits: { spend: 267, saving: 180, investment: 220 }, tithe: 20, pacesCompleted: 13, color: '#9A3412' },
];

const ATTENDANCE_TODAY = { 1:'Present',2:'Present',3:'Absent',4:'Present',5:'Late',6:'Present',7:'Present',8:'Present',9:'Absent',10:'Present' };

const BEHAVIOUR_ENTRIES = [
  { id:1, studentId:2, studentName:'Grace Williams',  type:'Merit',   category:'Scripture Memory',    note:'Memorised Psalm 23 in full, word-perfect recitation',       delta:+10, visibility:'General',   recordedBy:'Mrs Thompson', time:'09:15' },
  { id:2, studentId:5, studentName:'Daniel Patel',    type:'Demerit', category:'Punctuality',          note:'Late to Morning Assembly without prior notification',        delta:-5,  visibility:'General',   recordedBy:'Mr Osei',      time:'09:02' },
  { id:3, studentId:6, studentName:'Esther Brown',    type:'Merit',   category:'Academic Excellence',  note:'Scored 95% on PACE 1097 Mathematics test',                  delta:+15, visibility:'General',   recordedBy:'Mrs Thompson', time:'10:45' },
  { id:4, studentId:1, studentName:'Joshua Johnson',  type:'Merit',   category:'Helpfulness',          note:'Assisted younger students during self-study session',        delta:+5,  visibility:'General',   recordedBy:'Mrs Thompson', time:'11:20' },
  { id:5, studentId:9, studentName:'Joseph Taylor',   type:'Demerit', category:'Conduct',              note:'Disruptive behaviour during quiet study period',             delta:-5,  visibility:'Sensitive', recordedBy:'Mr Osei',      time:'13:15' },
  { id:6, studentId:4, studentName:'Ruth Chen',       type:'Merit',   category:'Character',            note:'Displayed exceptional kindness and patience with a peer',   delta:+10, visibility:'General',   recordedBy:'Mrs Thompson', time:'14:00' },
];

const PACE_SUBJECTS = [
  { subject:'Mathematics',    paceNumber:1097, selfTest:88, paceTest:85, completedAt:'12 Apr',  status:'On Track' },
  { subject:'English',        paceNumber:1089, selfTest:92, paceTest:90, completedAt:'08 Apr',  status:'On Track' },
  { subject:'Bible',          paceNumber:1094, selfTest:100,paceTest:98, completedAt:'19 Apr',  status:'Ahead'    },
  { subject:'Science',        paceNumber:1086, selfTest:79, paceTest:76, completedAt:'03 Apr',  status:'On Track' },
  { subject:'Social Studies', paceNumber:1091, selfTest:85, paceTest:83, completedAt:'15 Apr',  status:'On Track' },
];

const MESSAGES = [
  { id:1, from:'Mrs Johnson',  role:'Parent of Joshua Johnson',  preview:"Quick question about Joshua's PACE 1097 algebra section — anything we can do at home?", time:'10:23', unread:true,  body:"Thank you for the update on Joshua's progress. I had a quick question about his PACE 1097 — is there anything we can do at home to support him? He's been finding the algebra section a bit challenging. We try to go over his notes in the evenings but would welcome any suggestions from you." },
  { id:2, from:'Mr Williams',  role:'Parent of Grace Williams',  preview:"Grace has a dentist appointment Thursday 28th — she will be ~30 mins late.", time:'Yesterday', unread:true,  body:"Grace has a dentist appointment on Thursday 28th April so she will arrive approximately 30 minutes late. I've already noted it on the absence form. Please let me know if you need anything else from my end." },
  { id:3, from:'Mrs Okafor',   role:'Parent of Samuel Okafor',   preview:"Wanted to discuss Samuel's recent behaviour entry when you have a moment.", time:'Mon', unread:false, body:"I wanted to discuss Samuel's recent behaviour entry with you when you have a moment. He mentioned feeling frustrated in the classroom and I think a conversation between all of us could help resolve things positively." },
];

const SHOP_CATEGORIES = [
  { id:'treats',      label:'Treats',      tint:'#FDF1E6', ink:'#9C5A2F' },
  { id:'privileges',  label:'Privileges',  tint:'#EAF1FB', ink:'#3B5F95' },
  { id:'stationery',  label:'Stationery',  tint:'#EFEEFA', ink:'#5E5BA8' },
  { id:'vouchers',    label:'Vouchers',    tint:'#E8F2EC', ink:'#356B4D' },
  { id:'merch',       label:'Merch',       tint:'#F6ECEE', ink:'#8E3F4C' },
  { id:'recognition', label:'Recognition', tint:'#FBF3D9', ink:'#7E6315' },
];

const SHOP_ITEMS = [
  // Treats
  { id:1,  category:'treats',      name:'Hot Chocolate',        blurb:'Mug of cocoa with a marshmallow',           price:25,  stock:20, lowAt:5,  active:true,  description:'A warm mug of cocoa, served at morning break by the shopkeeper. Includes one marshmallow. Allergens: milk.', sold:18 },
  { id:2,  category:'treats',      name:'Cookie Bundle',        blurb:'Two oatmeal cookies, kitchen-baked',        price:30,  stock:14, lowAt:5,  active:true,  description:'Two freshly-baked oatmeal cookies from the staff kitchen. Allergens: gluten, may contain nuts.', sold:9  },
  { id:3,  category:'treats',      name:'Fruit Smoothie',       blurb:'Banana & mixed berry, made Fridays',        price:40,  stock:8,  lowAt:5,  active:true,  description:'Fresh banana and mixed-berry smoothie, made to order on Fridays at morning break.', sold:6  },
  // Privileges
  { id:4,  category:'privileges',  name:'Extra Break Time',     blurb:'+15 minutes of break, any day',             price:75,  stock:5,  lowAt:3,  active:true,  description:'An additional 15 minutes of break time, redeemable any day except exam days. Hand the voucher to your supervisor at the start of break.', sold:3  },
  { id:5,  category:'privileges',  name:'Front-of-Line Lunch',  blurb:'Skip the queue, with one friend',           price:30,  stock:10, lowAt:5,  active:true,  description:'Skip the lunch queue once, with one friend of your choice. Redeemable Monday to Thursday.', sold:4  },
  { id:6,  category:'privileges',  name:'Choose Class Music',   blurb:'Pick the playlist for self-study',          price:50,  stock:6,  lowAt:3,  active:true,  description:'Pick the music played during one supervised self-study session. Must be screened by a supervisor in advance.', sold:2  },
  // Stationery
  { id:7,  category:'stationery',  name:'Stationery Pack',      blurb:'Notebook, pen, pencil, eraser, ruler',      price:50,  stock:12, lowAt:4,  active:true,  description:'A pack containing a softback notebook, ballpoint pen, HB pencil, eraser and 15cm ruler — all branded with the Oasis crest.', sold:11 },
  { id:8,  category:'stationery',  name:'Gel Pen Set',          blurb:'Six coloured gels for revision',            price:35,  stock:18, lowAt:5,  active:true,  description:'Set of six coloured gel pens. Ideal for revision notes and mind-maps.', sold:7  },
  { id:9,  category:'stationery',  name:'Highlighter Pack',     blurb:'Four pastel highlighters',                  price:20,  stock:0,  lowAt:5,  active:true,  description:'Pack of four pastel highlighters — yellow, pink, blue and green. Currently out of stock.', sold:14 },
  // Vouchers
  { id:10, category:'vouchers',    name:'Book Token',           blurb:'£5 for the school book fair',               price:100, stock:8,  lowAt:3,  active:true,  description:'A £5 voucher redeemable at the school book fair (held twice a term) or at the local Christian bookshop on Castle Street.', sold:5  },
  { id:11, category:'vouchers',    name:'Cinema Ticket',        blurb:'One standard weekday ticket',               price:150, stock:4,  lowAt:2,  active:true,  description:'One standard cinema ticket valid weekday afternoons at the Vue cinema. Vouchers issued in paper form.', sold:2  },
  // Merch
  { id:12, category:'merch',       name:'Oasis Hoodie',         blurb:'Embroidered crest, navy',                   price:300, stock:3,  lowAt:2,  active:false, description:'Embroidered Oasis Learning Centre hoodie in navy. Sizes XS–XL. Currently paused between restock cycles.', sold:6  },
  { id:13, category:'merch',       name:'Water Bottle',         blurb:'Stainless steel, 500ml',                    price:120, stock:9,  lowAt:3,  active:true,  description:'500ml stainless-steel water bottle with the Oasis crest etched on the side. Hand-wash only.', sold:4  },
  { id:14, category:'merch',       name:'Canvas Tote Bag',      blurb:'Off-white, embroidered crest',              price:80,  stock:7,  lowAt:3,  active:true,  description:'Heavy-cotton canvas tote in off-white with embroidered Oasis crest. Roughly 38 × 42cm.', sold:3  },
  // Recognition
  { id:15, category:'recognition', name:'Praise Postcard Home', blurb:'Hand-written by your supervisor',           price:10,  stock:50, lowAt:10, active:true,  description:'A hand-written postcard from your supervisor describing what you did well, posted to your home address within the week.', sold:23 },
  { id:16, category:'recognition', name:'Mention in Assembly',  blurb:'Your name read at Friday assembly',         price:40,  stock:30, lowAt:10, active:true,  description:'Your achievement is named and celebrated at Friday morning assembly in front of the whole centre.', sold:11 },
];

const SHOP_PICKUPS = [
  { id:1, studentId:2,  itemId:1,  qty:1, status:'Ready',     placed:'Today 09:14', by:null },
  { id:2, studentId:6,  itemId:7,  qty:1, status:'Ready',     placed:'Today 08:55', by:null },
  { id:3, studentId:4,  itemId:15, qty:1, status:'Collected', placed:'Yesterday',   by:'Mrs Thompson' },
  { id:4, studentId:8,  itemId:2,  qty:2, status:'Ready',     placed:'Today 10:30', by:null },
  { id:5, studentId:10, itemId:10, qty:1, status:'Ready',     placed:'Today 11:02', by:null },
  { id:6, studentId:1,  itemId:5,  qty:1, status:'Collected', placed:'Mon 21 Apr',  by:'Mr Osei' },
  { id:7, studentId:6,  itemId:13, qty:1, status:'Collected', placed:'Mon 21 Apr',  by:'Mrs Thompson' },
];

const CLUBS = [
  { id:1, name:'Drama Club',      day:'Tuesday',   time:'3:00–4:00pm', capacity:12, enrolled:8,  room:'Studio 1',     emoji:'🎭', accent:'#7D3C98',
    memberIds:[1,2,4,6,8,10,7,3],
    leadIds:['lead-hughes'],
    nextSession:'Tue 29 Apr · 3:00pm' },
  { id:2, name:'Chess Club',      day:'Wednesday', time:'1:00–2:00pm', capacity:10, enrolled:6,  room:'Library',      emoji:'♟', accent:'#1B2B5E',
    memberIds:[1,3,5,7,9,2],
    leadIds:['lead-hughes'],
    nextSession:'Wed 30 Apr · 1:00pm' },
  { id:3, name:'Art & Craft',     day:'Thursday',  time:'2:00–3:30pm', capacity:15, enrolled:11, room:'Studio 2',     emoji:'🎨', accent:'#B45309',
    memberIds:[2,4,6,8,10,3,5,7,9,12],
    leadIds:['lead-quinn'],
    nextSession:'Thu 1 May · 2:00pm' },
  { id:4, name:'Scripture Union', day:'Friday',    time:'8:30–9:00am', capacity:30, enrolled:16, room:'Main Hall',    emoji:'✝',  accent:'#0E7490',
    memberIds:[1,2,3,4,5,6,7,8,9,10],
    leadIds:['lead-quinn'],
    nextSession:'Fri 2 May · 8:30am' },
];

// Clubs Lead accounts — staff with limited access; only see Behaviour + Attendance + Noticeboard
// for clubs in `clubIds`. Cannot see other students, fees, PACE, leaderboard, etc.
const CLUB_LEADS = [
  { id:'lead-hughes', firstName:'David', lastName:'Hughes', initials:'DH', email:'hughes@oasis.school',
    color:'#0E5C3A', phone:'07700 905544', role:'Clubs Lead',
    clubIds:[1,2],  // Drama + Chess
    joined:'Sep 2023', twoFA:true },
  { id:'lead-quinn', firstName:'Hannah', lastName:'Quinn', initials:'HQ', email:'quinn@oasis.school',
    color:'#B45309', phone:'07700 906633', role:'Clubs Lead',
    clubIds:[3,4],  // Art & Craft + Scripture Union
    joined:'Jan 2024', twoFA:true },
];

// Current signed-in Clubs Lead (mock)
const ME_CLUB_LEAD = CLUB_LEADS[0];

// Per-club attendance for the most recent session.
// Status: 'Present' | 'Absent' | 'Late' | null (unmarked)
const CLUB_ATTENDANCE = {
  1: { // Drama — last session Tue 22 Apr
    sessionDate:'2026-04-22', sessionLabel:'Tue 22 Apr', marked:true,
    statuses:{ 1:'Present', 2:'Present', 3:'Absent', 4:'Present', 6:'Present', 7:'Late', 8:'Present', 10:'Present' },
  },
  2: { // Chess — last session Wed 23 Apr
    sessionDate:'2026-04-23', sessionLabel:'Wed 23 Apr', marked:true,
    statuses:{ 1:'Present', 2:'Present', 3:'Present', 5:'Absent', 7:'Present', 9:'Late' },
  },
  3: { sessionDate:'2026-04-24', sessionLabel:'Thu 24 Apr', marked:true,
    statuses:{ 1:'Present', 2:'Present', 3:'Present', 4:'Present', 5:'Present', 6:'Present', 7:'Absent', 8:'Present', 9:'Present', 10:'Present' } },
  4: { sessionDate:'2026-04-25', sessionLabel:'Fri 25 Apr', marked:false, statuses:{} },
};

// Club-scoped behaviour entries (kept separate from form-room BEHAVIOUR_ENTRIES so
// admins see the source). type can be Merit / Demerit / General (no point delta).
const CLUB_BEHAVIOUR_ENTRIES = [
  { id:101, clubId:1, studentId:2, studentName:'Grace Williams', type:'Merit',   category:'Leadership',     note:'Led warm-up exercises for the group with confidence.',           delta:+10, time:'Tue 22 Apr · 3:08pm', recordedBy:'Mr Hughes' },
  { id:102, clubId:1, studentId:4, studentName:'Ruth Chen',      type:'Merit',   category:'Creativity',     note:'Wrote a beautiful original monologue for the Spring showcase.', delta:+5,  time:'Tue 22 Apr · 3:42pm', recordedBy:'Mr Hughes' },
  { id:103, clubId:1, studentId:7, studentName:'Caleb Smith',    type:'Demerit', category:'Punctuality',    note:'Arrived 15 minutes late without notice — second time this month.', delta:-5, time:'Tue 22 Apr · 3:15pm', recordedBy:'Mr Hughes' },
  { id:104, clubId:2, studentId:1, studentName:'Joshua Johnson', type:'Merit',   category:'Sportsmanship',  note:'Gracious in defeat — congratulated opponent and asked for feedback.', delta:+5, time:'Wed 23 Apr · 1:45pm', recordedBy:'Mr Hughes' },
  { id:105, clubId:2, studentId:5, studentName:'Daniel Patel',   type:'General', category:'Tournament',     note:'Selected for the Birmingham Schools Chess Tournament — well done.', delta:0,  time:'Wed 23 Apr · 1:55pm', recordedBy:'Mr Hughes' },
  { id:106, clubId:1, studentId:6, studentName:'Esther Brown',   type:'General', category:'Role',           note:'Cast as the lead in the Spring showcase production.',            delta:0,  time:'Tue 22 Apr · 3:55pm', recordedBy:'Mr Hughes' },
];

// Notices posted by club leads — appear in parents' "My Clubs" tab for the relevant club.
const CLUB_NOTICES = [
  { id:201, clubId:1, title:'Spring Showcase — Saturday 17 May',
    body:'Our end-of-term Drama showcase is on Saturday 17 May at 4:00pm in the Main Hall. Doors open 3:30pm. Costumes and scripts have been sent home with the children — please help them rehearse over the next two weeks. Refreshments will be served after the performance.',
    author:'Mr Hughes', posted:'24 Apr 2026', pinned:true },
  { id:202, clubId:1, title:'Costume request — basic black outfit',
    body:'For the ensemble scenes we need every student in plain black trousers/leggings and a plain black top (no logos). If this is difficult to provide please email me and we will sort something out from the costume cupboard.',
    author:'Mr Hughes', posted:'22 Apr 2026', pinned:false },
  { id:203, clubId:2, title:'Birmingham Schools Chess Tournament — entries open',
    body:'Daniel Patel has been selected to represent Oasis at the Birmingham Schools Tournament on Saturday 10 May. We have two further spots available — please reply if your child is keen to take part. Entry is free and lunch is provided.',
    author:'Mr Hughes', posted:'23 Apr 2026', pinned:true },
  { id:204, clubId:2, title:'No Chess Club on Wed 7 May',
    body:'Just a heads-up — Chess Club will not run on Wednesday 7 May as the Library is being used for the GCSE mock exams. Sessions resume as normal on Wednesday 14 May.',
    author:'Mr Hughes', posted:'20 Apr 2026', pinned:false },
  { id:205, clubId:4, title:'Friday 2 May assembly led by Scripture Union',
    body:'The children have prepared a short presentation on Psalm 23 for Friday morning assembly. Parents are warmly invited to join us at 8:30am.',
    author:'Mrs Quinn', posted:'21 Apr 2026', pinned:false },
];

// Mock invoices — Spring Term 2026. studentId links to STUDENTS.
// "items" mimics what the OCR/parser pulled out of the PDF.
const INVOICES = [
  {
    id:'INV-2026-041', studentId:1, issued:'01 Apr 2026', due:'22 Apr 2026', paidOn:'19 Apr 2026',
    fileName:'Johnson_April_Fees.pdf', fileSize:'184 KB', status:'Paid', term:'Spring Term 2',
    items:[
      { desc:'Spring Term 2 tuition — Y9',     qty:1, unit:420.00, amount:420.00 },
      { desc:'PACE workbooks (×5)',             qty:5, unit:7.50,   amount:37.50 },
      { desc:'Lunch programme — half term',    qty:1, unit:65.00,  amount:65.00 },
    ], total:522.50,
  },
  {
    id:'INV-2026-067', studentId:1, issued:'24 Apr 2026', due:'15 May 2026', paidOn:null,
    fileName:'Johnson_May_Fees.pdf', fileSize:'176 KB', status:'Unpaid', term:'Spring Term 2',
    items:[
      { desc:'Spring Term 2 tuition — Y9',     qty:1, unit:420.00, amount:420.00 },
      { desc:'Drama Club residential trip',     qty:1, unit:85.00,  amount:85.00 },
      { desc:'Stationery resupply',             qty:1, unit:12.00,  amount:12.00 },
    ], total:517.00,
  },
  {
    id:'INV-2026-022', studentId:2, issued:'15 Mar 2026', due:'05 Apr 2026', paidOn:null,
    fileName:'Williams_March_Fees.pdf', fileSize:'192 KB', status:'Overdue', term:'Spring Term 1',
    items:[
      { desc:'Spring Term 1 tuition — Y8',     qty:1, unit:420.00, amount:420.00 },
      { desc:'PACE workbooks (×4)',             qty:4, unit:7.50,   amount:30.00 },
      { desc:'Exam entry fee — Cambridge KS3',  qty:1, unit:48.00,  amount:48.00 },
    ], total:498.00,
  },
  {
    id:'INV-2026-058', studentId:3, issued:'24 Apr 2026', due:'15 May 2026', paidOn:null,
    fileName:'Okafor_May_Fees.pdf', fileSize:'168 KB', status:'Unpaid', term:'Spring Term 2',
    items:[
      { desc:'Spring Term 2 tuition — Y10',    qty:1, unit:445.00, amount:445.00 },
      { desc:'GCSE prep workbook bundle',       qty:1, unit:38.00,  amount:38.00 },
    ], total:483.00,
  },
  {
    id:'INV-2026-039', studentId:4, issued:'01 Apr 2026', due:'22 Apr 2026', paidOn:'18 Apr 2026',
    fileName:'Chen_April_Fees.pdf', fileSize:'171 KB', status:'Paid', term:'Spring Term 2',
    items:[
      { desc:'Spring Term 2 tuition — Y7',     qty:1, unit:395.00, amount:395.00 },
      { desc:'Lunch programme — half term',    qty:1, unit:65.00,  amount:65.00 },
      { desc:'Art & Craft Club materials',      qty:1, unit:18.00,  amount:18.00 },
    ], total:478.00,
  },
  {
    id:'INV-2026-014', studentId:5, issued:'10 Feb 2026', due:'03 Mar 2026', paidOn:null,
    fileName:'Patel_February_Fees.pdf', fileSize:'180 KB', status:'Overdue', term:'Spring Term 1',
    items:[
      { desc:'Spring Term 1 tuition — Y9',     qty:1, unit:420.00, amount:420.00 },
      { desc:'PACE workbooks (×5)',             qty:5, unit:7.50,   amount:37.50 },
    ], total:457.50,
  },
];

// ── Permission Slips ──────────────────────────────────────────────────────
// Each slip is a form admins compose and send to a group of students.
// "responses" maps studentId → { status, parentName, signedAt, medicalInfo, emergency, declineReason }
// Status: 'signed' | 'declined' | 'pending' (no response yet)
// "deadline" determines whether the slip appears in Active (deadline ≥ today) or Inactive lists.

const TODAY = '2026-04-25';

const PERMISSION_SLIPS = [
  {
    id: 'PS-001',
    title: 'Howletts Wild Animal Park',
    category: 'School Trip',
    eventDate: '2026-06-05',
    deadline: '2026-05-18',
    issued: '2026-04-22',
    issuedBy: 'Mrs Thompson',
    recipients: 'Years 7–10',
    studentIds: [1,2,3,4,5,6,7,8,9,10],
    location: 'Howletts Wild Animal Park, Kent',
    transport: 'Minibus',
    departureTime: '09:00',
    returnTime: '15:00 (approx.)',
    cost: '£20',
    description: 'A day visit to support students\' learning in a fun and engaging environment, giving them the opportunity to observe a wide range of animals and learn more about wildlife conservation.',
    whatToBring: ['Packed lunch', 'Refillable water bottle', 'Sun protection (cream + hat)', 'Small backpack'],
    consentText: 'I give permission for my child to take part in this trip. I understand that my child will be travelling by minibus and will be supervised by school staff at all times.',
    requireMedical: true, requireEmergencyContact: true, requirePayment: true,
    responses: {
      1:  { status:'signed',   parentName:'Mr Robert Johnson',  signedAt:'24 Apr 2026 19:14', medicalInfo:'Mild hay-fever — antihistamine taken in morning.', emergency:'Sarah Johnson · 07700 902222 · Mother' },
      2:  { status:'signed',   parentName:'Mr A. Williams',     signedAt:'23 Apr 2026 08:30', medicalInfo:'None', emergency:'Mrs L. Williams · 07700 901456 · Mother' },
      3:  { status:'pending'   },
      4:  { status:'signed',   parentName:'Mrs P. Chen',        signedAt:'22 Apr 2026 21:02', medicalInfo:'Peanut allergy — carries EpiPen.', emergency:'Mr D. Chen · 07700 904512 · Father' },
      5:  { status:'declined', parentName:'Mr V. Patel',        signedAt:'24 Apr 2026 12:40', declineReason:'Family commitment that day — Daniel will be absent.' },
      6:  { status:'signed',   parentName:'Mrs J. Brown',       signedAt:'23 Apr 2026 17:55', medicalInfo:'None', emergency:'Mr K. Brown · 07700 907788 · Father' },
      7:  { status:'pending'  },
      8:  { status:'signed',   parentName:'Mr T. Davies',       signedAt:'24 Apr 2026 09:11', medicalInfo:'Asthma — blue inhaler in bag.', emergency:'Mrs M. Davies · 07700 908899 · Mother' },
      9:  { status:'pending'  },
      10: { status:'signed',   parentName:'Mrs B. Mensah',      signedAt:'23 Apr 2026 14:22', medicalInfo:'None', emergency:'Mr C. Mensah · 07700 906655 · Father' },
    },
  },
  {
    id: 'PS-002',
    title: 'Annual Photography Consent — 2025/26',
    category: 'Consent',
    eventDate: null,
    deadline: '2026-05-30',
    issued: '2026-04-15',
    issuedBy: 'Mrs Thompson',
    recipients: 'All families',
    studentIds: [1,2,3,4,5,6,7,8,9,10],
    location: null, transport: null, departureTime: null, returnTime: null, cost: null,
    description: 'We occasionally take photographs during lessons, performances and trips for use in our newsletter, social media and centre prospectus. This annual consent form lets you tell us where your child\'s image may appear.',
    whatToBring: [],
    consentText: 'I give consent for photographs of my child to be used in Oasis Learning Centre communications, including the website, newsletter, and printed prospectus. I understand I may withdraw this consent at any time in writing.',
    requireMedical: false, requireEmergencyContact: false, requirePayment: false,
    responses: {
      1: { status:'signed',   parentName:'Mr Robert Johnson',  signedAt:'17 Apr 2026 20:01' },
      2: { status:'signed',   parentName:'Mr A. Williams',     signedAt:'16 Apr 2026 19:33' },
      3: { status:'declined', parentName:'Mrs E. Okafor',      signedAt:'18 Apr 2026 11:12', declineReason:'We would prefer Samuel not to appear in published photographs.' },
      4: { status:'signed',   parentName:'Mrs P. Chen',        signedAt:'16 Apr 2026 08:44' },
      5: { status:'pending'  },
      6: { status:'signed',   parentName:'Mrs J. Brown',       signedAt:'17 Apr 2026 13:25' },
      7: { status:'pending'  },
      8: { status:'signed',   parentName:'Mr T. Davies',       signedAt:'19 Apr 2026 09:55' },
      9: { status:'pending'  },
      10:{ status:'signed',   parentName:'Mrs B. Mensah',      signedAt:'18 Apr 2026 21:18' },
    },
  },
  {
    id: 'PS-003',
    title: 'Swimming Lessons — Summer Block',
    category: 'Activity',
    eventDate: '2026-06-15',
    deadline: '2026-05-25',
    issued: '2026-04-20',
    issuedBy: 'Mr Osei',
    recipients: 'Years 7–9',
    studentIds: [1,2,4,5,6,8,9,10],
    location: 'Aston Newtown Pool',
    transport: 'Walking (5 min)',
    departureTime: '14:00',
    returnTime: '15:30',
    cost: '£35 (block of 6)',
    description: 'Weekly swimming sessions for the summer block — Mondays, 15 June through 20 July. Lessons are graded by ability and run by qualified ASA instructors.',
    whatToBring: ['Swimwear', 'Towel', 'Goggles (optional)', 'Swim cap (required for long hair)'],
    consentText: 'I give permission for my child to attend the swimming lessons block at Aston Newtown Pool and confirm they are well enough to take part.',
    requireMedical: true, requireEmergencyContact: false, requirePayment: true,
    responses: {
      1: { status:'pending' },
      2: { status:'signed',   parentName:'Mr A. Williams',  signedAt:'24 Apr 2026 18:01', medicalInfo:'None' },
      4: { status:'pending' },
      5: { status:'pending' },
      6: { status:'signed',   parentName:'Mrs J. Brown',    signedAt:'24 Apr 2026 21:09', medicalInfo:'Mild eczema — own cream brought from home.' },
      8: { status:'pending' },
      9: { status:'declined', parentName:'Mrs S. Taylor',   signedAt:'23 Apr 2026 19:30', declineReason:'Joseph is not a confident swimmer yet — will rejoin next block.' },
      10:{ status:'pending' },
    },
  },
  // ── INACTIVE (deadline already passed) ──
  {
    id: 'PS-004',
    title: 'Cadbury World — Spring Trip',
    category: 'School Trip',
    eventDate: '2026-04-02',
    deadline: '2026-03-25',
    issued: '2026-03-10',
    issuedBy: 'Mrs Thompson',
    recipients: 'Years 7–10',
    studentIds: [1,2,3,4,5,6,7,8,9,10],
    location: 'Cadbury World, Bournville',
    transport: 'Coach',
    departureTime: '08:45',
    returnTime: '16:30',
    cost: '£28',
    description: 'A full-day visit to Cadbury World — chocolate-making demonstrations, factory tour, and a workshop session.',
    whatToBring: ['Packed lunch', 'Refillable water bottle', 'Warm coat'],
    consentText: 'I give permission for my child to attend the Cadbury World trip on 2 April 2026.',
    requireMedical: true, requireEmergencyContact: true, requirePayment: true,
    responses: {
      1: { status:'signed',   parentName:'Mr Robert Johnson', signedAt:'18 Mar 2026' },
      2: { status:'signed',   parentName:'Mr A. Williams',    signedAt:'15 Mar 2026' },
      3: { status:'signed',   parentName:'Mrs E. Okafor',     signedAt:'19 Mar 2026' },
      4: { status:'signed',   parentName:'Mrs P. Chen',       signedAt:'14 Mar 2026' },
      5: { status:'signed',   parentName:'Mr V. Patel',       signedAt:'21 Mar 2026' },
      6: { status:'signed',   parentName:'Mrs J. Brown',      signedAt:'13 Mar 2026' },
      7: { status:'declined', parentName:'Mr R. Smith',       signedAt:'20 Mar 2026', declineReason:'Caleb unwell at time of trip.' },
      8: { status:'signed',   parentName:'Mr T. Davies',      signedAt:'17 Mar 2026' },
      9: { status:'pending'  },
      10:{ status:'signed',   parentName:'Mrs B. Mensah',     signedAt:'16 Mar 2026' },
    },
  },
  {
    id: 'PS-005',
    title: 'Cinema Reward Outing',
    category: 'Reward',
    eventDate: '2026-02-14',
    deadline: '2026-02-07',
    issued: '2026-01-20',
    issuedBy: 'Mr Osei',
    recipients: 'Merit Shop top earners (5 students)',
    studentIds: [2, 4, 6, 8, 10],
    location: 'Vue Cinema, Star City',
    transport: 'Minibus',
    departureTime: '13:30',
    returnTime: '17:30',
    cost: '150 merits',
    description: 'Reward outing for the top merit earners of Spring Term 1. Film selection: a recently-released family feature.',
    whatToBring: ['Pocket money (optional)'],
    consentText: 'I give permission for my child to attend the cinema reward outing on 14 February 2026.',
    requireMedical: false, requireEmergencyContact: true, requirePayment: false,
    responses: {
      2: { status:'signed',   parentName:'Mr A. Williams',  signedAt:'25 Jan 2026' },
      4: { status:'signed',   parentName:'Mrs P. Chen',     signedAt:'24 Jan 2026' },
      6: { status:'signed',   parentName:'Mrs J. Brown',    signedAt:'24 Jan 2026' },
      8: { status:'signed',   parentName:'Mr T. Davies',    signedAt:'26 Jan 2026' },
      10:{ status:'signed',   parentName:'Mrs B. Mensah',   signedAt:'25 Jan 2026' },
    },
  },
];

const NOTICES = [
  { id:1, title:'End-of-Term Reports — Deadline Reminder', body:'Please ensure all PACE scores and behaviour summaries are entered by Friday 9 May so reports can be compiled over the weekend.', author:'Mrs Thompson', posted:'25 Apr', readCount:6, totalStaff:8 },
  { id:2, title:'Merit Shop Opens — Spring Term', body:'The Merit Shop will open on Monday 28 April. Shopkeepers please ensure stock levels are updated in the system before then.', author:'Mrs Thompson', posted:'23 Apr', readCount:8, totalStaff:8 },
  { id:3, title:'Staff Training Day — 2 May', body:'There will be a staff training morning on Friday 2 May, 8:00–10:30am. Students arrive at the usual time of 9:00am.', author:'Mr Osei', posted:'20 Apr', readCount:7, totalStaff:8 },
];

// ── Shared UI Components ─────────────────────────────────────────────────────

const Avatar = ({ initials, size = 36, color }) => (
  <div style={{
    width: size, height: size, borderRadius: '50%',
    background: color || C.navy, color: '#fff', flexShrink: 0,
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    fontSize: size * 0.33, fontWeight: 700, letterSpacing: '-0.5px', userSelect: 'none',
  }}>{initials}</div>
);

const Badge = ({ children, variant = 'blue' }) => {
  const v = { blue:{bg:C.blueLight,c:C.navy}, crimson:{bg:C.crimsonLight,c:C.crimson}, green:{bg:C.successBg,c:C.success}, amber:{bg:C.warningBg,c:C.warning}, red:{bg:C.dangerBg,c:C.danger}, grey:{bg:'#F1F5F9',c:C.textSecondary} };
  const s = v[variant] || v.blue;
  return <span style={{ display:'inline-flex', alignItems:'center', padding:'3px 10px', borderRadius:20, fontSize:11, fontWeight:700, background:s.bg, color:s.c, whiteSpace:'nowrap', letterSpacing:'0.2px' }}>{children}</span>;
};

const Btn = ({ children, onClick, variant = 'primary', size = 'md', style: xs, disabled }) => {
  const [h, setH] = React.useState(false);
  const vs = { primary:{bg:h?'#9B2235':C.crimson,c:'#fff',border:'none'}, secondary:{bg:h?C.bg:C.surface,c:C.navy,border:`1.5px solid ${C.border}`}, ghost:{bg:h?C.bg:'transparent',c:C.navy,border:'none'}, navy:{bg:h?C.navyLight:C.navy,c:'#fff',border:'none'}, blue:{bg:h?'#4A7DB5':C.blue,c:'#fff',border:'none'} };
  const ss = { sm:{p:'5px 12px',fs:12}, md:{p:'9px 18px',fs:13}, lg:{p:'12px 24px',fs:15} };
  const sv = vs[variant] || vs.primary; const sz = ss[size] || ss.md;
  return <button onClick={onClick} disabled={disabled} onMouseEnter={()=>setH(true)} onMouseLeave={()=>setH(false)} style={{ padding:sz.p, fontSize:sz.fs, background:sv.bg, color:sv.c, border:sv.border, borderRadius:8, fontWeight:600, cursor:disabled?'not-allowed':'pointer', fontFamily:'inherit', transition:'all 0.15s', display:'inline-flex', alignItems:'center', gap:6, opacity:disabled?0.5:1, ...xs }}>{children}</button>;
};

const Card = ({ children, style: xs, padding = 20 }) => (
  <div style={{ background:C.surface, borderRadius:12, padding, boxShadow:'0 1px 3px rgba(0,0,0,0.06)', border:`1px solid ${C.border}`, ...xs }}>{children}</div>
);

const StatCard = ({ label, value, sub, accent, icon }) => (
  <Card style={{ borderTop:`3px solid ${accent || C.blue}` }}>
    <p style={{ fontSize:11, fontWeight:700, color:C.textSecondary, textTransform:'uppercase', letterSpacing:'0.6px', marginBottom:8 }}>{label}</p>
    <p style={{ fontSize:30, fontWeight:800, color:accent || C.navy, lineHeight:1 }}>{value}</p>
    {sub && <p style={{ fontSize:12, color:C.textMuted, marginTop:6 }}>{sub}</p>}
  </Card>
);

const Divider = ({ style: xs }) => <div style={{ height:1, background:C.border, ...xs }} />;

const Input = ({ label, value, onChange, placeholder, type='text', style: xs }) => (
  <div style={{ ...xs }}>
    {label && <label style={{ fontSize:12, fontWeight:600, color:C.textSecondary, display:'block', marginBottom:5 }}>{label}</label>}
    <input value={value} onChange={onChange} placeholder={placeholder} type={type} style={{ width:'100%', padding:'9px 12px', border:`1.5px solid ${C.border}`, borderRadius:8, fontSize:13, fontFamily:'inherit', color:C.textPrimary, outline:'none', background:C.surface }} />
  </div>
);

const Select = ({ label, value, onChange, options, style: xs }) => (
  <div style={{ ...xs }}>
    {label && <label style={{ fontSize:12, fontWeight:600, color:C.textSecondary, display:'block', marginBottom:5 }}>{label}</label>}
    <select value={value} onChange={onChange} style={{ width:'100%', padding:'9px 12px', border:`1.5px solid ${C.border}`, borderRadius:8, fontSize:13, fontFamily:'inherit', color:C.textPrimary, background:C.surface, outline:'none' }}>
      {options.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
    </select>
  </div>
);

Object.assign(window, {
  C, STUDENTS, ATTENDANCE_TODAY, BEHAVIOUR_ENTRIES, PACE_SUBJECTS, MESSAGES,
  SHOP_ITEMS, SHOP_CATEGORIES, SHOP_PICKUPS, CLUBS, NOTICES, INVOICES, PERMISSION_SLIPS, TODAY,
  CLUB_LEADS, ME_CLUB_LEAD, CLUB_ATTENDANCE, CLUB_BEHAVIOUR_ENTRIES, CLUB_NOTICES,
  MY_CHILD: STUDENTS[0],
  Avatar, Badge, Btn, Card, StatCard, Divider, Input, Select,
});
