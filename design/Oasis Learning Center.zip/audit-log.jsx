// audit-log.jsx — Admin Audit Log
// Tracks every meaningful action on the portal: behaviour entries, PACE scores,
// attendance changes, shop transactions, reports sent, messages, notice posts,
// profile / permission edits, and security events.

// ── Mock audit data ──────────────────────────────────────────────────────────
// Categories drive both the filter chips and the colour of the type badge.
const AUDIT_CATEGORIES = [
  { id: 'behaviour',   label: 'Behaviour',   tone: 'crimson' },
  { id: 'pace',        label: 'PACE',        tone: 'blue'    },
  { id: 'attendance',  label: 'Attendance',  tone: 'green'   },
  { id: 'shop',        label: 'Merit Shop',  tone: 'amber'   },
  { id: 'messages',    label: 'Messages',    tone: 'blue'    },
  { id: 'reports',     label: 'Reports',     tone: 'navy'    },
  { id: 'noticeboard', label: 'Noticeboard', tone: 'navy'    },
  { id: 'profiles',    label: 'Profiles',    tone: 'grey'    },
  { id: 'security',    label: 'Security',    tone: 'red'     },
];

const AUDIT_ACTIONS = ['Created', 'Updated', 'Deleted', 'Viewed', 'Sent', 'Marked', 'Posted', 'Sign-in'];

const AUDIT_ACTORS = [
  { id: 'mt',  name: 'Mrs Thompson', initials: 'MT', role: 'Head of Centre', color: '#1B2B5E' },
  { id: 'mo',  name: 'Mr Osei',      initials: 'MO', role: 'Supervisor',     color: '#7D1C2C' },
  { id: 'sys', name: 'System',       initials: 'SY', role: 'Automation',     color: '#5A6A8A' },
];

// 38 sample events across the last 3 days. Time ordered newest → oldest.
const AUDIT_EVENTS = [
  // ── Today, 25 April 2026 ─────────────────────────────────────────────────
  { id:'a38', day:'Today',     time:'14:32', actor:'mt',  category:'behaviour',   action:'Created',  summary:'Awarded +10 Merit — Character',                            target:'Ruth Chen',         targetId:4,  note:'Displayed exceptional kindness and patience with a peer', meta:{ entry:'#BH-2026-0421', delta:'+10', visibility:'General' } },
  { id:'a37', day:'Today',     time:'14:28', actor:'mt',  category:'pace',        action:'Updated',  summary:'Recorded PACE Test score · 88%',                          target:'Joshua Johnson',    targetId:1,  meta:{ subject:'Mathematics', pace:'#1097', from:'—', to:'88%' } },
  { id:'a36', day:'Today',     time:'13:55', actor:'sys', category:'shop',        action:'Created',  summary:'Pickup order placed by parent · Hot Chocolate × 1',       target:'Grace Williams',    targetId:2,  meta:{ price:'25 m', balance:'213 m' } },
  { id:'a35', day:'Today',     time:'13:20', actor:'mo',  category:'behaviour',   action:'Created',  summary:'Logged −5 Demerit — Conduct',                              target:'Joseph Taylor',     targetId:9,  note:'Disruptive behaviour during quiet study period', meta:{ entry:'#BH-2026-0420', delta:'−5', visibility:'Sensitive' }, sensitive:true },
  { id:'a34', day:'Today',     time:'13:15', actor:'mo',  category:'behaviour',   action:'Viewed',   summary:'Opened sensitive behaviour entry',                        target:'Joseph Taylor',     targetId:9,  meta:{ entry:'#BH-2026-0420' }, sensitive:true },
  { id:'a33', day:'Today',     time:'12:48', actor:'mt',  category:'reports',     action:'Sent',     summary:'Sent Spring Term 2 report to parent',                     target:'Faith Mensah',      targetId:10, meta:{ recipient:'parent@oasis.school', size:'2 pages' } },
  { id:'a32', day:'Today',     time:'12:14', actor:'mt',  category:'messages',    action:'Sent',     summary:'Replied to message from Mrs Johnson',                     target:'Joshua Johnson',    targetId:1,  meta:{ thread:'#MSG-204' } },
  { id:'a31', day:'Today',     time:'11:42', actor:'mt',  category:'behaviour',   action:'Updated',  summary:'Edited note on existing merit entry',                     target:'Joshua Johnson',    targetId:1,  note:'Note changed from "Helped peer" → "Assisted younger students during self-study session"', meta:{ entry:'#BH-2026-0418', field:'note' } },
  { id:'a30', day:'Today',     time:'11:20', actor:'mt',  category:'behaviour',   action:'Created',  summary:'Awarded +5 Merit — Helpfulness',                          target:'Joshua Johnson',    targetId:1,  note:'Assisted younger students during self-study session', meta:{ entry:'#BH-2026-0418', delta:'+5' } },
  { id:'a29', day:'Today',     time:'11:05', actor:'mo',  category:'shop',        action:'Marked',   summary:'Marked pickup as Collected · Front-of-Line Lunch',        target:'Joshua Johnson',    targetId:1,  meta:{ pickup:'#PK-2026-0086', collectedBy:'Mr Osei' } },
  { id:'a28', day:'Today',     time:'10:51', actor:'mt',  category:'shop',        action:'Updated',  summary:'Set stock to 0 · Highlighter Pack',                       target:null,                meta:{ item:'#SH-009', from:'4', to:'0', reason:'Restock pending' } },
  { id:'a27', day:'Today',     time:'10:45', actor:'mt',  category:'pace',        action:'Updated',  summary:'Recorded PACE Test score · 95%',                          target:'Esther Brown',      targetId:6,  meta:{ subject:'Mathematics', pace:'#1097', from:'—', to:'95%' } },
  { id:'a26', day:'Today',     time:'10:23', actor:'sys', category:'messages',    action:'Created',  summary:'Inbound message from parent',                             target:'Joshua Johnson',    targetId:1,  meta:{ from:'Mrs Johnson', thread:'#MSG-204' } },
  { id:'a25', day:'Today',     time:'09:35', actor:'mt',  category:'attendance',  action:'Marked',   summary:'Saved morning register · 25 April',                       target:null,                meta:{ present:7, late:1, absent:2, total:10 } },
  { id:'a24', day:'Today',     time:'09:34', actor:'mt',  category:'attendance',  action:'Updated',  summary:'Marked attendance Late',                                  target:'Daniel Patel',      targetId:5,  meta:{ from:'Present', to:'Late' } },
  { id:'a23', day:'Today',     time:'09:33', actor:'mt',  category:'attendance',  action:'Updated',  summary:'Marked attendance Absent',                                target:'Joseph Taylor',     targetId:9,  meta:{ from:'Present', to:'Absent' } },
  { id:'a22', day:'Today',     time:'09:15', actor:'mt',  category:'behaviour',   action:'Created',  summary:'Awarded +10 Merit — Scripture Memory',                    target:'Grace Williams',    targetId:2,  note:'Memorised Psalm 23 in full, word-perfect recitation', meta:{ entry:'#BH-2026-0415', delta:'+10' } },
  { id:'a21', day:'Today',     time:'09:02', actor:'mo',  category:'behaviour',   action:'Created',  summary:'Logged −5 Demerit — Punctuality',                          target:'Daniel Patel',      targetId:5,  note:'Late to Morning Assembly without prior notification', meta:{ entry:'#BH-2026-0414', delta:'−5' } },
  { id:'a20', day:'Today',     time:'08:47', actor:'mt',  category:'security',    action:'Sign-in',  summary:'Signed in successfully · 2FA verified',                   target:null,                meta:{ ip:'82.14.116.4', device:'MacBook · Safari', location:'Birmingham, UK' } },
  { id:'a19', day:'Today',     time:'08:41', actor:'mo',  category:'security',    action:'Sign-in',  summary:'Signed in successfully · 2FA verified',                   target:null,                meta:{ ip:'82.14.116.9', device:'iPad · Mobile Safari', location:'Birmingham, UK' } },

  // ── Yesterday, 24 April 2026 ─────────────────────────────────────────────
  { id:'a18', day:'Yesterday', time:'16:48', actor:'mt',  category:'profiles',    action:'Updated',  summary:'Granted permission tag · leaderboard-admin',              target:'Mr Osei',           meta:{ field:'tags', from:'—', to:'leaderboard-admin' } },
  { id:'a17', day:'Yesterday', time:'15:30', actor:'mt',  category:'reports',     action:'Sent',     summary:'Sent Spring Term 2 report to parent',                     target:'Caleb Smith',       targetId:7,  meta:{ recipient:'caleb.smith.parent@oasis.school' } },
  { id:'a16', day:'Yesterday', time:'15:12', actor:'mt',  category:'reports',     action:'Updated',  summary:'Saved draft report',                                      target:'Daniel Patel',      targetId:5,  meta:{ status:'Draft' } },
  { id:'a15', day:'Yesterday', time:'14:20', actor:'mo',  category:'pace',        action:'Updated',  summary:'Recorded Self-Test score · 79%',                          target:'Samuel Okafor',     targetId:3,  meta:{ subject:'Science', pace:'#1086', from:'—', to:'79%' } },
  { id:'a14', day:'Yesterday', time:'13:55', actor:'mt',  category:'shop',        action:'Created',  summary:'Issued refund · 30 merits to Spend Account',              target:'Hannah Davies',     targetId:8,  meta:{ reason:'Order cancelled — out of stock', balance:'175 m' } },
  { id:'a13', day:'Yesterday', time:'12:30', actor:'mt',  category:'behaviour',   action:'Deleted',  summary:'Removed merit entry (logged in error)',                    target:'Joshua Johnson',    targetId:1,  note:'Reason: duplicate entry from morning register', meta:{ entry:'#BH-2026-0411', delta:'+5' } },
  { id:'a12', day:'Yesterday', time:'11:18', actor:'mt',  category:'noticeboard', action:'Posted',   summary:'Posted notice — End-of-Term Reports Deadline',            target:null,                meta:{ notice:'#NT-12', audience:'All staff', readCount:'6/8' } },
  { id:'a11', day:'Yesterday', time:'10:42', actor:'mo',  category:'shop',        action:'Marked',   summary:'Marked pickup as Collected · Praise Postcard',            target:'Ruth Chen',         targetId:4,  meta:{ pickup:'#PK-2026-0079' } },
  { id:'a10', day:'Yesterday', time:'10:15', actor:'mo',  category:'behaviour',   action:'Created',  summary:'Awarded +5 Merit — Helpfulness',                          target:'Hannah Davies',     targetId:8,  note:'Tidied the supervised study area unprompted', meta:{ entry:'#BH-2026-0408', delta:'+5' } },
  { id:'a09', day:'Yesterday', time:'09:30', actor:'mt',  category:'attendance',  action:'Marked',   summary:'Saved morning register · 24 April',                       target:null,                meta:{ present:9, late:0, absent:1, total:10 } },

  // ── Wednesday, 23 April 2026 ─────────────────────────────────────────────
  { id:'a08', day:'Wed 23 Apr', time:'16:05', actor:'mt', category:'profiles',    action:'Updated',  summary:'Edited profile · phone number',                            target:'Mrs Thompson',      meta:{ field:'phone', from:'07700 900119', to:'07700 900123' } },
  { id:'a07', day:'Wed 23 Apr', time:'14:42', actor:'mt', category:'security',    action:'Updated',  summary:'2FA secret rotated for own account',                       target:'Mrs Thompson',      meta:{ method:'Authenticator app' } },
  { id:'a06', day:'Wed 23 Apr', time:'13:30', actor:'mt', category:'noticeboard', action:'Posted',   summary:'Posted notice — Merit Shop Opens',                         target:null,                meta:{ notice:'#NT-11', audience:'All staff' } },
  { id:'a05', day:'Wed 23 Apr', time:'12:08', actor:'mo', category:'pace',        action:'Updated',  summary:'Recorded PACE Test score · 76%',                           target:'Samuel Okafor',     targetId:3,  meta:{ subject:'Science', pace:'#1086', from:'—', to:'76%' } },
  { id:'a04', day:'Wed 23 Apr', time:'11:14', actor:'sys', category:'security',   action:'Sign-in',  summary:'Failed sign-in attempt · wrong password',                  target:'parent@oasis.school', meta:{ ip:'90.211.4.88', attempts:'2 of 5', location:'Manchester, UK' }, sensitive:true },
  { id:'a03', day:'Wed 23 Apr', time:'10:55', actor:'mt', category:'shop',        action:'Created',  summary:'Added new shop item · Cookie Bundle',                      target:null,                meta:{ item:'#SH-002', price:'30 m', stock:'14' } },
  { id:'a02', day:'Wed 23 Apr', time:'09:22', actor:'mt', category:'behaviour',   action:'Updated',  summary:'Changed visibility General → Sensitive',                   target:'Joseph Taylor',     targetId:9,  meta:{ entry:'#BH-2026-0395', field:'visibility', from:'General', to:'Sensitive' }, sensitive:true },
  { id:'a01', day:'Wed 23 Apr', time:'08:50', actor:'mt', category:'security',    action:'Sign-in',  summary:'Signed in successfully · 2FA verified',                   target:null,                meta:{ ip:'82.14.116.4', device:'MacBook · Safari', location:'Birmingham, UK' } },
];

// ── Helpers ──────────────────────────────────────────────────────────────────
const catLookup = Object.fromEntries(AUDIT_CATEGORIES.map(c => [c.id, c]));
const actorLookup = Object.fromEntries(AUDIT_ACTORS.map(a => [a.id, a]));

// Map action verbs to small coloured dot accents
const actionAccent = {
  Created:  C.success,
  Updated:  C.blue,
  Deleted:  C.danger,
  Viewed:   C.textMuted,
  Sent:     C.navy,
  Marked:   C.success,
  Posted:   C.navy,
  'Sign-in':C.warning,
};

// ── Audit Log Page ───────────────────────────────────────────────────────────
const AdminAuditLog = ({ mobile }) => {
  const { useState, useMemo } = React;

  const [search,    setSearch]    = useState('');
  const [cats,      setCats]      = useState(new Set()); // empty = all
  const [actor,     setActor]     = useState('all');
  const [studentId, setStudentId] = useState('all');
  const [action,    setAction]    = useState('all');
  const [range,     setRange]     = useState('7d');     // today | 7d | 30d | all
  const [sensOnly,  setSensOnly]  = useState(false);
  const [expanded,  setExpanded]  = useState(null);

  // Filtering ────────────────────────────────────────────────────────────────
  const filtered = useMemo(() => {
    const dayBuckets = {
      today: ['Today'],
      '7d':  ['Today','Yesterday','Wed 23 Apr'],
      '30d': ['Today','Yesterday','Wed 23 Apr'],
      all:   null,
    };
    const allowedDays = dayBuckets[range];

    return AUDIT_EVENTS.filter(e => {
      if (allowedDays && !allowedDays.includes(e.day)) return false;
      if (cats.size && !cats.has(e.category)) return false;
      if (actor !== 'all' && e.actor !== actor) return false;
      if (studentId !== 'all' && String(e.targetId) !== studentId) return false;
      if (action !== 'all' && e.action !== action) return false;
      if (sensOnly && !e.sensitive) return false;
      if (search) {
        const q = search.toLowerCase();
        const hay = [e.summary, e.target, e.note, ...(Object.values(e.meta||{}))]
          .filter(Boolean).join(' ').toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
  }, [search, cats, actor, studentId, action, range, sensOnly]);

  // Group filtered events by day for the timeline
  const grouped = useMemo(() => {
    const g = {};
    filtered.forEach(e => { (g[e.day] = g[e.day] || []).push(e); });
    return g;
  }, [filtered]);

  // Stat-strip computations (always against full window, not the current filter)
  const stats = useMemo(() => {
    const today = AUDIT_EVENTS.filter(e => e.day === 'Today');
    return {
      today: today.length,
      sensitive: AUDIT_EVENTS.filter(e => e.action === 'Viewed' && e.sensitive).length
              + AUDIT_EVENTS.filter(e => e.sensitive && e.action !== 'Viewed').length,
      edits: AUDIT_EVENTS.filter(e => e.action === 'Updated' || e.action === 'Deleted').length,
      failed: AUDIT_EVENTS.filter(e => e.category === 'security' && /Failed/.test(e.summary)).length,
    };
  }, []);

  const toggleCat = (id) => {
    setCats(prev => {
      const n = new Set(prev);
      if (n.has(id)) n.delete(id); else n.add(id);
      return n;
    });
  };

  const clearFilters = () => {
    setSearch(''); setCats(new Set()); setActor('all'); setStudentId('all');
    setAction('all'); setRange('7d'); setSensOnly(false);
  };

  const activeFilterCount =
    (search ? 1 : 0) + cats.size +
    (actor !== 'all' ? 1 : 0) + (studentId !== 'all' ? 1 : 0) +
    (action !== 'all' ? 1 : 0) + (range !== '7d' ? 1 : 0) +
    (sensOnly ? 1 : 0);

  // ─── render ───────────────────────────────────────────────────────────────
  return (
    <div className="page-fade">
      {/* Header */}
      <div style={{ display:'flex', alignItems:'flex-start', justifyContent:'space-between', marginBottom:18, flexWrap:'wrap', gap:12 }}>
        <div>
          <p style={{ fontSize:13, color:C.textSecondary }}>Friday, 25 April 2026 · Head of Centre access only</p>
          <h2 style={{ fontSize:mobile?20:26, fontWeight:800, color:C.navy, marginTop:2, letterSpacing:'-0.3px' }}>Audit Log</h2>
          <p style={{ fontSize:13, color:C.textSecondary, marginTop:4, maxWidth:560 }}>
            Every action on the portal — who logged a merit, edited a note, marked attendance, ran a report. Retained for 7 years per safeguarding policy.
          </p>
        </div>
        <div style={{ display:'flex', gap:8, flexWrap:'wrap' }}>
          <Btn variant="secondary" size="sm">
            <svg width={13} height={13} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" style={{ marginRight:1 }}><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4M7 10l5 5 5-5M12 15V3"/></svg>
            Export CSV
          </Btn>
          <Btn variant="navy" size="sm">View Retention Policy</Btn>
        </div>
      </div>

      {/* Stat strip */}
      <div style={{ display:'grid', gridTemplateColumns:mobile?'1fr 1fr':'repeat(4,1fr)', gap:12, marginBottom:18 }}>
        <StatCard label="Events Today"     value={stats.today}     sub="across all staff"        accent={C.blue}    />
        <StatCard label="Sensitive Access" value={stats.sensitive} sub="views + actions"          accent={C.warning} />
        <StatCard label="Edits & Deletes"  value={stats.edits}     sub="last 7 days"              accent={C.crimson} />
        <StatCard label="Failed Sign-ins"  value={stats.failed}    sub="last 7 days · review"     accent={C.danger}  />
      </div>

      {/* Filter bar */}
      <Card padding={16} style={{ marginBottom:14 }}>
        {/* Row 1 — search + range + actor + student + action + sensitive */}
        <div style={{ display:'grid', gridTemplateColumns:mobile?'1fr':'minmax(220px,1fr) 200px 180px 180px 160px auto', gap:10, alignItems:'end' }}>
          <div>
            <label style={{ fontSize:11, fontWeight:700, color:C.textSecondary, display:'block', marginBottom:5, textTransform:'uppercase', letterSpacing:'0.5px' }}>Search</label>
            <div style={{ position:'relative' }}>
              <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke={C.textMuted} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" style={{ position:'absolute', left:10, top:'50%', transform:'translateY(-50%)' }}><circle cx={11} cy={11} r={8}/><path d="M21 21l-4.35-4.35"/></svg>
              <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search notes, names, IDs…"
                style={{ width:'100%', padding:'9px 12px 9px 32px', border:`1.5px solid ${C.border}`, borderRadius:8, fontSize:13, fontFamily:'inherit', color:C.textPrimary, outline:'none', background:C.surface }} />
            </div>
          </div>

          <div>
            <label style={{ fontSize:11, fontWeight:700, color:C.textSecondary, display:'block', marginBottom:5, textTransform:'uppercase', letterSpacing:'0.5px' }}>Date range</label>
            <div style={{ display:'flex', background:C.bg, borderRadius:8, padding:3, gap:2 }}>
              {[['today','Today'],['7d','7 days'],['30d','30 days'],['all','All']].map(([id,l])=>(
                <button key={id} onClick={()=>setRange(id)} style={{ flex:1, padding:'7px 4px', border:'none', borderRadius:6, background: range===id ? C.navy : 'transparent', color: range===id ? '#fff' : C.textSecondary, fontWeight:700, fontSize:11, cursor:'pointer', fontFamily:'inherit', transition:'all 0.12s' }}>{l}</button>
              ))}
            </div>
          </div>

          <Select label="Actor" value={actor} onChange={e=>setActor(e.target.value)}
            options={[{value:'all',label:'All staff'}, ...AUDIT_ACTORS.map(a=>({value:a.id,label:a.name}))]} />

          <Select label="Student" value={studentId} onChange={e=>setStudentId(e.target.value)}
            options={[{value:'all',label:'All students'}, ...STUDENTS.map(s=>({value:String(s.id),label:s.name}))]} />

          <Select label="Action" value={action} onChange={e=>setAction(e.target.value)}
            options={[{value:'all',label:'Any action'}, ...AUDIT_ACTIONS.map(a=>({value:a,label:a}))]} />

          <button onClick={()=>setSensOnly(s=>!s)} style={{
            padding:'9px 12px', border:`1.5px solid ${sensOnly ? C.warning : C.border}`, borderRadius:8,
            background: sensOnly ? C.warningBg : C.surface, color: sensOnly ? C.warning : C.textSecondary,
            fontWeight:700, fontSize:12, cursor:'pointer', fontFamily:'inherit',
            display:'flex', alignItems:'center', gap:6, whiteSpace:'nowrap', height:38,
          }}>
            <svg width={13} height={13} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round"><rect x={3} y={11} width={18} height={11} rx={2}/><path d="M7 11V7a5 5 0 0110 0v4"/></svg>
            Sensitive only
          </button>
        </div>

        {/* Row 2 — category chips */}
        <div style={{ display:'flex', flexWrap:'wrap', gap:6, marginTop:14, alignItems:'center' }}>
          <span style={{ fontSize:11, fontWeight:700, color:C.textSecondary, textTransform:'uppercase', letterSpacing:'0.5px', marginRight:4 }}>Type:</span>
          <button onClick={()=>setCats(new Set())} style={{
            padding:'5px 12px', borderRadius:20, border:`1.5px solid ${cats.size===0 ? C.navy : C.border}`,
            background: cats.size===0 ? C.navy : C.surface, color: cats.size===0 ? '#fff' : C.textSecondary,
            fontWeight:700, fontSize:11, cursor:'pointer', fontFamily:'inherit',
          }}>All</button>
          {AUDIT_CATEGORIES.map(c => {
            const on = cats.has(c.id);
            return (
              <button key={c.id} onClick={()=>toggleCat(c.id)} style={{
                padding:'5px 12px', borderRadius:20,
                border:`1.5px solid ${on ? C.navy : C.border}`,
                background: on ? C.navy : C.surface,
                color: on ? '#fff' : C.textSecondary,
                fontWeight:700, fontSize:11, cursor:'pointer', fontFamily:'inherit',
                display:'inline-flex', alignItems:'center', gap:6, transition:'all 0.12s',
              }}>
                <span style={{ width:7, height:7, borderRadius:'50%', background: c.tone==='crimson'?C.crimson : c.tone==='blue'?C.blue : c.tone==='green'?C.success : c.tone==='amber'?C.warning : c.tone==='red'?C.danger : c.tone==='navy'?(on?'#fff':C.navy) : C.textMuted, opacity: on?1:0.85 }} />
                {c.label}
              </button>
            );
          })}
          {activeFilterCount > 0 && (
            <button onClick={clearFilters} style={{
              marginLeft:'auto', padding:'5px 12px', borderRadius:20, border:'none',
              background:'transparent', color:C.crimson, fontWeight:700, fontSize:11,
              cursor:'pointer', fontFamily:'inherit', display:'inline-flex', alignItems:'center', gap:5,
            }}>
              <svg width={11} height={11} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2.5} strokeLinecap="round"><path d="M18 6L6 18M6 6l12 12"/></svg>
              Clear {activeFilterCount} filter{activeFilterCount===1?'':'s'}
            </button>
          )}
        </div>
      </Card>

      {/* Results header */}
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:8, padding:'0 4px' }}>
        <p style={{ fontSize:12, fontWeight:700, color:C.textSecondary, letterSpacing:'0.3px' }}>
          {filtered.length} event{filtered.length===1?'':'s'} {activeFilterCount > 0 ? '· filtered' : '· last 7 days'}
        </p>
        <p style={{ fontSize:11, color:C.textMuted }}>Newest first · times in Europe/London</p>
      </div>

      {/* Timeline / table */}
      {filtered.length === 0 ? (
        <Card padding={48} style={{ textAlign:'center' }}>
          <div style={{ width:48, height:48, borderRadius:24, background:C.bg, display:'inline-flex', alignItems:'center', justifyContent:'center', marginBottom:12 }}>
            <svg width={22} height={22} viewBox="0 0 24 24" fill="none" stroke={C.textMuted} strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round"><circle cx={11} cy={11} r={8}/><path d="M21 21l-4.35-4.35"/></svg>
          </div>
          <p style={{ fontSize:14, fontWeight:700, color:C.navy }}>No events match these filters</p>
          <p style={{ fontSize:12, color:C.textSecondary, marginTop:4 }}>Try widening the date range or clearing a chip.</p>
        </Card>
      ) : (
        <div style={{ display:'flex', flexDirection:'column', gap:18 }}>
          {Object.keys(grouped).map(day => (
            <div key={day}>
              {/* Day divider */}
              <div style={{ display:'flex', alignItems:'center', gap:10, marginBottom:8, padding:'0 4px' }}>
                <p style={{ fontSize:11, fontWeight:800, color:C.navy, textTransform:'uppercase', letterSpacing:'0.6px' }}>{day}</p>
                <div style={{ flex:1, height:1, background:C.border }} />
                <p style={{ fontSize:11, color:C.textMuted, fontWeight:600 }}>{grouped[day].length} event{grouped[day].length===1?'':'s'}</p>
              </div>

              {/* Events */}
              <Card padding={0}>
                {grouped[day].map((e, idx) => {
                  const a = actorLookup[e.actor];
                  const cat = catLookup[e.category];
                  const isOpen = expanded === e.id;
                  const stripeColor = actionAccent[e.action] || C.textMuted;

                  return (
                    <div key={e.id} style={{ borderBottom: idx < grouped[day].length-1 ? `1px solid ${C.borderLight}` : 'none' }}>
                      {/* Row */}
                      <div
                        onClick={()=>setExpanded(isOpen ? null : e.id)}
                        style={{
                          display:'grid',
                          gridTemplateColumns: mobile ? 'auto 1fr auto' : '60px 28px auto auto 1fr auto auto',
                          gap: mobile ? 10 : 12,
                          alignItems:'center',
                          padding: mobile ? '12px 14px' : '12px 16px',
                          cursor:'pointer',
                          background: isOpen ? '#FAFBFE' : (e.sensitive ? '#FFFBF5' : 'transparent'),
                          borderLeft: `3px solid ${isOpen ? stripeColor : 'transparent'}`,
                          transition: 'background 0.12s, border-color 0.12s',
                        }}
                        onMouseEnter={ev => { if(!isOpen) ev.currentTarget.style.background = C.bg; }}
                        onMouseLeave={ev => { if(!isOpen) ev.currentTarget.style.background = e.sensitive ? '#FFFBF5' : 'transparent'; }}
                      >
                        {/* Time */}
                        {!mobile && (
                          <span style={{ fontSize:12, fontWeight:700, color:C.textSecondary, fontVariantNumeric:'tabular-nums' }}>{e.time}</span>
                        )}

                        {/* Action dot */}
                        {!mobile && (
                          <span title={e.action} style={{ width:10, height:10, borderRadius:'50%', background:stripeColor, boxShadow:`0 0 0 3px ${stripeColor}22`, justifySelf:'center' }} />
                        )}

                        {/* Actor */}
                        <div style={{ display:'flex', alignItems:'center', gap:8, minWidth:0 }}>
                          <Avatar initials={a.initials} size={28} color={a.color} />
                          {!mobile && (
                            <div style={{ minWidth:0 }}>
                              <p style={{ fontSize:13, fontWeight:700, color:C.navy, whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }}>{a.name}</p>
                              <p style={{ fontSize:10, color:C.textMuted, fontWeight:600 }}>{a.role}</p>
                            </div>
                          )}
                        </div>

                        {/* Category badge */}
                        {!mobile && <Badge variant={cat.tone}>{cat.label}</Badge>}

                        {/* Summary + target */}
                        <div style={{ minWidth:0 }}>
                          <p style={{ fontSize:13, color:C.textPrimary, lineHeight:1.4 }}>
                            <span style={{ fontWeight:700, color:stripeColor, marginRight:6 }}>{e.action}</span>
                            <span>{e.summary}</span>
                            {e.target && (
                              <>
                                <span style={{ color:C.textMuted, margin:'0 6px' }}>·</span>
                                <span style={{ fontWeight:700, color:C.navy }}>{e.target}</span>
                              </>
                            )}
                          </p>
                          {mobile && (
                            <p style={{ fontSize:11, color:C.textMuted, marginTop:3 }}>{e.time} · {a.name} · {cat.label}</p>
                          )}
                        </div>

                        {/* Flags */}
                        {!mobile && (
                          <div style={{ display:'flex', gap:6, alignItems:'center' }}>
                            {e.sensitive && <Badge variant="amber">Sensitive</Badge>}
                          </div>
                        )}

                        {/* Chevron */}
                        {!mobile && (
                          <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke={C.textMuted} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" style={{ transform: isOpen?'rotate(90deg)':'rotate(0deg)', transition:'transform 0.15s' }}>
                            <path d="M9 5l7 7-7 7"/>
                          </svg>
                        )}
                      </div>

                      {/* Expanded detail */}
                      {isOpen && (
                        <div style={{ padding:'14px 24px 18px', background:'#FAFBFE', borderTop:`1px dashed ${C.border}` }}>
                          <div style={{ display:'grid', gridTemplateColumns:mobile?'1fr':'2fr 1fr', gap:18 }}>
                            {/* Left: note / diff */}
                            <div>
                              {e.note && (
                                <div style={{ marginBottom:12 }}>
                                  <p style={{ fontSize:10, fontWeight:700, color:C.textMuted, textTransform:'uppercase', letterSpacing:'0.5px', marginBottom:5 }}>Note</p>
                                  <p style={{ fontSize:13, color:C.textPrimary, lineHeight:1.55, padding:'10px 12px', background:C.surface, borderRadius:8, border:`1px solid ${C.border}` }}>{e.note}</p>
                                </div>
                              )}

                              {e.meta && e.meta.from !== undefined && e.meta.to !== undefined && (
                                <div style={{ marginBottom:12 }}>
                                  <p style={{ fontSize:10, fontWeight:700, color:C.textMuted, textTransform:'uppercase', letterSpacing:'0.5px', marginBottom:5 }}>Change · {e.meta.field || 'value'}</p>
                                  <div style={{ display:'flex', gap:8, alignItems:'center', flexWrap:'wrap' }}>
                                    <span style={{ fontSize:13, padding:'5px 10px', background:C.dangerBg, color:C.danger, fontWeight:700, borderRadius:6, textDecoration:'line-through' }}>{e.meta.from}</span>
                                    <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke={C.textMuted} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg>
                                    <span style={{ fontSize:13, padding:'5px 10px', background:C.successBg, color:C.success, fontWeight:700, borderRadius:6 }}>{e.meta.to}</span>
                                  </div>
                                </div>
                              )}

                              <div style={{ display:'flex', gap:8, flexWrap:'wrap' }}>
                                <Btn variant="secondary" size="sm">Open entity</Btn>
                                <Btn variant="ghost" size="sm">Copy event ID</Btn>
                                {e.action !== 'Deleted' && e.category !== 'security' && <Btn variant="ghost" size="sm">Flag for review</Btn>}
                              </div>
                            </div>

                            {/* Right: metadata */}
                            <div style={{ background:C.surface, borderRadius:8, border:`1px solid ${C.border}`, padding:'10px 14px' }}>
                              <p style={{ fontSize:10, fontWeight:700, color:C.textMuted, textTransform:'uppercase', letterSpacing:'0.5px', marginBottom:8 }}>Details</p>
                              {[
                                ['Event ID',  e.id.toUpperCase()],
                                ['Timestamp', `${e.day === 'Today' ? '25 Apr' : e.day === 'Yesterday' ? '24 Apr' : '23 Apr'} 2026 · ${e.time}`],
                                ['Actor',     `${a.name} (${a.role})`],
                                ['Category',  cat.label],
                                ['Action',    e.action],
                                e.target ? ['Target', e.target] : null,
                                ...Object.entries(e.meta || {}).filter(([k]) => !['from','to','field'].includes(k))
                                  .map(([k,v]) => [k.replace(/([A-Z])/g,' $1').replace(/^./,c=>c.toUpperCase()), String(v)]),
                              ].filter(Boolean).map(([k,v]) => (
                                <div key={k} style={{ display:'grid', gridTemplateColumns:'120px 1fr', gap:8, padding:'5px 0', borderTop:`1px solid ${C.borderLight}`, fontSize:12 }}>
                                  <span style={{ color:C.textMuted, fontWeight:600 }}>{k}</span>
                                  <span style={{ color:C.textPrimary, fontWeight:600, fontFamily: /^#|^\d|\d{1,3}\.\d/.test(v) ? 'ui-monospace, SFMono-Regular, monospace' : 'inherit', fontSize: /^#|^\d|\d{1,3}\.\d/.test(v) ? 11.5 : 12 }}>{v}</span>
                                </div>
                              ))}
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </Card>
            </div>
          ))}
        </div>
      )}

      {/* Footer note */}
      <div style={{ marginTop:18, padding:'12px 16px', background:C.surface, borderRadius:10, border:`1px dashed ${C.border}`, display:'flex', gap:10, alignItems:'flex-start' }}>
        <svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke={C.blue} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" style={{ flexShrink:0, marginTop:1 }}><circle cx={12} cy={12} r={10}/><path d="M12 16v-4M12 8h.01"/></svg>
        <p style={{ fontSize:12, color:C.textSecondary, lineHeight:1.5 }}>
          The audit log is <strong style={{ color:C.navy }}>append-only</strong> — entries cannot be edited or removed, even by the Head of Centre. Deletions of source records (e.g. a behaviour entry logged in error) appear here as their own audited event. Exports are watermarked and themselves logged.
        </p>
      </div>
    </div>
  );
};

Object.assign(window, { AdminAuditLog });
