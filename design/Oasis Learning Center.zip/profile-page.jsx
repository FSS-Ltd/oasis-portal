// profile-page.jsx — Reusable Profile Page
// Works for: Student profiles (admin edits), Staff profiles (self + admin edit), Parent profiles (self + admin edit)
// viewerRole: 'admin' = full edit access | 'self' = own info only | 'readonly' = view only

// ── Extended mock data ───────────────────────────────────────────────────────

const STAFF_PROFILES = [
  {
    id: 's1', type: 'staff', role: 'Head of Centre',
    firstName: 'Margaret', lastName: 'Thompson',
    initials: 'MT', color: C.navy,
    email: 'head@oasis.school', phone: '07700 900123',
    address: '14 Elm Grove, Birmingham, B12 4PQ',
    dob: '1974-06-15', startDate: '2019-09-01',
    qualifications: 'BA Education (Hons), PGCE, ACE Certified Supervisor',
    tags: ['leaderboard-admin'],
    subjects: ['Mathematics', 'English', 'Bible'],
    notes: 'Head of Centre since 2019. Responsible for all academic oversight, reporting and staff management.',
    twoFA: true, status: 'Active',
  },
  {
    id: 's2', type: 'staff', role: 'Supervisor',
    firstName: 'Kwame', lastName: 'Osei',
    initials: 'KO', color: '#1A7A4A',
    email: 'supervisor@oasis.school', phone: '07700 900456',
    address: '8 Oak Lane, Birmingham, B15 2RW',
    dob: '1985-03-22', startDate: '2021-01-10',
    qualifications: 'BSc Applied Science, ACE Certified Supervisor',
    tags: ['shopkeeper'],
    subjects: ['Science', 'Social Studies'],
    notes: 'Supervises Y9 and Y10 students. Also acts as shopkeeper during Merit Shop sessions.',
    twoFA: true, status: 'Active',
  },
  {
    id: 's3', type: 'staff', role: 'Clubs Admin',
    firstName: 'Abigail', lastName: 'Carter',
    initials: 'AC', color: '#7D3C98',
    email: 'clubs@oasis.school', phone: '07700 900789',
    address: '3 Maple Street, Birmingham, B8 1TG',
    dob: '1990-11-08', startDate: '2022-09-05',
    qualifications: 'BA Youth Work, First Aid Certified',
    tags: [],
    subjects: [],
    notes: 'Manages all extracurricular clubs and activities. Reports directly to Head of Centre.',
    twoFA: false, status: 'Active',
  },
];

const PARENT_PROFILES = [
  {
    id: 'p1', type: 'parent',
    firstName: 'Robert', lastName: 'Johnson',
    initials: 'RJ', color: '#5B90C5',
    email: 'parent@oasis.school', phone: '07700 901111',
    address: '22 Birch Road, Birmingham, B20 3NN',
    dob: '1978-04-10',
    children: [1], // Joshua
    emergencyContact: 'Mrs Sarah Johnson — 07700 902222',
    preferredContact: 'Email',
    gdprConsent: true, photoConsent: true,
    notes: 'Primary contact for Joshua Johnson. Very engaged parent — responds promptly.',
    twoFA: true, status: 'Active',
  },
  {
    id: 'p2', type: 'parent',
    firstName: 'David', lastName: 'Williams',
    initials: 'DW', color: '#7D3C98',
    email: 'dwilliams@email.com', phone: '07700 903333',
    address: '5 Cedar Avenue, Birmingham, B4 7LX',
    dob: '1975-09-30',
    children: [2], // Grace
    emergencyContact: 'Mrs Linda Williams — 07700 904444',
    preferredContact: 'Phone',
    gdprConsent: true, photoConsent: false,
    notes: 'Photo consent withheld — do not include Grace in any published photography.',
    twoFA: true, status: 'Active',
  },
];

const STUDENT_EXTENDED = {
  1:  { firstName:'Joshua',  lastName:'Johnson',  dob:'2011-03-14', address:'22 Birch Road, Birmingham, B20 3NN', enrolledDate:'2024-01-08', medicalNotes:'Mild nut allergy — carries EpiPen', dietaryReqs:'No nuts', emergencyContact:'Mrs Sarah Johnson — 07700 902222', parentIds:['p1'], faith:'Christian', photo: null },
  2:  { firstName:'Grace',   lastName:'Williams', dob:'2012-07-22', address:'5 Cedar Avenue, Birmingham, B4 7LX', enrolledDate:'2023-09-04', medicalNotes:'None', dietaryReqs:'None', emergencyContact:'Mrs Linda Williams — 07700 904444', parentIds:['p2'], faith:'Christian', photo: null },
  3:  { firstName:'Samuel',  lastName:'Okafor',   dob:'2010-11-05', address:'17 Ash Close, Birmingham, B6 2PL', enrolledDate:'2023-09-04', medicalNotes:'Asthma — inhaler kept in office', dietaryReqs:'None', emergencyContact:'Mrs Okafor — 07700 905555', parentIds:[], faith:'Christian', photo: null },
  4:  { firstName:'Ruth',    lastName:'Chen',     dob:'2013-02-18', address:'9 Pine Way, Birmingham, B28 9QR', enrolledDate:'2024-01-08', medicalNotes:'None', dietaryReqs:'Vegetarian', emergencyContact:'Mr Chen — 07700 906666', parentIds:[], faith:'Christian', photo: null },
  5:  { firstName:'Daniel',  lastName:'Patel',    dob:'2011-08-30', address:'33 Willow Drive, Birmingham, B12 0HJ', enrolledDate:'2024-09-02', medicalNotes:'None', dietaryReqs:'Halal', emergencyContact:'Mrs Patel — 07700 907777', parentIds:[], faith:'Christian', photo: null },
  6:  { firstName:'Esther',  lastName:'Brown',    dob:'2012-05-11', address:'6 Oak Street, Birmingham, B17 4MN', enrolledDate:'2023-09-04', medicalNotes:'None', dietaryReqs:'None', emergencyContact:'Mr Brown — 07700 908888', parentIds:[], faith:'Christian', photo: null },
  7:  { firstName:'Caleb',   lastName:'Smith',    dob:'2010-12-03', address:'21 Elm Lane, Birmingham, B29 5AQ', enrolledDate:'2023-01-09', medicalNotes:'None', dietaryReqs:'None', emergencyContact:'Mrs Smith — 07700 909999', parentIds:[], faith:'Christian', photo: null },
  8:  { firstName:'Hannah',  lastName:'Davies',   dob:'2013-09-27', address:'44 Maple Crescent, Birmingham, B5 3RT', enrolledDate:'2024-01-08', medicalNotes:'Glasses — may need seating consideration', dietaryReqs:'None', emergencyContact:'Mr Davies — 07700 910000', parentIds:[], faith:'Christian', photo: null },
  9:  { firstName:'Joseph',  lastName:'Taylor',   dob:'2011-06-19', address:'12 Beech Road, Birmingham, B11 7KW', enrolledDate:'2023-09-04', medicalNotes:'None', dietaryReqs:'None', emergencyContact:'Mrs Taylor — 07700 911111', parentIds:[], faith:'Christian', photo: null },
  10: { firstName:'Faith',   lastName:'Mensah',   dob:'2012-04-08', address:'28 Sycamore Way, Birmingham, B25 2GJ', enrolledDate:'2023-09-04', medicalNotes:'None', dietaryReqs:'None', emergencyContact:'Mr Mensah — 07700 912222', parentIds:[], faith:'Christian', photo: null },
};

// ── Helpers ──────────────────────────────────────────────────────────────────
const ALL_PROFILES = [
  ...STUDENTS.map(s => ({ ...s, ...STUDENT_EXTENDED[s.id], type:'student', id:`st${s.id}`, rawId: s.id })),
  ...STAFF_PROFILES,
  ...PARENT_PROFILES,
];

const fmtDob = str => { if (!str) return '—'; const d = new Date(str); return d.toLocaleDateString('en-GB', { day:'numeric', month:'long', year:'numeric' }); };
const age    = str => { if (!str) return ''; const d = new Date(str); const today = new Date('2026-05-01'); return Math.floor((today - d) / 3.156e10); };

const TAG_LABELS = { 'leaderboard-admin':'Leaderboard Admin', 'shopkeeper':'Shopkeeper', 'shopadmin':'Shop Admin' };
const ALL_TAGS   = Object.keys(TAG_LABELS);
const ROLES      = ['Head of Centre','Principal','Pastor','Head of Discipline','Clubs Admin','Supervisor'];
const YEAR_GROUPS = ['Y7','Y8','Y9','Y10','Y11'];
const SUPERVISORS = ['Mrs Thompson','Mr Osei'];
const TITHE_OPTS  = ['10','15','20'];

// ── Field components ─────────────────────────────────────────────────────────
const FieldRow = ({ label, value, editing, onChange, type='text', options, textarea, placeholder, readOnly }) => {
  const displayVal = value || <span style={{ color:C.textMuted, fontStyle:'italic' }}>Not set</span>;
  if (!editing || readOnly) {
    return (
      <div style={{ display:'grid', gridTemplateColumns:'160px 1fr', gap:12, padding:'11px 0', borderBottom:`1px solid ${C.borderLight}`, alignItems:'flex-start' }}>
        <p style={{ fontSize:12, fontWeight:700, color:C.textSecondary, textTransform:'uppercase', letterSpacing:'0.4px', paddingTop:1 }}>{label}</p>
        <p style={{ fontSize:13, color:C.textPrimary, lineHeight:1.5 }}>{displayVal}</p>
      </div>
    );
  }
  return (
    <div style={{ display:'grid', gridTemplateColumns:'160px 1fr', gap:12, padding:'10px 0', borderBottom:`1px solid ${C.borderLight}`, alignItems:'center' }}>
      <p style={{ fontSize:12, fontWeight:700, color:C.textSecondary, textTransform:'uppercase', letterSpacing:'0.4px' }}>{label}</p>
      {options ? (
        <select value={value} onChange={e => onChange(e.target.value)}
          style={{ padding:'8px 10px', border:`1.5px solid ${C.border}`, borderRadius:7, fontSize:13, fontFamily:'inherit', color:C.textPrimary, background:C.surface, outline:'none', width:'100%' }}>
          {options.map(o => <option key={o} value={o}>{o}</option>)}
        </select>
      ) : textarea ? (
        <textarea value={value} onChange={e => onChange(e.target.value)} rows={3} placeholder={placeholder}
          style={{ padding:'8px 10px', border:`1.5px solid ${C.border}`, borderRadius:7, fontSize:13, fontFamily:'inherit', color:C.textPrimary, resize:'vertical', outline:'none', width:'100%' }} />
      ) : (
        <input type={type} value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder}
          style={{ padding:'8px 10px', border:`1.5px solid ${C.border}`, borderRadius:7, fontSize:13, fontFamily:'inherit', color:C.textPrimary, background:C.surface, outline:'none', width:'100%' }} />
      )}
    </div>
  );
};

const SectionTitle = ({ children, action }) => (
  <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:4, marginTop:8 }}>
    <p style={{ fontSize:11, fontWeight:800, color:C.textSecondary, textTransform:'uppercase', letterSpacing:'0.7px' }}>{children}</p>
    {action}
  </div>
);

const ToggleSwitch = ({ value, onChange, label }) => (
  <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', padding:'10px 0', borderBottom:`1px solid ${C.borderLight}` }}>
    <p style={{ fontSize:13, color:C.textPrimary }}>{label}</p>
    <button onClick={() => onChange(!value)} style={{
      width:40, height:22, borderRadius:11, border:'none', cursor:'pointer', position:'relative', transition:'background 0.2s',
      background: value ? C.success : C.border, flexShrink:0,
    }}>
      <div style={{ width:16, height:16, borderRadius:'50%', background:'#fff', position:'absolute', top:3, transition:'left 0.2s', left: value ? 21 : 3, boxShadow:'0 1px 3px rgba(0,0,0,0.2)' }} />
    </button>
  </div>
);

// ── Profile type tabs config ──────────────────────────────────────────────────
const studentTabs  = ['Personal','Academic','Medical & Contact','Merits & Finance','Permissions'];
const staffTabs    = ['Personal','Role & Access','Contact','Permissions'];
const parentTabs   = ['Personal','Contact','Children','Consent & Permissions'];

// ── Main Profile Page ─────────────────────────────────────────────────────────
const ProfilePage = ({ mobile, viewerRole = 'admin' }) => {
  const [selectedId, setSelectedId] = React.useState('st1');
  const [editing,    setEditing]    = React.useState(false);
  const [saved,      setSaved]      = React.useState(false);
  const [activeTab,  setActiveTab]  = React.useState(0);
  const [filterType, setFilterType] = React.useState('all');

  // Find the selected profile
  const baseProfile = ALL_PROFILES.find(p => p.id === selectedId) || ALL_PROFILES[0];

  // Local editable state — seeded from profile, reset on selection change
  const [form, setForm] = React.useState(baseProfile);
  React.useEffect(() => {
    const p = ALL_PROFILES.find(p => p.id === selectedId) || ALL_PROFILES[0];
    setForm({ ...p });
    setEditing(false);
    setSaved(false);
    setActiveTab(0);
  }, [selectedId]);

  const set = (key, val) => setForm(f => ({ ...f, [key]: val }));

  const canEdit = viewerRole === 'admin' || (viewerRole === 'self' && form.id === 'self');
  const tabs = form.type === 'student' ? studentTabs : form.type === 'staff' ? staffTabs : parentTabs;

  const handleSave = () => { setSaved(true); setEditing(false); setTimeout(() => setSaved(false), 3000); };
  const handleCancel = () => { const p = ALL_PROFILES.find(p => p.id === selectedId); setForm({ ...p }); setEditing(false); };

  // Filter for directory
  const filtered = ALL_PROFILES.filter(p => filterType === 'all' || p.type === filterType);

  // ── Profile list panel ───────────────────────────────────────────────────
  const DirectoryPanel = () => (
    <div style={{ display:'flex', flexDirection:'column', height:'100%', overflow:'hidden' }}>
      {/* Filter tabs */}
      <div style={{ display:'flex', gap:3, padding:'12px 12px 8px', flexShrink:0 }}>
        {[['all','All'],['student','Students'],['staff','Staff'],['parent','Parents']].map(([k,l]) => (
          <button key={k} onClick={() => setFilterType(k)}
            style={{ flex:1, padding:'6px 4px', borderRadius:6, border:'none', fontFamily:'inherit', fontSize:11, fontWeight:700, cursor:'pointer',
              background: filterType === k ? C.navy : C.bg, color: filterType === k ? '#fff' : C.textSecondary }}>
            {l}
          </button>
        ))}
      </div>
      {/* Search */}
      <div style={{ padding:'0 12px 10px', flexShrink:0 }}>
        <input placeholder="Search people…" style={{ width:'100%', padding:'8px 12px', border:`1.5px solid ${C.border}`, borderRadius:8, fontSize:12, fontFamily:'inherit', color:C.textPrimary, outline:'none' }} />
      </div>
      {/* List */}
      <div style={{ flex:1, overflowY:'auto' }}>
        {filtered.map(p => {
          const isActive = p.id === selectedId;
          const typeCol  = p.type === 'student' ? C.blue : p.type === 'staff' ? C.navy : C.crimson;
          const typeLabel= p.type === 'student' ? p.year || 'Student' : p.type === 'staff' ? p.role : 'Parent';
          return (
            <div key={p.id} onClick={() => setSelectedId(p.id)}
              style={{ display:'flex', alignItems:'center', gap:10, padding:'10px 14px', cursor:'pointer', borderLeft:`3px solid ${isActive ? C.blue : 'transparent'}`, background: isActive ? C.bg : 'transparent', transition:'background 0.1s' }}>
              <Avatar initials={p.initials} size={34} color={p.color} />
              <div style={{ flex:1, minWidth:0 }}>
                <p style={{ fontSize:13, fontWeight: isActive ? 700 : 600, color:C.navy, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>
                  {p.firstName} {p.lastName}
                </p>
                <div style={{ display:'flex', alignItems:'center', gap:6, marginTop:2 }}>
                  <div style={{ width:6, height:6, borderRadius:'50%', background:typeCol, flexShrink:0 }} />
                  <p style={{ fontSize:11, color:C.textSecondary }}>{typeLabel}</p>
                  {p.status && <span style={{ fontSize:10, color: p.status === 'Active' ? C.success : C.danger, fontWeight:700 }}>· {p.status}</span>}
                </div>
              </div>
            </div>
          );
        })}
      </div>
      {viewerRole === 'admin' && (
        <div style={{ padding:12, borderTop:`1px solid ${C.border}`, flexShrink:0 }}>
          <Btn variant="primary" size="sm" style={{ width:'100%', justifyContent:'center' }}>+ Add Person</Btn>
        </div>
      )}
    </div>
  );

  // ── Student tabs content ─────────────────────────────────────────────────
  const StudentPersonal = () => (
    <div>
      <SectionTitle>Identity</SectionTitle>
      <Card padding={16} style={{ marginBottom:16 }}>
        <FieldRow label="First name"   value={form.firstName}   editing={editing} onChange={v=>set('firstName',v)} />
        <FieldRow label="Last name"    value={form.lastName}    editing={editing} onChange={v=>set('lastName',v)} />
        <FieldRow label="Date of birth" value={`${fmtDob(form.dob)} (age ${age(form.dob)})`} editing={editing} onChange={v=>set('dob',v)} type="date" readOnly />
        <FieldRow label="Year group"   value={form.year}        editing={editing} onChange={v=>set('year',v)} options={YEAR_GROUPS} />
        <FieldRow label="Enrolled"     value={fmtDob(form.enrolledDate)} editing={false} onChange={()=>{}} readOnly />
        <FieldRow label="Faith"        value={form.faith}       editing={editing} onChange={v=>set('faith',v)} />
      </Card>
      <SectionTitle>Supervisor assignment</SectionTitle>
      <Card padding={16}>
        <FieldRow label="Supervisor" value={form.tutor} editing={editing} onChange={v=>set('tutor',v)} options={SUPERVISORS} />
        <FieldRow label="Student login" value={form.userId ? 'Enabled' : 'Not yet issued'} editing={false} onChange={()=>{}} readOnly />
      </Card>
    </div>
  );

  const StudentAcademic = () => (
    <div>
      <SectionTitle>PACE Overview</SectionTitle>
      <Card padding={16} style={{ marginBottom:16 }}>
        <FieldRow label="PACEs completed" value={`${form.pacesCompleted} this year`} editing={false} onChange={()=>{}} readOnly />
        <div style={{ padding:'11px 0', borderBottom:`1px solid ${C.borderLight}` }}>
          <p style={{ fontSize:12, fontWeight:700, color:C.textSecondary, textTransform:'uppercase', letterSpacing:'0.4px', marginBottom:10 }}>Active subjects</p>
          <div style={{ display:'flex', flexWrap:'wrap', gap:6 }}>
            {PACE_SUBJECTS.map(p => (
              <div key={p.subject} style={{ display:'flex', alignItems:'center', gap:8, background:C.bg, borderRadius:8, padding:'6px 12px' }}>
                <span style={{ fontSize:12, fontWeight:600, color:C.navy }}>{p.subject}</span>
                <span style={{ fontSize:11, color:C.blue, fontWeight:700 }}>#{p.paceNumber}</span>
                <Badge variant={p.status==='Ahead'?'green':p.status==='On Track'?'blue':'red'}>{p.status}</Badge>
              </div>
            ))}
          </div>
        </div>
      </Card>
      <SectionTitle>Supervisor notes on progress</SectionTitle>
      <Card padding={16}>
        <FieldRow label="Academic notes" value={form.notes || 'No notes added yet.'} editing={editing} onChange={v=>set('notes',v)} textarea />
      </Card>
    </div>
  );

  const StudentMedical = () => (
    <div>
      <SectionTitle>Medical information</SectionTitle>
      <Card padding={16} style={{ marginBottom:16 }}>
        <FieldRow label="Medical notes"  value={form.medicalNotes}  editing={editing} onChange={v=>set('medicalNotes',v)}  textarea />
        <FieldRow label="Dietary reqs"   value={form.dietaryReqs}   editing={editing} onChange={v=>set('dietaryReqs',v)} />
      </Card>
      <SectionTitle>Contact & emergency</SectionTitle>
      <Card padding={16}>
        <FieldRow label="Home address"       value={form.address}          editing={editing} onChange={v=>set('address',v)} />
        <FieldRow label="Emergency contact"  value={form.emergencyContact} editing={editing} onChange={v=>set('emergencyContact',v)} />
        {form.parentIds?.length > 0 && (
          <div style={{ padding:'11px 0', borderBottom:`1px solid ${C.borderLight}` }}>
            <p style={{ fontSize:12, fontWeight:700, color:C.textSecondary, textTransform:'uppercase', letterSpacing:'0.4px', marginBottom:8 }}>Linked parents</p>
            {form.parentIds.map(pid => {
              const par = PARENT_PROFILES.find(p => p.id === pid);
              return par ? (
                <div key={pid} style={{ display:'flex', alignItems:'center', gap:10, marginBottom:6 }}>
                  <Avatar initials={par.initials} size={26} color={par.color} />
                  <span style={{ fontSize:13, color:C.navy, fontWeight:600 }}>{par.firstName} {par.lastName}</span>
                  <Badge variant="grey">{par.preferredContact}</Badge>
                </div>
              ) : null;
            })}
          </div>
        )}
      </Card>
    </div>
  );

  const StudentMerits = () => {
    const totalMerits = (form.merits?.spend||0) + (form.merits?.saving||0) + (form.merits?.investment||0);
    return (
      <div>
        <SectionTitle>Merit accounts</SectionTitle>
        <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:10, marginBottom:16 }}>
          {[['Spend',C.crimson,form.merits?.spend||0],['Saving',C.navy,form.merits?.saving||0],['Investment',C.blue,form.merits?.investment||0]].map(([l,col,v])=>(
            <Card key={l} style={{ borderTop:`3px solid ${col}`, textAlign:'center' }} padding={14}>
              <p style={{ fontSize:11, fontWeight:700, color:C.textSecondary, textTransform:'uppercase', letterSpacing:'0.5px', marginBottom:8 }}>{l}</p>
              <p style={{ fontSize:26, fontWeight:800, color:col }}>{v}</p>
            </Card>
          ))}
        </div>
        <Card padding={16} style={{ marginBottom:16 }}>
          <FieldRow label="Total merits" value={String(totalMerits)} editing={false} onChange={()=>{}} readOnly />
          <div style={{ display:'grid', gridTemplateColumns:'160px 1fr', gap:12, padding:'10px 0', borderBottom:`1px solid ${C.borderLight}`, alignItems:'center' }}>
            <p style={{ fontSize:12, fontWeight:700, color:C.textSecondary, textTransform:'uppercase', letterSpacing:'0.4px' }}>Tithe rate</p>
            {editing ? (
              <div style={{ display:'flex', gap:8 }}>
                {TITHE_OPTS.map(t => (
                  <button key={t} onClick={() => set('tithe', Number(t))}
                    style={{ flex:1, padding:'7px', borderRadius:7, border:`1.5px solid ${form.tithe===Number(t)?C.crimson:C.border}`, background:form.tithe===Number(t)?C.crimsonLight:'transparent', color:form.tithe===Number(t)?C.crimson:C.textSecondary, fontWeight:700, fontSize:14, cursor:'pointer', fontFamily:'inherit' }}>
                    {t}%
                  </button>
                ))}
              </div>
            ) : <p style={{ fontSize:13, color:C.textPrimary }}>{form.tithe}% weekly</p>}
          </div>
        </Card>
        <SectionTitle>Account settings</SectionTitle>
        <Card padding={16}>
          <FieldRow label="Investment return" value="~10.4% this year" editing={false} onChange={()=>{}} readOnly />
          <FieldRow label="Withdrawal fee" value="5% of proceeds (default)" editing={false} onChange={()=>{}} readOnly />
        </Card>
      </div>
    );
  };

  const StudentPermissions = () => (
    <div>
      <SectionTitle>System access</SectionTitle>
      <Card padding={16} style={{ marginBottom:16 }}>
        <ToggleSwitch label="Student portal login enabled" value={!!form.userId} onChange={v => set('userId', v ? 'pending' : null)} />
        <ToggleSwitch label="Two-factor authentication (2FA)" value={form.twoFA||false} onChange={v => set('twoFA', v)} />
        <FieldRow label="Account status" value={form.status||'Active'} editing={editing} onChange={v=>set('status',v)} options={['Active','Suspended','Archived']} />
      </Card>
      {viewerRole === 'admin' && (
        <>
          <SectionTitle>Danger zone</SectionTitle>
          <Card padding={16} style={{ borderColor:C.dangerBg }}>
            <p style={{ fontSize:13, color:C.textSecondary, marginBottom:12 }}>These actions are irreversible. Only the Head of Centre can perform them.</p>
            <div style={{ display:'flex', gap:8, flexWrap:'wrap' }}>
              <Btn variant="secondary" size="sm">Reset Password</Btn>
              <Btn variant="secondary" size="sm">Archive Student</Btn>
            </div>
          </Card>
        </>
      )}
    </div>
  );

  // ── Staff tabs content ───────────────────────────────────────────────────
  const StaffPersonal = () => (
    <div>
      <SectionTitle>Identity</SectionTitle>
      <Card padding={16} style={{ marginBottom:16 }}>
        <FieldRow label="First name"    value={form.firstName}    editing={editing} onChange={v=>set('firstName',v)} />
        <FieldRow label="Last name"     value={form.lastName}     editing={editing} onChange={v=>set('lastName',v)} />
        <FieldRow label="Date of birth" value={fmtDob(form.dob)} editing={false}   onChange={()=>{}} readOnly />
        <FieldRow label="Start date"    value={fmtDob(form.startDate)} editing={false} onChange={()=>{}} readOnly />
        <FieldRow label="Qualifications" value={form.qualifications} editing={editing} onChange={v=>set('qualifications',v)} textarea />
      </Card>
      <SectionTitle>Notes</SectionTitle>
      <Card padding={16}>
        <FieldRow label="Staff notes" value={form.notes} editing={editing} onChange={v=>set('notes',v)} textarea placeholder="Internal notes about this staff member…" />
      </Card>
    </div>
  );

  const StaffRole = () => (
    <div>
      <SectionTitle>Role & responsibilities</SectionTitle>
      <Card padding={16} style={{ marginBottom:16 }}>
        <FieldRow label="Role" value={form.role} editing={editing} onChange={v=>set('role',v)} options={ROLES} />
        <div style={{ padding:'11px 0', borderBottom:`1px solid ${C.borderLight}` }}>
          <p style={{ fontSize:12, fontWeight:700, color:C.textSecondary, textTransform:'uppercase', letterSpacing:'0.4px', marginBottom:8 }}>Supervised subjects</p>
          <div style={{ display:'flex', flexWrap:'wrap', gap:6 }}>
            {(form.subjects||[]).length > 0
              ? (form.subjects||[]).map(s => <Badge key={s} variant="blue">{s}</Badge>)
              : <span style={{ fontSize:13, color:C.textMuted, fontStyle:'italic' }}>None assigned</span>
            }
          </div>
        </div>
      </Card>
      <SectionTitle>Permission tags</SectionTitle>
      <Card padding={16}>
        {ALL_TAGS.map(tag => (
          <ToggleSwitch
            key={tag}
            label={TAG_LABELS[tag]}
            value={(form.tags||[]).includes(tag)}
            onChange={v => set('tags', v ? [...(form.tags||[]), tag] : (form.tags||[]).filter(t=>t!==tag))}
          />
        ))}
      </Card>
    </div>
  );

  const StaffContact = () => (
    <div>
      <SectionTitle>Contact details</SectionTitle>
      <Card padding={16}>
        <FieldRow label="Email"   value={form.email}   editing={editing} onChange={v=>set('email',v)}   type="email" />
        <FieldRow label="Phone"   value={form.phone}   editing={editing} onChange={v=>set('phone',v)}   type="tel" />
        <FieldRow label="Address" value={form.address} editing={editing} onChange={v=>set('address',v)} />
      </Card>
    </div>
  );

  const StaffPermissions = () => (
    <div>
      <SectionTitle>Account & security</SectionTitle>
      <Card padding={16} style={{ marginBottom:16 }}>
        <ToggleSwitch label="Two-factor authentication (2FA)" value={form.twoFA||false} onChange={v=>set('twoFA',v)} />
        <FieldRow label="Account status" value={form.status||'Active'} editing={editing} onChange={v=>set('status',v)} options={['Active','Suspended','Archived']} />
        <FieldRow label="Last login" value="Today, 08:47" editing={false} onChange={()=>{}} readOnly />
      </Card>
      {viewerRole === 'admin' && (
        <>
          <SectionTitle>Admin actions</SectionTitle>
          <Card padding={16}>
            <div style={{ display:'flex', gap:8, flexWrap:'wrap' }}>
              <Btn variant="secondary" size="sm">Reset Password</Btn>
              <Btn variant="secondary" size="sm">Resend Invite Email</Btn>
              <Btn variant="secondary" size="sm">Suspend Account</Btn>
            </div>
          </Card>
        </>
      )}
    </div>
  );

  // ── Parent tabs content ──────────────────────────────────────────────────
  const ParentPersonal = () => (
    <div>
      <SectionTitle>Identity</SectionTitle>
      <Card padding={16}>
        <FieldRow label="First name"    value={form.firstName} editing={editing} onChange={v=>set('firstName',v)} />
        <FieldRow label="Last name"     value={form.lastName}  editing={editing} onChange={v=>set('lastName',v)} />
        <FieldRow label="Date of birth" value={fmtDob(form.dob)} editing={false} onChange={()=>{}} readOnly />
      </Card>
    </div>
  );

  const ParentContact = () => (
    <div>
      <SectionTitle>Contact details</SectionTitle>
      <Card padding={16} style={{ marginBottom:16 }}>
        <FieldRow label="Email"   value={form.email}   editing={editing} onChange={v=>set('email',v)}   type="email" />
        <FieldRow label="Phone"   value={form.phone}   editing={editing} onChange={v=>set('phone',v)}   type="tel" />
        <FieldRow label="Address" value={form.address} editing={editing} onChange={v=>set('address',v)} />
        <FieldRow label="Preferred contact" value={form.preferredContact} editing={editing} onChange={v=>set('preferredContact',v)} options={['Email','Phone','Either']} />
        <FieldRow label="Emergency contact" value={form.emergencyContact} editing={editing} onChange={v=>set('emergencyContact',v)} />
      </Card>
      <SectionTitle>Internal notes</SectionTitle>
      <Card padding={16}>
        <FieldRow label="Notes" value={form.notes} editing={editing && viewerRole==='admin'} onChange={v=>set('notes',v)} textarea placeholder="Notes visible to staff only…" readOnly={viewerRole !== 'admin'} />
      </Card>
    </div>
  );

  const ParentChildren = () => (
    <div>
      <SectionTitle>Linked children</SectionTitle>
      <Card padding={16} style={{ marginBottom:16 }}>
        {(form.children||[]).map(childId => {
          const child = STUDENTS.find(s=>s.id===childId);
          const ext   = STUDENT_EXTENDED[childId];
          if (!child) return null;
          return (
            <div key={childId} style={{ display:'flex', alignItems:'center', gap:12, padding:'10px 0', borderBottom:`1px solid ${C.borderLight}` }}>
              <Avatar initials={child.initials} size={36} color={child.color} />
              <div style={{ flex:1 }}>
                <p style={{ fontSize:14, fontWeight:700, color:C.navy }}>{child.name}</p>
                <p style={{ fontSize:12, color:C.textSecondary }}>{child.year} · Enrolled {ext?.enrolledDate ? new Date(ext.enrolledDate).toLocaleDateString('en-GB',{month:'short',year:'numeric'}) : '—'}</p>
              </div>
              <Badge variant="blue">{child.year}</Badge>
            </div>
          );
        })}
        {(!form.children||form.children.length===0) && <p style={{ fontSize:13, color:C.textMuted }}>No children linked yet.</p>}
        {viewerRole === 'admin' && <div style={{ marginTop:12 }}><Btn variant="secondary" size="sm">+ Link Child</Btn></div>}
      </Card>
    </div>
  );

  const ParentConsent = () => (
    <div>
      <SectionTitle>GDPR & consent</SectionTitle>
      <Card padding={16} style={{ marginBottom:16 }}>
        <ToggleSwitch label="GDPR data processing consent given" value={form.gdprConsent||false} onChange={v=>set('gdprConsent',v)} />
        <ToggleSwitch label="Photography & media consent" value={form.photoConsent||false} onChange={v=>set('photoConsent',v)} />
        <ToggleSwitch label="Two-factor authentication (2FA)" value={form.twoFA||false} onChange={v=>set('twoFA',v)} />
        <FieldRow label="Account status" value={form.status||'Active'} editing={editing} onChange={v=>set('status',v)} options={['Active','Suspended','Archived']} />
      </Card>
      {!form.photoConsent && (
        <div style={{ padding:'12px 14px', background:C.warningBg, borderRadius:10, border:`1px solid ${C.warning}22`, marginBottom:12 }}>
          <p style={{ fontSize:12, fontWeight:700, color:C.warning }}>⚠ Photography consent withheld</p>
          <p style={{ fontSize:12, color:C.warning, marginTop:3 }}>Do not include this family's child(ren) in any published photographs or media.</p>
        </div>
      )}
    </div>
  );

  // ── Tab renderer ─────────────────────────────────────────────────────────
  const tabPanels = {
    student:  [StudentPersonal, StudentAcademic, StudentMedical, StudentMerits, StudentPermissions],
    staff:    [StaffPersonal, StaffRole, StaffContact, StaffPermissions],
    parent:   [ParentPersonal, ParentContact, ParentChildren, ParentConsent],
  };
  const TabPanel = tabPanels[form.type]?.[activeTab] || (() => null);

  const typeColor = form.type === 'student' ? C.blue : form.type === 'staff' ? C.navy : C.crimson;
  const typeLabel = form.type === 'student' ? form.year : form.type === 'staff' ? form.role : 'Parent';

  // ── Layout ───────────────────────────────────────────────────────────────
  if (mobile) {
    return (
      <div className="page-fade" style={{ display:'flex', flexDirection:'column', height:'100%', overflow:'hidden' }}>
        {/* Mobile: student picker at top */}
        <div style={{ background:C.surface, borderBottom:`1px solid ${C.border}`, overflowX:'auto', display:'flex', padding:'8px 10px', gap:8, flexShrink:0 }}>
          {ALL_PROFILES.slice(0,8).map(p=>(
            <button key={p.id} onClick={()=>setSelectedId(p.id)} style={{ display:'flex', flexDirection:'column', alignItems:'center', gap:4, background:'none', border:'none', cursor:'pointer', flexShrink:0, padding:'4px 6px', borderRadius:8, outline: p.id===selectedId?`2px solid ${p.color}`:'none' }}>
              <Avatar initials={p.initials} size={32} color={p.color} />
              <span style={{ fontSize:9, fontWeight:700, color:p.id===selectedId?p.color:C.textMuted }}>{p.firstName.slice(0,5)}</span>
            </button>
          ))}
        </div>

        {/* Hero */}
        <div style={{ background:`linear-gradient(130deg, ${typeColor} 0%, ${C.navyLight} 100%)`, padding:'14px 16px', flexShrink:0 }}>
          <div style={{ display:'flex', alignItems:'center', gap:12 }}>
            <Avatar initials={form.initials} size={44} color={form.color} />
            <div style={{ flex:1 }}>
              <p style={{ fontSize:17, fontWeight:800, color:'#fff', margin:0 }}>{form.firstName} {form.lastName}</p>
              <p style={{ fontSize:12, color:'rgba(255,255,255,0.7)', marginTop:2 }}>{typeLabel}</p>
            </div>
            {canEdit && (
              editing
                ? <button onClick={handleSave} style={{ padding:'6px 12px', background:C.success, color:'#fff', border:'none', borderRadius:7, fontSize:12, fontWeight:700, cursor:'pointer', fontFamily:'inherit' }}>Save</button>
                : <button onClick={()=>setEditing(true)} style={{ padding:'6px 12px', background:'rgba(255,255,255,0.2)', color:'#fff', border:'none', borderRadius:7, fontSize:12, fontWeight:700, cursor:'pointer', fontFamily:'inherit' }}>Edit</button>
            )}
          </div>
        </div>

        {/* Tab bar */}
        <div style={{ background:C.surface, borderBottom:`1px solid ${C.border}`, display:'flex', overflowX:'auto', flexShrink:0 }}>
          {tabs.map((t,i)=>(
            <button key={t} onClick={()=>setActiveTab(i)} style={{ padding:'10px 14px', border:'none', background:'none', borderBottom: activeTab===i?`2px solid ${typeColor}`:'2px solid transparent', color:activeTab===i?typeColor:C.textSecondary, fontWeight:600, fontSize:11, cursor:'pointer', whiteSpace:'nowrap', fontFamily:'inherit', flexShrink:0 }}>{t}</button>
          ))}
        </div>

        {/* Content */}
        <div style={{ flex:1, overflowY:'auto', padding:14 }}>
          <TabPanel />
        </div>
      </div>
    );
  }

  // Desktop
  return (
    <div className="page-fade">
      <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:20 }}>
        <div>
          <h2 style={{ fontSize:24, fontWeight:800, color:C.navy }}>People & Profiles</h2>
          <p style={{ fontSize:13, color:C.textSecondary, marginTop:2 }}>View and update student, staff and parent information.</p>
        </div>
      </div>

      <div style={{ display:'grid', gridTemplateColumns:'260px 1fr', gap:16, alignItems:'start' }}>
        {/* Directory sidebar */}
        <Card padding={0} style={{ overflow:'hidden', position:'sticky', top:0, maxHeight:'calc(100vh - 160px)' }}>
          <DirectoryPanel />
        </Card>

        {/* Profile editor */}
        <div>
          {/* Profile hero card */}
          <Card style={{ marginBottom:16, background:`linear-gradient(130deg, ${typeColor} 0%, ${C.navyLight} 100%)`, border:'none' }} padding={24}>
            <div style={{ display:'flex', alignItems:'center', gap:18 }}>
              {/* Avatar with upload hint */}
              <div style={{ position:'relative', cursor: editing ? 'pointer' : 'default' }}>
                <Avatar initials={form.initials} size={68} color={form.color} />
                {editing && (
                  <div style={{ position:'absolute', inset:0, borderRadius:'50%', background:'rgba(0,0,0,0.35)', display:'flex', alignItems:'center', justifyContent:'center' }}>
                    <span style={{ fontSize:10, color:'#fff', fontWeight:700 }}>CHANGE</span>
                  </div>
                )}
              </div>
              <div style={{ flex:1 }}>
                <div style={{ display:'flex', gap:8, alignItems:'center', marginBottom:4 }}>
                  <p style={{ fontSize:22, fontWeight:800, color:'#fff', margin:0 }}>{form.firstName} {form.lastName}</p>
                  <div style={{ background:'rgba(255,255,255,0.15)', borderRadius:6, padding:'3px 10px' }}>
                    <span style={{ fontSize:11, fontWeight:700, color:'rgba(255,255,255,0.9)' }}>{form.type === 'student' ? 'Student' : form.type === 'staff' ? 'Staff' : 'Parent'}</span>
                  </div>
                </div>
                <p style={{ fontSize:13, color:'rgba(255,255,255,0.7)', margin:0 }}>{typeLabel}</p>
                <div style={{ display:'flex', gap:8, marginTop:10, flexWrap:'wrap' }}>
                  {form.type === 'student' && (
                    <>
                      <div style={{ background:'rgba(255,255,255,0.12)', borderRadius:7, padding:'5px 12px', fontSize:12, color:'rgba(255,255,255,0.85)', fontWeight:600 }}>Age {age(form.dob)}</div>
                      <div style={{ background:'rgba(255,255,255,0.12)', borderRadius:7, padding:'5px 12px', fontSize:12, color:'rgba(255,255,255,0.85)', fontWeight:600 }}>{form.tutor}</div>
                      <div style={{ background:'rgba(255,255,255,0.12)', borderRadius:7, padding:'5px 12px', fontSize:12, color:'rgba(255,255,255,0.85)', fontWeight:600 }}>
                        {(form.merits?.spend||0)+(form.merits?.saving||0)+(form.merits?.investment||0)} merits
                      </div>
                    </>
                  )}
                  {form.type === 'staff' && (form.tags||[]).map(t => (
                    <div key={t} style={{ background:'rgba(255,255,255,0.12)', borderRadius:7, padding:'5px 12px', fontSize:12, color:'rgba(255,255,255,0.85)', fontWeight:600 }}>{TAG_LABELS[t]}</div>
                  ))}
                  {form.type === 'parent' && (
                    <div style={{ background:'rgba(255,255,255,0.12)', borderRadius:7, padding:'5px 12px', fontSize:12, color:'rgba(255,255,255,0.85)', fontWeight:600 }}>
                      {(form.children||[]).length} child linked
                    </div>
                  )}
                </div>
              </div>
              {/* Actions */}
              <div style={{ display:'flex', flexDirection:'column', gap:8, alignItems:'flex-end' }}>
                {canEdit && !editing && (
                  <Btn variant="secondary" onClick={() => setEditing(true)} style={{ background:'rgba(255,255,255,0.15)', border:'1.5px solid rgba(255,255,255,0.25)', color:'#fff' }}>Edit Profile</Btn>
                )}
                {editing && (
                  <div style={{ display:'flex', gap:8 }}>
                    <Btn variant="secondary" onClick={handleCancel} style={{ background:'rgba(255,255,255,0.1)', border:'1.5px solid rgba(255,255,255,0.2)', color:'rgba(255,255,255,0.8)' }}>Cancel</Btn>
                    <Btn variant="navy"      onClick={handleSave}   style={{ background:C.success, border:'none' }}>Save Changes</Btn>
                  </div>
                )}
                {saved && <Badge variant="green">✓ Saved</Badge>}
                {form.twoFA && <Badge variant="grey">🔒 2FA Active</Badge>}
              </div>
            </div>
          </Card>

          {/* Tab navigation */}
          <div style={{ display:'flex', gap:2, marginBottom:16, background:C.bg, borderRadius:10, padding:4, width:'fit-content' }}>
            {tabs.map((t,i) => (
              <button key={t} onClick={() => setActiveTab(i)}
                style={{ padding:'8px 18px', borderRadius:7, border:'none', cursor:'pointer', fontFamily:'inherit', fontWeight:600, fontSize:12, transition:'all 0.15s',
                  background: activeTab===i ? typeColor : 'transparent',
                  color:       activeTab===i ? '#fff'    : C.textSecondary,
                }}>{t}</button>
            ))}
          </div>

          {/* Tab content */}
          <div className="page-fade" key={`${selectedId}-${activeTab}`}>
            <TabPanel />
          </div>
        </div>
      </div>
    </div>
  );
};

Object.assign(window, { ProfilePage });
