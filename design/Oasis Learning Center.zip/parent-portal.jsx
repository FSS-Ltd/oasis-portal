// parent-portal.jsx — Parent Portal

const PARENT_NAV = [
  { id:'home',        label:'Home',        icon:'M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6' },
  { id:'attendance',  label:'Attendance',  icon:'M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4' },
  { id:'pace',        label:'PACE',        icon:'M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253' },
  { id:'merits',      label:'Merit Wallet',icon:'M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z' },
  { id:'messages',    label:'Messages',    icon:'M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z', badge:1 },
  { id:'shop',        label:'Shop',        icon:'M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z' },
  { id:'leaderboard', label:'Leaderboard', icon:'M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z' },
  { id:'clubs',       label:'Clubs',       icon:'M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z' },
];

const PARENT_MOBILE_NAV = ['home','attendance','merits','messages','clubs'];

const MY_CHILD = STUDENTS[0]; // Joshua Johnson

const PNavIcon = ({ path, active }) => (
  <svg width={18} height={18} viewBox="0 0 24 24" fill="none" stroke={active?C.crimson:'#94a3b8'} strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" style={{ flexShrink:0 }}>
    <path d={path} />
  </svg>
);

// ── Parent Home ──────────────────────────────────────────────────────────────
const ParentHome = ({ mobile, setPage }) => {
  const child = MY_CHILD;
  const totalMerits = child.merits.spend + child.merits.saving + child.merits.investment;
  const todayStatus = ATTENDANCE_TODAY[child.id];
  const myBehaviour = BEHAVIOUR_ENTRIES.filter(e => e.studentId === child.id);

  return (
    <div className="page-fade">
      <div style={{ marginBottom: 20 }}>
        <p style={{ fontSize: 13, color: C.textSecondary }}>Friday, 25 April 2026</p>
        <h2 style={{ fontSize: mobile ? 20 : 26, fontWeight: 800, color: C.navy, marginTop: 2 }}>Welcome, Mr & Mrs Johnson</h2>
        <p style={{ fontSize: 13, color: C.textSecondary, marginTop: 2 }}>Parent of Joshua Johnson</p>
      </div>

      {/* Child hero card */}
      <Card style={{ background: `linear-gradient(135deg, ${C.navy} 0%, ${C.navyLight} 100%)`, marginBottom: 20, borderColor: 'transparent' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 16, flexWrap: 'wrap' }}>
          <Avatar initials={child.initials} size={mobile ? 48 : 56} color={C.blue} />
          <div style={{ flex: 1 }}>
            <p style={{ fontSize: mobile ? 18 : 22, fontWeight: 800, color: '#fff', margin: 0 }}>{child.name}</p>
            <p style={{ fontSize: 13, color: 'rgba(255,255,255,0.7)', marginTop: 2 }}>{child.year} · Supervisor: {child.tutor}</p>
          </div>
          <div style={{ textAlign: 'right' }}>
            <p style={{ fontSize: 28, fontWeight: 800, color: C.blue, margin: 0 }}>{totalMerits}</p>
            <p style={{ fontSize: 11, color: 'rgba(255,255,255,0.6)', marginTop: 2 }}>total merits</p>
          </div>
        </div>
        <div style={{ display: 'flex', gap: 10, marginTop: 16, flexWrap: 'wrap' }}>
          {[['Today', todayStatus, todayStatus === 'Present' ? C.successBg : todayStatus === 'Late' ? C.warningBg : C.dangerBg, todayStatus === 'Present' ? C.success : todayStatus === 'Late' ? C.warning : C.danger], [`${child.pacesCompleted} PACEs`, 'Completed this year', 'rgba(255,255,255,0.12)', 'rgba(255,255,255,0.9)'], [`${child.tithe}%`, 'Tithe rate', 'rgba(255,255,255,0.12)', 'rgba(255,255,255,0.9)']].map(([val, label, bg, col]) => (
            <div key={label} style={{ flex: 1, minWidth: 80, background: bg, borderRadius: 8, padding: '10px 12px', textAlign: 'center' }}>
              <p style={{ fontSize: 16, fontWeight: 800, color: col, margin: 0 }}>{val}</p>
              <p style={{ fontSize: 10, color: typeof col === 'string' && col.includes('rgba') ? 'rgba(255,255,255,0.6)' : col, marginTop: 2 }}>{label}</p>
            </div>
          ))}
        </div>
      </Card>

      <div style={{ display: 'grid', gridTemplateColumns: mobile ? '1fr' : '1fr 1fr', gap: 16 }}>
        {/* Recent behaviour */}
        <Card>
          <p style={{ fontWeight: 700, fontSize: 14, color: C.navy, marginBottom: 12 }}>Recent Behaviour</p>
          {myBehaviour.length === 0
            ? <p style={{ fontSize: 13, color: C.textMuted }}>No entries today.</p>
            : myBehaviour.map(e => (
              <div key={e.id} style={{ display: 'flex', alignItems: 'flex-start', gap: 10, paddingBottom: 10, marginBottom: 10, borderBottom: `1px solid ${C.borderLight}` }}>
                <div style={{ width: 8, height: 8, borderRadius: '50%', background: e.type === 'Merit' ? C.success : C.danger, marginTop: 5, flexShrink: 0 }} />
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                    <Badge variant={e.type === 'Merit' ? 'green' : 'red'}>{e.delta > 0 ? `+${e.delta}` : e.delta} merits</Badge>
                    <span style={{ fontSize: 11, color: C.textMuted }}>{e.time}</span>
                  </div>
                  <p style={{ fontSize: 12, color: C.textSecondary, marginTop: 4 }}>{e.category} — {e.note.slice(0, 50)}{e.note.length > 50 ? '…' : ''}</p>
                </div>
              </div>
            ))
          }
          <button onClick={() => setPage('attendance')} style={{ fontSize: 12, color: C.blue, fontWeight: 600, background: 'none', border: 'none', cursor: 'pointer', fontFamily: 'inherit', paddingLeft: 0 }}>View full attendance →</button>
        </Card>

        {/* Merit snapshot */}
        <Card>
          <p style={{ fontWeight: 700, fontSize: 14, color: C.navy, marginBottom: 12 }}>Merit Wallet</p>
          {[['Spend', child.merits.spend, C.crimson], ['Saving', child.merits.saving, C.navy], ['Investment', child.merits.investment, C.blue]].map(([label, val, col]) => (
            <div key={label} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 0', borderBottom: `1px solid ${C.borderLight}` }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <div style={{ width: 10, height: 10, borderRadius: 3, background: col }} />
                <span style={{ fontSize: 13, color: C.textSecondary, fontWeight: 500 }}>{label} Account</span>
              </div>
              <span style={{ fontSize: 15, fontWeight: 700, color: col }}>{val}</span>
            </div>
          ))}
          <div style={{ paddingTop: 10 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span style={{ fontSize: 12, fontWeight: 700, color: C.textSecondary }}>TOTAL</span>
              <span style={{ fontSize: 18, fontWeight: 800, color: C.navy }}>{totalMerits}</span>
            </div>
          </div>
          <button onClick={() => setPage('merits')} style={{ fontSize: 12, color: C.blue, fontWeight: 600, background: 'none', border: 'none', cursor: 'pointer', fontFamily: 'inherit', paddingLeft: 0, marginTop: 8 }}>Manage wallet →</button>
        </Card>
      </div>
    </div>
  );
};

// ── Parent Attendance ────────────────────────────────────────────────────────
const ParentAttendance = ({ mobile }) => {
  const WEEK_DATA = [
    { day: 'Mon 21', status: 'Present' }, { day: 'Tue 22', status: 'Present' },
    { day: 'Wed 23', status: 'Present' }, { day: 'Thu 24', status: 'Late' },
    { day: 'Fri 25', status: 'Present' },
  ];
  const statColor = { Present: C.success, Late: C.warning, Absent: C.danger };
  const statBg    = { Present: C.successBg, Late: C.warningBg, Absent: C.dangerBg };

  return (
    <div className="page-fade">
      <h2 style={{ fontSize: mobile ? 18 : 22, fontWeight: 800, color: C.navy, marginBottom: 4 }}>Attendance</h2>
      <p style={{ fontSize: 13, color: C.textSecondary, marginBottom: 20 }}>Joshua Johnson · Spring Term 2</p>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 12, marginBottom: 20 }}>
        {[['92%', 'Attendance Rate', C.success], ['18', 'Days Present', C.blue], ['1', 'Late Arrivals', C.warning]].map(([v, l, c]) => (
          <StatCard key={l} label={l} value={v} accent={c} />
        ))}
      </div>

      <Card style={{ marginBottom: 16 }}>
        <p style={{ fontWeight: 700, fontSize: 14, color: C.navy, marginBottom: 14 }}>This Week</p>
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
          {WEEK_DATA.map(d => (
            <div key={d.day} style={{ flex: 1, minWidth: 60, background: statBg[d.status], borderRadius: 10, padding: '12px 8px', textAlign: 'center' }}>
              <p style={{ fontSize: 11, color: statColor[d.status], fontWeight: 700 }}>{d.day}</p>
              <div style={{ width: 10, height: 10, borderRadius: '50%', background: statColor[d.status], margin: '8px auto 6px' }} />
              <p style={{ fontSize: 10, color: statColor[d.status], fontWeight: 600 }}>{d.status}</p>
            </div>
          ))}
        </div>
      </Card>

      <Card>
        <p style={{ fontWeight: 700, fontSize: 14, color: C.navy, marginBottom: 14 }}>April 2026</p>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7,1fr)', gap: 4, textAlign: 'center' }}>
          {['M', 'T', 'W', 'T', 'F', 'S', 'S'].map((d, i) => <div key={i} style={{ fontSize: 11, fontWeight: 700, color: C.textMuted, padding: '4px 0' }}>{d}</div>)}
          {Array.from({ length: 30 }, (_, i) => i + 1).map(d => {
            const isWeekend = [5, 6, 12, 13, 19, 20, 26, 27].includes(d);
            const status = d === 24 ? 'Late' : isWeekend ? null : 'Present';
            const bg = isWeekend ? 'transparent' : status === 'Present' ? C.successBg : status === 'Late' ? C.warningBg : 'transparent';
            const col = isWeekend ? C.textMuted : status === 'Present' ? C.success : status === 'Late' ? C.warning : C.textMuted;
            return <div key={d} style={{ padding: '6px 2px', borderRadius: 6, background: bg, fontSize: 11, fontWeight: 600, color: col }}>{d}</div>;
          })}
        </div>
        <div style={{ display: 'flex', gap: 12, marginTop: 12, flexWrap: 'wrap' }}>
          {[['Present', C.successBg, C.success], ['Late', C.warningBg, C.warning], ['Absent', C.dangerBg, C.danger]].map(([l, bg, c]) => (
            <div key={l} style={{ display: 'flex', alignItems: 'center', gap: 6 }}><div style={{ width: 12, height: 12, borderRadius: 3, background: bg, border: `1px solid ${c}` }} /><span style={{ fontSize: 12, color: C.textSecondary }}>{l}</span></div>
          ))}
        </div>
      </Card>
    </div>
  );
};

// ── Parent PACE ──────────────────────────────────────────────────────────────
const ParentPACE = ({ mobile }) => (
  <div className="page-fade">
    <h2 style={{ fontSize: mobile ? 18 : 22, fontWeight: 800, color: C.navy, marginBottom: 4 }}>PACE Progress</h2>
    <p style={{ fontSize: 13, color: C.textSecondary, marginBottom: 20 }}>Joshua Johnson · {PACE_SUBJECTS.length} active subjects</p>
    <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
      {PACE_SUBJECTS.map((p, i) => (
        <Card key={i}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 12 }}>
            <div>
              <p style={{ fontWeight: 700, fontSize: 14, color: C.navy }}>{p.subject}</p>
              <p style={{ fontSize: 12, color: C.blue, fontWeight: 600, marginTop: 2 }}>PACE #{p.paceNumber}</p>
            </div>
            <Badge variant={p.status === 'Ahead' ? 'green' : p.status === 'On Track' ? 'blue' : 'red'}>{p.status}</Badge>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 8 }}>
            {[['Self-Test', p.selfTest, '%'], ['PACE Test', p.paceTest, '%'], ['Completed', p.completedAt, '']].map(([label, val, suffix]) => (
              <div key={label} style={{ background: C.bg, borderRadius: 8, padding: '8px 10px', textAlign: 'center' }}>
                <p style={{ fontSize: 16, fontWeight: 800, color: typeof val === 'number' ? (val >= 90 ? C.success : val >= 75 ? C.warning : C.danger) : C.navy }}>{val}{suffix}</p>
                <p style={{ fontSize: 10, color: C.textMuted, marginTop: 2 }}>{label}</p>
              </div>
            ))}
          </div>
          {/* Progress bar */}
          <div style={{ marginTop: 12 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
              <span style={{ fontSize: 11, color: C.textSecondary }}>PACE progress</span>
              <span style={{ fontSize: 11, fontWeight: 700, color: C.navy }}>{p.paceTest}%</span>
            </div>
            <div style={{ height: 6, background: C.bg, borderRadius: 4, overflow: 'hidden' }}>
              <div style={{ height: '100%', width: `${p.paceTest}%`, background: p.paceTest >= 90 ? C.success : p.paceTest >= 75 ? C.blue : C.warning, borderRadius: 4, transition: 'width 0.5s ease' }} />
            </div>
          </div>
        </Card>
      ))}
    </div>
  </div>
);

// ── Parent Merit Wallet ──────────────────────────────────────────────────────
const ParentMeritWallet = ({ mobile }) => {
  const child = MY_CHILD;
  const [tithe, setTithe] = React.useState(child.tithe);
  const investReturn = 10.4;

  const RECENT = [
    { desc: 'Scripture Memory — Psalm 23', type: 'credit', account: 'Spend', amount: +10, date: 'Today 09:15' },
    { desc: 'Weekly tithe (10%)', type: 'debit', account: 'TithePaid', amount: -8, date: 'Mon 21 Apr' },
    { desc: 'Transfer to Saving', type: 'transfer', account: 'Saving', amount: -30, date: 'Mon 21 Apr' },
    { desc: 'Investment unit purchase', type: 'transfer', account: 'Investment', amount: -20, date: 'Fri 18 Apr' },
    { desc: 'Hot Chocolate — Merit Shop', type: 'debit', account: 'Spend', amount: -25, date: 'Thu 17 Apr' },
    { desc: 'Helpfulness award', type: 'credit', account: 'Spend', amount: +5, date: 'Thu 17 Apr' },
  ];

  return (
    <div className="page-fade">
      <h2 style={{ fontSize: mobile ? 18 : 22, fontWeight: 800, color: C.navy, marginBottom: 4 }}>Merit Wallet</h2>
      <p style={{ fontSize: 13, color: C.textSecondary, marginBottom: 20 }}>Joshua Johnson</p>

      {/* Three account cards */}
      <div style={{ display: 'grid', gridTemplateColumns: mobile ? '1fr' : '1fr 1fr 1fr', gap: 12, marginBottom: 20 }}>
        <Card style={{ borderTop: `3px solid ${C.crimson}` }}>
          <p style={{ fontSize: 11, fontWeight: 700, color: C.textSecondary, textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: 6 }}>Spend Account</p>
          <p style={{ fontSize: 32, fontWeight: 800, color: C.crimson }}>{child.merits.spend}</p>
          <p style={{ fontSize: 11, color: C.textMuted, marginTop: 4 }}>Available in Merit Shop</p>
          <div style={{ marginTop: 12, padding: '8px', background: C.crimsonLight, borderRadius: 6, fontSize: 11, color: C.crimson, fontWeight: 600 }}>+5 merits today</div>
        </Card>
        <Card style={{ borderTop: `3px solid ${C.navy}` }}>
          <p style={{ fontSize: 11, fontWeight: 700, color: C.textSecondary, textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: 6 }}>Saving Account</p>
          <p style={{ fontSize: 32, fontWeight: 800, color: C.navy }}>{child.merits.saving}</p>
          <p style={{ fontSize: 11, color: C.textMuted, marginTop: 4 }}>Transferred from Spend</p>
          <div style={{ marginTop: 12, padding: '8px', background: C.blueLight, borderRadius: 6, fontSize: 11, color: C.navy, fontWeight: 600 }}>No interest · safe storage</div>
        </Card>
        <Card style={{ borderTop: `3px solid ${C.blue}` }}>
          <p style={{ fontSize: 11, fontWeight: 700, color: C.textSecondary, textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: 6 }}>Investment Account</p>
          <p style={{ fontSize: 32, fontWeight: 800, color: C.blue }}>{child.merits.investment}</p>
          <p style={{ fontSize: 11, color: C.textMuted, marginTop: 4 }}>~10% p.a. avg return</p>
          <div style={{ marginTop: 12, padding: '8px', background: C.successBg, borderRadius: 6, fontSize: 11, color: C.success, fontWeight: 600 }}>+{investReturn}% this year</div>
        </Card>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: mobile ? '1fr' : '1fr 1fr', gap: 16 }}>
        {/* Tithe config */}
        <Card>
          <p style={{ fontWeight: 700, fontSize: 14, color: C.navy, marginBottom: 4 }}>Weekly Tithe Rate</p>
          <p style={{ fontSize: 12, color: C.textSecondary, marginBottom: 14 }}>Applied to weekly merit earnings. You can adjust this rate.</p>
          <div style={{ display: 'flex', gap: 8, marginBottom: 14 }}>
            {[10, 15, 20].map(pct => (
              <button key={pct} onClick={() => setTithe(pct)} style={{ flex: 1, padding: '10px', borderRadius: 8, border: `2px solid ${tithe === pct ? C.crimson : C.border}`, background: tithe === pct ? C.crimsonLight : 'transparent', color: tithe === pct ? C.crimson : C.textSecondary, fontWeight: 700, fontSize: 15, cursor: 'pointer', fontFamily: 'inherit', transition: 'all 0.15s' }}>{pct}%</button>
            ))}
          </div>
          <div style={{ padding: '10px 12px', background: C.bg, borderRadius: 8, fontSize: 12, color: C.textSecondary }}>
            At <strong>{tithe}%</strong>, next week's tithe estimate: approx. <strong style={{ color: C.crimson }}>{Math.round(15 * tithe / 100)} merits</strong> (based on last week's earning of 15 merits)
          </div>
        </Card>

        {/* Recent transactions */}
        <Card>
          <p style={{ fontWeight: 700, fontSize: 14, color: C.navy, marginBottom: 12 }}>Recent Transactions</p>
          {RECENT.map((t, i) => (
            <div key={i} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '8px 0', borderBottom: i < RECENT.length - 1 ? `1px solid ${C.borderLight}` : '' }}>
              <div style={{ flex: 1, minWidth: 0 }}>
                <p style={{ fontSize: 12, fontWeight: 600, color: C.textPrimary, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{t.desc}</p>
                <p style={{ fontSize: 10, color: C.textMuted, marginTop: 1 }}>{t.date}</p>
              </div>
              <span style={{ fontSize: 13, fontWeight: 700, color: t.amount > 0 ? C.success : C.danger, marginLeft: 12 }}>{t.amount > 0 ? `+${t.amount}` : t.amount}</span>
            </div>
          ))}
        </Card>
      </div>
    </div>
  );
};

// ── Parent Messages ──────────────────────────────────────────────────────────
const ParentMessages = ({ mobile }) => {
  const [reply, setReply] = React.useState('');
  const myMessages = [
    { id: 1, from: 'Mrs Thompson', role: 'Head of Centre', preview: "Joshua did exceptionally well in his Bible PACE test today — we're very proud of his dedication.", time: 'Today', unread: true, body: "Joshua did exceptionally well in his Bible PACE test today — scored 98%! We're very proud of his dedication and scripture memory work. He's been a wonderful example to the other students this week. Please do encourage him at home — it's making a real difference." },
    { id: 2, from: 'Mr Osei', role: 'Supervisor', preview: "Just a reminder that the Merit Shop opens Monday 28th. Joshua has a great balance to spend!", time: 'Wed', unread: false, body: "Just a quick note to remind you that the Merit Shop opens on Monday 28th April. Joshua has built up a wonderful merit balance and will have plenty to spend. We'll also be introducing some new items this term — keep an eye on the shop tab!" },
  ];
  const [selected, setSelected] = React.useState(mobile ? null : myMessages[0]);

  if (mobile) {
    if (selected) return (
      <div className="page-fade" style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
        <button onClick={() => setSelected(null)} style={{ display: 'flex', alignItems: 'center', gap: 6, background: 'none', border: 'none', color: C.blue, fontWeight: 600, fontSize: 13, cursor: 'pointer', marginBottom: 12, fontFamily: 'inherit' }}>← Back</button>
        <Card style={{ marginBottom: 12 }}><p style={{ fontWeight: 700, fontSize: 14, color: C.navy }}>{selected.from}</p><p style={{ fontSize: 12, color: C.textSecondary }}>{selected.role}</p></Card>
        <Card style={{ flex: 1, marginBottom: 12, overflow: 'auto' }}><p style={{ fontSize: 13, color: C.textPrimary, lineHeight: 1.7 }}>{selected.body}</p></Card>
        <div style={{ display: 'flex', gap: 8 }}>
          <input value={reply} onChange={e => setReply(e.target.value)} placeholder="Reply to {selected.from}…" style={{ flex: 1, padding: '10px 14px', border: `1.5px solid ${C.border}`, borderRadius: 8, fontSize: 13, fontFamily: 'inherit', outline: 'none' }} />
          <Btn variant="primary">Send</Btn>
        </div>
      </div>
    );
    return (
      <div className="page-fade">
        <h2 style={{ fontSize: 18, fontWeight: 800, color: C.navy, marginBottom: 14 }}>Messages</h2>
        {myMessages.map(m => (
          <Card key={m.id} style={{ marginBottom: 10, cursor: 'pointer', borderLeft: m.unread ? `3px solid ${C.crimson}` : '' }} padding={14} onClick={() => setSelected(m)}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
              <p style={{ fontWeight: 700, fontSize: 13, color: C.navy }}>{m.from}</p>
              <span style={{ fontSize: 11, color: C.textMuted }}>{m.time}</span>
            </div>
            <p style={{ fontSize: 12, color: C.textSecondary }}>{m.preview}</p>
          </Card>
        ))}
        <div style={{ marginTop: 16 }}>
          <Btn variant="primary" style={{ width: '100%', justifyContent: 'center' }}>+ New Message to Staff</Btn>
        </div>
      </div>
    );
  }

  return (
    <div className="page-fade">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
        <h2 style={{ fontSize: 22, fontWeight: 800, color: C.navy }}>Messages</h2>
        <Btn variant="primary">+ New Message</Btn>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '280px 1fr', gap: 16, minHeight: 480 }}>
        <Card padding={0}>
          {myMessages.map((m, i) => (
            <div key={m.id} onClick={() => setSelected(m)} style={{ padding: '14px 16px', borderBottom: i < myMessages.length - 1 ? `1px solid ${C.border}` : '', cursor: 'pointer', background: selected?.id === m.id ? C.bg : '', borderLeft: m.unread ? `3px solid ${C.crimson}` : '' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
                <p style={{ fontWeight: 700, fontSize: 13, color: C.navy }}>{m.from}</p>
                <span style={{ fontSize: 11, color: C.textMuted }}>{m.time}</span>
              </div>
              <p style={{ fontSize: 12, color: C.textSecondary }}>{m.role}</p>
              <p style={{ fontSize: 11, color: C.textMuted, marginTop: 4 }}>{m.preview.slice(0, 55)}…</p>
            </div>
          ))}
        </Card>
        {selected ? (
          <Card style={{ display: 'flex', flexDirection: 'column' }}>
            <div style={{ marginBottom: 16, paddingBottom: 16, borderBottom: `1px solid ${C.border}` }}>
              <p style={{ fontWeight: 700, fontSize: 16, color: C.navy }}>{selected.from}</p>
              <p style={{ fontSize: 12, color: C.textSecondary }}>{selected.role}</p>
            </div>
            <p style={{ fontSize: 14, color: C.textPrimary, lineHeight: 1.7, flex: 1 }}>{selected.body}</p>
            <div style={{ marginTop: 20, paddingTop: 16, borderTop: `1px solid ${C.border}`, display: 'flex', gap: 10 }}>
              <input value={reply} onChange={e => setReply(e.target.value)} placeholder="Type your reply…" style={{ flex: 1, padding: '10px 14px', border: `1.5px solid ${C.border}`, borderRadius: 8, fontSize: 13, fontFamily: 'inherit', outline: 'none' }} />
              <Btn variant="primary">Send</Btn>
            </div>
          </Card>
        ) : <Card style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}><p style={{ color: C.textMuted }}>Select a message</p></Card>}
      </div>
    </div>
  );
};

// ── Parent Shop ──────────────────────────────────────────────────────────────
const ParentShop = ({ mobile }) => {
  const child = MY_CHILD;
  return (
    <div className="page-fade">
      <div style={{ marginBottom: 20 }}>
        <h2 style={{ fontSize: mobile ? 18 : 22, fontWeight: 800, color: C.navy }}>Merit Shop</h2>
        <p style={{ fontSize: 13, color: C.textSecondary, marginTop: 2 }}>Joshua's Spend Balance: <strong style={{ color: C.crimson }}>{child.merits.spend} merits</strong></p>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: mobile ? '1fr 1fr' : 'repeat(3,1fr)', gap: 12 }}>
        {SHOP_ITEMS.filter(i => i.active).map(item => {
          const canAfford = child.merits.spend >= item.price;
          return (
            <Card key={item.id} style={{ opacity: canAfford ? 1 : 0.6 }}>
              <div style={{ height: 70, background: `linear-gradient(135deg,${C.blueLight},${C.bg})`, borderRadius: 8, marginBottom: 12, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 10, color: C.textMuted, fontFamily: 'monospace' }}>item photo</div>
              <p style={{ fontWeight: 700, fontSize: 13, color: C.navy, marginBottom: 6 }}>{item.name}</p>
              <p style={{ fontSize: 11, color: C.textMuted, marginBottom: 8 }}>Stock: {item.stock}</p>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <span style={{ fontWeight: 800, fontSize: 16, color: C.crimson }}>{item.price}</span>
                <Badge variant={canAfford ? 'blue' : 'grey'}>{canAfford ? 'Can afford' : 'Save more'}</Badge>
              </div>
            </Card>
          );
        })}
      </div>
      <p style={{ fontSize: 12, color: C.textMuted, marginTop: 16, textAlign: 'center' }}>Purchases are completed in-centre by a staff shopkeeper.</p>
    </div>
  );
};

// ── Parent Leaderboard ───────────────────────────────────────────────────────
const ParentLeaderboard = ({ mobile }) => {
  const [tab, setTab] = React.useState('tithers');
  const sorted = {
    tithers: [...STUDENTS].sort((a, b) => (b.merits.spend + b.merits.saving + b.merits.investment) * b.tithe / 100 - (a.merits.spend + a.merits.saving + a.merits.investment) * a.tithe / 100),
    investors: [...STUDENTS].sort((a, b) => b.merits.investment - a.merits.investment),
    savers: [...STUDENTS].sort((a, b) => b.merits.saving - a.merits.saving),
  };
  const vals = { tithers: s => Math.round((s.merits.spend + s.merits.saving + s.merits.investment) * s.tithe / 100) + ' tithed', investors: s => s.merits.investment + ' invested', savers: s => s.merits.saving + ' saved' };
  const medals = ['🥇', '🥈', '🥉'];
  const myRank = { tithers: sorted.tithers.findIndex(s => s.id === MY_CHILD.id) + 1, investors: sorted.investors.findIndex(s => s.id === MY_CHILD.id) + 1, savers: sorted.savers.findIndex(s => s.id === MY_CHILD.id) + 1 };

  return (
    <div className="page-fade">
      <h2 style={{ fontSize: mobile ? 18 : 22, fontWeight: 800, color: C.navy, marginBottom: 20 }}>Leaderboard</h2>
      <div style={{ display: 'flex', gap: 4, marginBottom: 16, background: C.bg, borderRadius: 10, padding: 4 }}>
        {[['tithers', 'Top Tithers'], ['investors', 'Top Investors'], ['savers', 'Top Savers']].map(([id, label]) => (
          <button key={id} onClick={() => setTab(id)} style={{ flex: 1, padding: '8px 12px', borderRadius: 7, border: 'none', background: tab === id ? C.navy : 'transparent', color: tab === id ? '#fff' : C.textSecondary, fontWeight: 600, fontSize: 12, cursor: 'pointer', fontFamily: 'inherit' }}>{label}</button>
        ))}
      </div>
      <div style={{ padding: '10px 14px', background: C.blueLight, borderRadius: 8, marginBottom: 14, fontSize: 13, color: C.navy, fontWeight: 600 }}>
        Joshua is ranked #{myRank[tab]} on this board
      </div>
      <Card padding={0}>
        {sorted[tab].map((s, i) => (
          <div key={s.id} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '14px 16px', borderBottom: i < 9 ? `1px solid ${C.border}` : '', background: s.id === MY_CHILD.id ? C.blueLight : '' }}>
            <span style={{ fontSize: i < 3 ? 20 : 14, width: 28, textAlign: 'center', fontWeight: 700, color: i < 3 ? '' : C.textMuted }}>{i < 3 ? medals[i] : `#${i + 1}`}</span>
            <Avatar initials={s.initials} size={32} color={s.color} />
            <div style={{ flex: 1 }}>
              <p style={{ fontWeight: s.id === MY_CHILD.id ? 700 : 600, fontSize: 13, color: C.navy }}>{s.name}{s.id === MY_CHILD.id ? ' (Joshua)' : ''}</p>
              <p style={{ fontSize: 11, color: C.textSecondary }}>{s.year}</p>
            </div>
            <p style={{ fontWeight: 700, fontSize: 13, color: C.blue }}>{vals[tab](s)}</p>
          </div>
        ))}
      </Card>
    </div>
  );
};

// ── Parent Clubs ─────────────────────────────────────────────────────────────
const ParentClubs = ({ mobile }) => {
  const [enrolled, setEnrolled] = React.useState([4]); // Joshua enrolled in Scripture Union

  return (
    <div className="page-fade">
      <h2 style={{ fontSize: mobile ? 18 : 22, fontWeight: 800, color: C.navy, marginBottom: 4 }}>Clubs & Activities</h2>
      <p style={{ fontSize: 13, color: C.textSecondary, marginBottom: 20 }}>Sign Joshua up for after-school clubs</p>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
        {CLUBS.map(club => {
          const isEnrolled = enrolled.includes(club.id);
          const isFull = club.enrolled >= club.capacity;
          return (
            <Card key={club.id}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 12 }}>
                <div style={{ flex: 1 }}>
                  <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 4 }}>
                    <p style={{ fontWeight: 700, fontSize: 14, color: C.navy }}>{club.name}</p>
                    {isEnrolled && <Badge variant="green">Enrolled</Badge>}
                    {isFull && !isEnrolled && <Badge variant="red">Full</Badge>}
                  </div>
                  <p style={{ fontSize: 12, color: C.textSecondary }}>{club.day} · {club.time}</p>
                  <p style={{ fontSize: 11, color: C.textMuted, marginTop: 4 }}>{club.enrolled}/{club.capacity} places filled</p>
                </div>
                <Btn
                  variant={isEnrolled ? 'secondary' : isFull ? 'ghost' : 'primary'}
                  size="sm"
                  disabled={isFull && !isEnrolled}
                  onClick={() => setEnrolled(e => isEnrolled ? e.filter(id => id !== club.id) : [...e, club.id])}
                >
                  {isEnrolled ? 'Withdraw' : isFull ? 'Full' : 'Sign Up'}
                </Btn>
              </div>
            </Card>
          );
        })}
      </div>
    </div>
  );
};

// ── Parent Self-Profile Page ─────────────────────────────────────────────────
const ParentSelfProfile = ({ mobile, onLogout }) => {
  const parent = {
    firstName: 'Robert', lastName: 'Johnson', initials: 'RJ',
    email: 'parent@oasis.school', phone: '07700 901111',
    address: '22 Birch Road, Birmingham, B20 3NN',
    emergencyContact: 'Mrs Sarah Johnson — 07700 902222',
    preferredContact: 'Email',
    gdprConsent: true, photoConsent: true, twoFA: true,
  };
  const [editing, setEditing] = React.useState(false);
  const [form, setForm]       = React.useState({ ...parent });
  const [saved, setSaved]     = React.useState(false);
  const [tab, setTab]         = React.useState('account');
  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));
  const handleSave = () => { setSaved(true); setEditing(false); setTimeout(() => setSaved(false), 3000); };

  const FRow = ({ label, value, editKey, type = 'text', readOnly }) => (
    <div style={{ display: 'grid', gridTemplateColumns: mobile ? '1fr' : '140px 1fr', gap: mobile ? 4 : 12, padding: '11px 0', borderBottom: `1px solid ${C.borderLight}`, alignItems: mobile ? 'flex-start' : 'center' }}>
      <p style={{ fontSize: 11, fontWeight: 700, color: C.textSecondary, textTransform: 'uppercase', letterSpacing: '0.4px' }}>{label}</p>
      {editing && !readOnly
        ? <input type={type} value={form[editKey] || ''} onChange={e => set(editKey, e.target.value)}
            style={{ padding: '8px 10px', border: `1.5px solid ${C.border}`, borderRadius: 7, fontSize: 13, fontFamily: 'inherit', color: C.textPrimary, outline: 'none', width: '100%' }} />
        : <p style={{ fontSize: 13, color: value ? C.textPrimary : C.textMuted, fontStyle: value ? 'normal' : 'italic' }}>{value || 'Not set'}</p>
      }
    </div>
  );

  const Toggle = ({ label, desc, val, onChange }) => (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '12px 0', borderBottom: `1px solid ${C.borderLight}`, gap: 12 }}>
      <div>
        <p style={{ fontSize: 13, fontWeight: 600, color: C.textPrimary }}>{label}</p>
        {desc && <p style={{ fontSize: 11, color: C.textMuted, marginTop: 2 }}>{desc}</p>}
      </div>
      <button onClick={() => editing && onChange(!val)} style={{
        width: 40, height: 22, borderRadius: 11, border: 'none', cursor: editing ? 'pointer' : 'default',
        background: val ? C.success : C.border, position: 'relative', flexShrink: 0, transition: 'background 0.2s',
      }}>
        <div style={{ width: 16, height: 16, borderRadius: '50%', background: '#fff', position: 'absolute', top: 3, left: val ? 21 : 3, transition: 'left 0.2s', boxShadow: '0 1px 3px rgba(0,0,0,0.2)' }} />
      </button>
    </div>
  );

  const tabs = [['account','My Account'], ['children','My Children'], ['privacy','Privacy & Consent'], ['security','Security']];

  return (
    <div className="page-fade">
      {/* Hero */}
      <Card style={{ background: `linear-gradient(130deg, ${C.crimson} 0%, #9B2235 100%)`, border: 'none', marginBottom: 20 }} padding={mobile ? 16 : 24}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 16, flexWrap: 'wrap' }}>
          <div style={{ position: 'relative' }}>
            <Avatar initials={form.initials || 'RJ'} size={mobile ? 48 : 60} color="rgba(255,255,255,0.2)" />
            {editing && <div style={{ position: 'absolute', inset: 0, borderRadius: '50%', background: 'rgba(0,0,0,0.3)', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}><span style={{ fontSize: 9, color: '#fff', fontWeight: 700 }}>CHANGE</span></div>}
          </div>
          <div style={{ flex: 1 }}>
            <p style={{ fontSize: mobile ? 18 : 22, fontWeight: 800, color: '#fff', margin: 0 }}>{form.firstName} {form.lastName}</p>
            <p style={{ fontSize: 13, color: 'rgba(255,255,255,0.7)', marginTop: 3 }}>Parent / Guardian · Oasis Learning Centre</p>
            <div style={{ display: 'flex', gap: 8, marginTop: 10, flexWrap: 'wrap' }}>
              <div style={{ background: 'rgba(255,255,255,0.15)', borderRadius: 6, padding: '4px 10px', fontSize: 11, color: 'rgba(255,255,255,0.9)', fontWeight: 600 }}>👦 Joshua Johnson · Y9</div>
              {form.twoFA && <div style={{ background: 'rgba(255,255,255,0.15)', borderRadius: 6, padding: '4px 10px', fontSize: 11, color: 'rgba(255,255,255,0.9)', fontWeight: 600 }}>🔒 2FA Active</div>}
            </div>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8, alignItems: 'flex-end' }}>
            {!editing
              ? <button onClick={() => setEditing(true)} style={{ padding: '8px 16px', background: 'rgba(255,255,255,0.2)', border: '1.5px solid rgba(255,255,255,0.3)', borderRadius: 8, color: '#fff', fontSize: 12, fontWeight: 700, cursor: 'pointer', fontFamily: 'inherit' }}>Edit Profile</button>
              : <div style={{ display: 'flex', gap: 8 }}>
                  <button onClick={() => { setForm({ ...parent }); setEditing(false); }} style={{ padding: '8px 14px', background: 'rgba(255,255,255,0.1)', border: '1.5px solid rgba(255,255,255,0.2)', borderRadius: 8, color: 'rgba(255,255,255,0.8)', fontSize: 12, fontWeight: 700, cursor: 'pointer', fontFamily: 'inherit' }}>Cancel</button>
                  <button onClick={handleSave} style={{ padding: '8px 14px', background: C.success, border: 'none', borderRadius: 8, color: '#fff', fontSize: 12, fontWeight: 700, cursor: 'pointer', fontFamily: 'inherit' }}>Save</button>
                </div>
            }
            {saved && <span style={{ fontSize: 11, color: 'rgba(255,255,255,0.8)', fontWeight: 600 }}>✓ Saved</span>}
          </div>
        </div>
      </Card>

      {/* Tabs */}
      <div style={{ display: 'flex', gap: 2, marginBottom: 20, background: C.bg, borderRadius: 10, padding: 4, width: 'fit-content', overflowX: 'auto' }}>
        {tabs.map(([id, label]) => (
          <button key={id} onClick={() => setTab(id)} style={{ padding: '8px 16px', borderRadius: 7, border: 'none', cursor: 'pointer', fontFamily: 'inherit', fontWeight: 600, fontSize: 12, transition: 'all 0.15s', whiteSpace: 'nowrap',
            background: tab === id ? C.crimson : 'transparent', color: tab === id ? '#fff' : C.textSecondary }}>{label}</button>
        ))}
      </div>

      {/* Tab: My Account */}
      {tab === 'account' && (
        <Card padding={16}>
          <FRow label="First name"        value={form.firstName}         editKey="firstName" />
          <FRow label="Last name"         value={form.lastName}          editKey="lastName" />
          <FRow label="Email address"     value={form.email}             editKey="email"     type="email" />
          <FRow label="Phone number"      value={form.phone}             editKey="phone"     type="tel" />
          <FRow label="Home address"      value={form.address}           editKey="address" />
          <FRow label="Emergency contact" value={form.emergencyContact}  editKey="emergencyContact" />
          <FRow label="Preferred contact" value={form.preferredContact}  readOnly />
          {!editing && (
            <div style={{ paddingTop: 14, display: 'flex', gap: 8 }}>
              <button onClick={() => setEditing(true)} style={{ padding: '9px 18px', background: C.crimson, border: 'none', borderRadius: 8, color: '#fff', fontSize: 13, fontWeight: 700, cursor: 'pointer', fontFamily: 'inherit' }}>Edit My Details</button>
            </div>
          )}
        </Card>
      )}

      {/* Tab: My Children */}
      {tab === 'children' && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          {/* Child card */}
          {[STUDENTS[0]].map(child => {
            const totalMerits = child.merits.spend + child.merits.saving + child.merits.investment;
            const att = ATTENDANCE_TODAY[child.id];
            return (
              <Card key={child.id} style={{ borderLeft: `4px solid ${child.color}` }} padding={mobile ? 14 : 20}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 16 }}>
                  <Avatar initials={child.initials} size={48} color={child.color} />
                  <div style={{ flex: 1 }}>
                    <p style={{ fontSize: 17, fontWeight: 800, color: C.navy }}>{child.name}</p>
                    <p style={{ fontSize: 12, color: C.textSecondary, marginTop: 2 }}>{child.year} · Supervisor: {child.tutor} · Enrolled Jan 2024</p>
                  </div>
                  <Badge variant={att === 'Present' ? 'green' : att === 'Late' ? 'amber' : 'red'}>{att}</Badge>
                </div>
                <div style={{ display: 'grid', gridTemplateColumns: mobile ? '1fr 1fr' : 'repeat(4,1fr)', gap: 10, marginBottom: 14 }}>
                  {[
                    ['Total Merits', totalMerits, C.blue],
                    ['Spend', child.merits.spend, C.crimson],
                    ['Saving', child.merits.saving, C.navy],
                    ['Investment', child.merits.investment, '#5B90C5'],
                  ].map(([l, v, col]) => (
                    <div key={l} style={{ background: C.bg, borderRadius: 8, padding: '10px', textAlign: 'center' }}>
                      <p style={{ fontSize: 20, fontWeight: 800, color: col }}>{v}</p>
                      <p style={{ fontSize: 10, color: C.textMuted, marginTop: 2 }}>{l}</p>
                    </div>
                  ))}
                </div>
                <div style={{ display: 'grid', gridTemplateColumns: mobile ? '1fr' : '1fr 1fr', gap: 10 }}>
                  <div style={{ background: C.bg, borderRadius: 8, padding: '12px 14px' }}>
                    <p style={{ fontSize: 11, fontWeight: 700, color: C.textSecondary, marginBottom: 6, textTransform: 'uppercase', letterSpacing: '0.4px' }}>Tithe Rate</p>
                    <p style={{ fontSize: 20, fontWeight: 800, color: C.navy }}>{child.tithe}%</p>
                    <p style={{ fontSize: 11, color: C.textMuted, marginTop: 2 }}>Applied to weekly merit earnings</p>
                  </div>
                  <div style={{ background: C.bg, borderRadius: 8, padding: '12px 14px' }}>
                    <p style={{ fontSize: 11, fontWeight: 700, color: C.textSecondary, marginBottom: 6, textTransform: 'uppercase', letterSpacing: '0.4px' }}>PACEs This Year</p>
                    <p style={{ fontSize: 20, fontWeight: 800, color: C.navy }}>{child.pacesCompleted}</p>
                    <p style={{ fontSize: 11, color: C.textMuted, marginTop: 2 }}>Completed PACEs</p>
                  </div>
                </div>
                {/* Recent behaviour for this child */}
                <div style={{ marginTop: 14, paddingTop: 14, borderTop: `1px solid ${C.border}` }}>
                  <p style={{ fontSize: 12, fontWeight: 700, color: C.textSecondary, textTransform: 'uppercase', letterSpacing: '0.4px', marginBottom: 10 }}>Recent Activity</p>
                  {BEHAVIOUR_ENTRIES.filter(e => e.studentId === child.id).slice(0, 3).map(e => (
                    <div key={e.id} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '7px 0', borderBottom: `1px solid ${C.borderLight}` }}>
                      <div style={{ width: 32, height: 32, borderRadius: 8, background: e.delta > 0 ? C.successBg : C.dangerBg, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                        <span style={{ fontSize: 11, fontWeight: 800, color: e.delta > 0 ? C.success : C.danger }}>{e.delta > 0 ? `+${e.delta}` : e.delta}</span>
                      </div>
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <p style={{ fontSize: 12, fontWeight: 600, color: C.navy }}>{e.category}</p>
                        <p style={{ fontSize: 11, color: C.textSecondary, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{e.note}</p>
                      </div>
                      <span style={{ fontSize: 11, color: C.textMuted, whiteSpace: 'nowrap' }}>{e.time}</span>
                    </div>
                  ))}
                </div>
              </Card>
            );
          })}
          <Card padding={16} style={{ background: C.bg, border: `1.5px dashed ${C.border}`, textAlign: 'center' }}>
            <p style={{ fontSize: 13, color: C.textMuted, marginBottom: 8 }}>Have another child enrolled at Oasis?</p>
            <p style={{ fontSize: 12, color: C.textMuted, marginBottom: 12 }}>Contact the Head of Centre to link additional children to your account.</p>
            <button style={{ padding: '8px 18px', background: C.navy, border: 'none', borderRadius: 8, color: '#fff', fontSize: 12, fontWeight: 700, cursor: 'pointer', fontFamily: 'inherit' }}>Contact Mrs Thompson</button>
          </Card>
        </div>
      )}

      {/* Tab: Privacy & Consent */}
      {tab === 'privacy' && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          <Card padding={16}>
            <p style={{ fontSize: 13, fontWeight: 700, color: C.navy, marginBottom: 4 }}>Data & Privacy Preferences</p>
            <p style={{ fontSize: 12, color: C.textSecondary, marginBottom: 14, lineHeight: 1.6 }}>Oasis Learning Centre stores your family's data securely in accordance with UK GDPR. You can review and update your consent preferences below. For full data deletion requests, please contact the Head of Centre.</p>
            <Toggle label="GDPR data processing consent" desc="Required for enrolment. Allows the centre to process your child's educational records." val={form.gdprConsent} onChange={v => set('gdprConsent', v)} />
            <Toggle label="Photography & media consent" desc="Allows photos of your child to be used in centre materials and communications." val={form.photoConsent} onChange={v => set('photoConsent', v)} />
            {!form.photoConsent && (
              <div style={{ marginTop: 12, padding: '10px 14px', background: C.warningBg, borderRadius: 8, border: `1px solid ${C.warning}33` }}>
                <p style={{ fontSize: 12, fontWeight: 700, color: C.warning }}>Photography consent withheld</p>
                <p style={{ fontSize: 11, color: C.warning, marginTop: 2 }}>Staff have been notified. Joshua will not appear in any published photographs.</p>
              </div>
            )}
            {editing && (
              <div style={{ marginTop: 14 }}>
                <button onClick={handleSave} style={{ padding: '9px 20px', background: C.success, border: 'none', borderRadius: 8, color: '#fff', fontSize: 13, fontWeight: 700, cursor: 'pointer', fontFamily: 'inherit' }}>Save Preferences</button>
              </div>
            )}
          </Card>
          <Card padding={16}>
            <p style={{ fontSize: 13, fontWeight: 700, color: C.navy, marginBottom: 8 }}>Your Rights</p>
            {[['Right of Access', 'Request a copy of all data held about your family.'], ['Right to Rectification', 'Correct any inaccurate information — use Edit Profile above.'], ['Right to Erasure', 'Request deletion of data when your child leaves the centre.'], ['Data Retention', "Children's records are retained for 5 years after the end of enrolment."]].map(([title, desc]) => (
              <div key={title} style={{ padding: '10px 0', borderBottom: `1px solid ${C.borderLight}` }}>
                <p style={{ fontSize: 12, fontWeight: 700, color: C.navy }}>{title}</p>
                <p style={{ fontSize: 12, color: C.textSecondary, marginTop: 2 }}>{desc}</p>
              </div>
            ))}
          </Card>
        </div>
      )}

      {/* Tab: Security */}
      {tab === 'security' && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          <Card padding={16}>
            <p style={{ fontSize: 13, fontWeight: 700, color: C.navy, marginBottom: 14 }}>Account Security</p>
            <Toggle label="Two-factor authentication (2FA)" desc="Adds an extra layer of security via authenticator app or SMS." val={form.twoFA} onChange={v => set('twoFA', v)} />
            <div style={{ padding: '12px 0', borderBottom: `1px solid ${C.borderLight}` }}>
              <p style={{ fontSize: 12, fontWeight: 700, color: C.navy }}>Last sign-in</p>
              <p style={{ fontSize: 13, color: C.textSecondary, marginTop: 3 }}>Today, 08:32 · Birmingham, UK</p>
            </div>
            <div style={{ padding: '12px 0' }}>
              <p style={{ fontSize: 12, fontWeight: 700, color: C.navy }}>Account email</p>
              <p style={{ fontSize: 13, color: C.textSecondary, marginTop: 3 }}>{form.email}</p>
            </div>
          </Card>
          <Card padding={16}>
            <p style={{ fontSize: 13, fontWeight: 700, color: C.navy, marginBottom: 12 }}>Password & Access</p>
            <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
              <button style={{ padding: '9px 16px', background: C.bg, border: `1.5px solid ${C.border}`, borderRadius: 8, fontSize: 12, fontWeight: 700, color: C.navy, cursor: 'pointer', fontFamily: 'inherit' }}>Change Password</button>
              <button onClick={onLogout} style={{ padding: '9px 16px', background: C.dangerBg, border: `1.5px solid ${C.dangerMid}`, borderRadius: 8, fontSize: 12, fontWeight: 700, color: C.danger, cursor: 'pointer', fontFamily: 'inherit' }}>Sign Out of All Devices</button>
            </div>
          </Card>
        </div>
      )}
    </div>
  );
};

// ── Parent Profile Badge (desktop top-right) ─────────────────────────────────
const ParentProfileBadge = ({ onClick, active }) => (
  <button onClick={onClick} style={{
    display: 'flex', alignItems: 'center', gap: 10, padding: '6px 10px 6px 8px',
    background: active ? C.crimsonLight : C.bg, border: `1.5px solid ${active ? C.crimson : C.border}`,
    borderRadius: 10, cursor: 'pointer', fontFamily: 'inherit', transition: 'all 0.15s',
  }}>
    <Avatar initials="RJ" size={30} color={C.crimson} />
    <div style={{ textAlign: 'left' }}>
      <p style={{ fontSize: 12, fontWeight: 700, color: active ? C.crimson : C.navy, margin: 0, lineHeight: 1.2 }}>Mr & Mrs Johnson</p>
      <p style={{ fontSize: 10, color: active ? C.crimson : C.textSecondary, margin: 0 }}>My Profile</p>
    </div>
    <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke={active ? C.crimson : C.textMuted} strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round" style={{ marginLeft: 2 }}>
      <path d={active ? 'M18 15l-6-6-6 6' : 'M6 9l6 6 6-6'} />
    </svg>
  </button>
);



// ── Parent Portal Shell ──────────────────────────────────────────────────────
const ParentPortal = ({ onLogout, mobileMode }) => {
  const [page, setPage] = React.useState('home');

  const [showProfile, setShowProfile] = React.useState(false);
  const pages = { home: ParentHome, attendance: ParentAttendance, pace: ParentPACE, merits: ParentMeritWallet, messages: ParentMessages, shop: ParentShop, leaderboard: ParentLeaderboard, clubs: ParentClubs };
  const PageComp = pages[page] || ParentHome;

  if (mobileMode) {
    const mobileNavItems = PARENT_NAV.filter(n => PARENT_MOBILE_NAV.includes(n.id));
    return (
      <div style={{ display: 'flex', flexDirection: 'column', height: '100%', background: C.bg, overflow: 'hidden' }}>
        {/* Mobile header */}
        <div style={{ background: C.crimson, padding: '12px 16px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexShrink: 0 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <img src="assets/oasis-logo.png" alt="Oasis" style={{ height: 28, filter: 'brightness(0) invert(1)' }} />
            <div>
              <p style={{ fontSize: 11, color: 'rgba(255,255,255,0.7)', margin: 0 }}>Parent Portal</p>
              <p style={{ fontSize: 13, fontWeight: 700, color: '#fff', margin: 0 }}>The Johnson Family</p>
            </div>
          </div>
          {/* Mobile profile badge */}
          <button onClick={() => setShowProfile(s => !s)} style={{
            display: 'flex', alignItems: 'center', gap: 8,
            background: showProfile ? 'rgba(255,255,255,0.3)' : 'rgba(255,255,255,0.15)',
            border: '1.5px solid rgba(255,255,255,0.25)', borderRadius: 8,
            padding: '6px 10px', cursor: 'pointer', fontFamily: 'inherit',
          }}>
            <Avatar initials="RJ" size={22} color="rgba(255,255,255,0.2)" />
            <span style={{ fontSize: 11, fontWeight: 700, color: '#fff' }}>{showProfile ? 'Close' : 'My Profile'}</span>
          </button>
        </div>
        {/* Content */}
        <div style={{ flex: 1, overflowY: 'auto', padding: 14 }}>
          {showProfile
            ? <ParentSelfProfile mobile={true} onLogout={onLogout} />
            : <PageComp mobile={true} setPage={setPage} />
          }
        </div>
        {/* Bottom nav */}
        <div style={{ background: '#fff', display: 'flex', flexShrink: 0, borderTop: `1px solid ${C.border}` }}>
          {mobileNavItems.map(n => (
            <button key={n.id} onClick={() => { setPage(n.id); setShowProfile(false); }} style={{ flex: 1, padding: '10px 4px 8px', border: 'none', background: 'none', cursor: 'pointer', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 3 }}>
              <PNavIcon path={n.icon} active={page === n.id && !showProfile} />
              <span style={{ fontSize: 9, color: (page === n.id && !showProfile) ? C.crimson : '#94a3b8', fontWeight: 600, fontFamily: 'inherit' }}>{n.label}</span>
            </button>
          ))}
        </div>
      </div>
    );
  }

  // Desktop layout — top nav
  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100vh', background: C.bg, overflow: 'hidden' }}>
      {/* Top nav */}
      <div style={{ background: '#fff', borderBottom: `1px solid ${C.border}`, padding: '0 24px 0 32px', display: 'flex', alignItems: 'center', gap: 0, flexShrink: 0, height: 60 }}>
        <img src="assets/oasis-logo.png" alt="Oasis" style={{ height: 32, marginRight: 20 }} />
        <div style={{ flex: 1, display: 'flex', gap: 2, overflowX: 'auto' }}>
          {PARENT_NAV.map(n => (
            <button key={n.id} onClick={() => { setPage(n.id); setShowProfile(false); }}
              style={{ padding: '18px 14px', border: 'none', background: 'none',
                borderBottom: (page === n.id && !showProfile) ? `2px solid ${C.crimson}` : '2px solid transparent',
                color: (page === n.id && !showProfile) ? C.crimson : C.textSecondary,
                fontWeight: 600, fontSize: 13, cursor: 'pointer', whiteSpace: 'nowrap', fontFamily: 'inherit', display: 'flex', alignItems: 'center', gap: 6 }}>
              {n.label}
              {n.badge && <span style={{ background: C.crimson, color: '#fff', fontSize: 10, fontWeight: 700, borderRadius: 10, padding: '1px 5px' }}>{n.badge}</span>}
            </button>
          ))}
        </div>
        {/* Profile badge + sign out */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, paddingLeft: 16, borderLeft: `1px solid ${C.border}`, flexShrink: 0 }}>
          <ParentProfileBadge onClick={() => setShowProfile(s => !s)} active={showProfile} />
          <button onClick={onLogout} style={{ padding: '6px 14px', background: C.bg, border: `1px solid ${C.border}`, borderRadius: 8, fontSize: 12, fontWeight: 600, color: C.textSecondary, cursor: 'pointer', fontFamily: 'inherit' }}>Sign out</button>
        </div>
      </div>
      {/* Content */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '28px 32px' }}>
        {showProfile
          ? <ParentSelfProfile mobile={false} onLogout={onLogout} />
          : <PageComp mobile={false} setPage={setPage} />
        }
      </div>
    </div>
  );
};

Object.assign(window, { ParentPortal, ParentSelfProfile, ParentProfileBadge });
