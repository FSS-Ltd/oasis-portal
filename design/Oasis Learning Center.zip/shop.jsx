// shop.jsx — Merit Shop (Parent + Admin)

const SHOP_CAT_MAP = Object.fromEntries(SHOP_CATEGORIES.map(c => [c.id, c]));
const SHOP_ITEM_MAP = Object.fromEntries(SHOP_ITEMS.map(i => [i.id, i]));

/* ============================================================================
   ShopTile — placeholder product image
   Tinted background per category + monospace item label + faint diagonal stripes.
   Sized via wrapper; tile fills 100%.
   ============================================================================ */
const ShopTile = ({ item, size = 'md', radius = 14 }) => {
  const cat = SHOP_CAT_MAP[item.category] || { tint:'#F1F4FA', ink:'#5A6A8A' };
  const fs = size === 'lg' ? 13 : size === 'sm' ? 9 : 11;
  const pad = size === 'lg' ? 24 : size === 'sm' ? 10 : 14;
  return (
    <div style={{
      width:'100%', height:'100%', position:'relative', overflow:'hidden',
      background: cat.tint, borderRadius: radius,
      display:'flex', alignItems:'center', justifyContent:'center',
      padding: pad,
    }}>
      {/* Diagonal stripe overlay */}
      <div style={{
        position:'absolute', inset:0, opacity:0.06, pointerEvents:'none',
        backgroundImage:`repeating-linear-gradient(45deg, ${cat.ink} 0 1px, transparent 1px 14px)`,
      }} />
      <p style={{
        position:'relative', textAlign:'center', textTransform:'uppercase',
        letterSpacing:'1.4px', fontWeight:700, color:cat.ink, fontSize:fs,
        fontFamily:'ui-monospace, "SF Mono", Menlo, monospace',
        textWrap:'balance', lineHeight:1.25,
      }}>{item.name}</p>
      {/* tiny accent dot */}
      <div style={{ position:'absolute', top:10, right:10, width:6, height:6, borderRadius:'50%', background:cat.ink, opacity:0.5 }} />
    </div>
  );
};

const CategoryDot = ({ catId, size = 8 }) => {
  const cat = SHOP_CAT_MAP[catId];
  if (!cat) return null;
  return <span style={{ display:'inline-block', width:size, height:size, borderRadius:'50%', background:cat.ink, flexShrink:0 }} />;
};

/* ============================================================================
   PARENT SHOP — mobile reference layout + desktop adaptation
   ============================================================================ */
const ParentShop = ({ mobile }) => {
  const child = MY_CHILD;
  const [view, setView]       = React.useState('browse');   // 'browse' | 'item' | 'cart' | 'placed'
  const [selectedId, setSel]  = React.useState(null);
  const [cart, setCart]       = React.useState([{ itemId:1, qty:1 }, { itemId:7, qty:1 }]); // sample
  const [activeCat, setCat]   = React.useState('all');
  const [search, setSearch]   = React.useState('');

  const selectedItem = selectedId ? SHOP_ITEM_MAP[selectedId] : null;
  const cartLines = cart.map(c => ({ ...c, item: SHOP_ITEM_MAP[c.itemId] })).filter(c => c.item);
  const cartCount = cart.reduce((a,c)=>a+c.qty, 0);
  const cartTotal = cartLines.reduce((a,c)=>a + c.item.price * c.qty, 0);
  const balanceAfter = child.merits.spend - cartTotal;

  const addToCart = (id, qty=1) => {
    setCart(c => {
      const ex = c.find(l => l.itemId === id);
      if (ex) return c.map(l => l.itemId === id ? { ...l, qty: l.qty + qty } : l);
      return [...c, { itemId:id, qty }];
    });
  };
  const setQty = (id, qty) => {
    setCart(c => qty <= 0 ? c.filter(l => l.itemId !== id) : c.map(l => l.itemId === id ? { ...l, qty } : l));
  };

  const visibleItems = SHOP_ITEMS.filter(i => i.active && (activeCat === 'all' || i.category === activeCat) && (!search || i.name.toLowerCase().includes(search.toLowerCase())));

  /* ───────────────────────────────────────── MOBILE ───────────────────────── */
  if (mobile) {
    if (view === 'placed') return <ParentPickupPlaced onDone={() => { setView('browse'); setCart([]); }} cartLines={cartLines} cartTotal={cartTotal} child={child} />;
    if (view === 'cart')   return <ParentCartMobile lines={cartLines} cartTotal={cartTotal} balanceAfter={balanceAfter} child={child} setQty={setQty} onBack={() => setView('browse')} onReserve={() => setView('placed')} />;
    if (view === 'item' && selectedItem) return <ParentItemMobile item={selectedItem} cartCount={cartCount} onBack={() => setView('browse')} onAdd={() => { addToCart(selectedItem.id); setView('cart'); }} onCart={() => setView('cart')} />;
    return <ParentBrowseMobile child={child} cartCount={cartCount} onCart={() => setView('cart')} onOpen={id => { setSel(id); setView('item'); }} />;
  }

  /* ───────────────────────────────────────── DESKTOP ──────────────────────── */
  return (
    <div>
      {/* Header strip */}
      <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:20, flexWrap:'wrap', gap:12 }}>
        <div>
          <h2 style={{ fontSize:22, fontWeight:800, color:C.navy, letterSpacing:'-0.4px' }}>Merit Shop</h2>
          <p style={{ fontSize:13, color:C.textSecondary, marginTop:2 }}>Spend your earned merits on treats, privileges and rewards · Spring Term 2026</p>
        </div>
        <div style={{ display:'flex', gap:10, alignItems:'center' }}>
          <div style={{ background:C.crimsonLight, borderRadius:10, padding:'8px 14px', display:'flex', alignItems:'center', gap:10 }}>
            <Avatar initials={child.initials} size={28} color={child.color} />
            <div>
              <p style={{ fontSize:10, fontWeight:700, color:C.textMuted, textTransform:'uppercase', letterSpacing:'0.5px' }}>{child.name} · Spend</p>
              <p style={{ fontSize:16, fontWeight:800, color:C.crimson, lineHeight:1 }}>{child.merits.spend} <span style={{ fontSize:10, fontWeight:600 }}>merits</span></p>
            </div>
          </div>
        </div>
      </div>

      <div style={{ display:'grid', gridTemplateColumns:'220px 1fr 320px', gap:16, alignItems:'start' }}>
        {/* Left: categories */}
        <Card padding={12}>
          <p style={{ fontSize:11, fontWeight:700, color:C.textMuted, textTransform:'uppercase', letterSpacing:'0.6px', padding:'6px 10px 10px' }}>Categories</p>
          {[{ id:'all', label:'All Items' }, ...SHOP_CATEGORIES].map(cat => {
            const n = cat.id === 'all' ? SHOP_ITEMS.filter(i=>i.active).length : SHOP_ITEMS.filter(i=>i.active && i.category===cat.id).length;
            const sel = activeCat === cat.id;
            return (
              <button key={cat.id} onClick={() => setCat(cat.id)} style={{
                width:'100%', display:'flex', alignItems:'center', gap:10, padding:'9px 10px',
                borderRadius:8, background: sel ? C.bg : 'transparent', border:'none',
                fontFamily:'inherit', cursor:'pointer', textAlign:'left', marginBottom:2,
              }}>
                {cat.id === 'all'
                  ? <span style={{ width:8, height:8, borderRadius:2, background:C.navy }} />
                  : <CategoryDot catId={cat.id} />
                }
                <span style={{ flex:1, fontSize:13, fontWeight: sel ? 700 : 600, color: sel ? C.navy : C.textSecondary }}>{cat.label}</span>
                <span style={{ fontSize:11, color:C.textMuted, fontWeight:600 }}>{n}</span>
              </button>
            );
          })}
          <Divider style={{ margin:'10px 0' }} />
          <div style={{ padding:'6px 10px' }}>
            <p style={{ fontSize:11, fontWeight:700, color:C.textMuted, textTransform:'uppercase', letterSpacing:'0.6px', marginBottom:8 }}>Recent</p>
            {[['Hot Chocolate', '17 Apr', -25],['Helpfulness award','17 Apr',+5]].map(([n,d,a],i)=>(
              <div key={i} style={{ display:'flex', justifyContent:'space-between', alignItems:'baseline', padding:'5px 0' }}>
                <div style={{ minWidth:0, flex:1 }}>
                  <p style={{ fontSize:12, fontWeight:600, color:C.navy, whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }}>{n}</p>
                  <p style={{ fontSize:10, color:C.textMuted }}>{d}</p>
                </div>
                <span style={{ fontSize:12, fontWeight:700, color: a > 0 ? C.success : C.crimson }}>{a > 0 ? `+${a}` : a}</span>
              </div>
            ))}
          </div>
        </Card>

        {/* Centre: catalogue */}
        <div>
          <div style={{ display:'flex', gap:10, marginBottom:14 }}>
            <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search the shop…" style={{ flex:1, padding:'10px 14px', border:`1.5px solid ${C.border}`, borderRadius:10, fontSize:13, fontFamily:'inherit', color:C.navy, outline:'none' }} />
            <Btn variant="secondary">Filter</Btn>
          </div>
          {activeCat !== 'all' && (
            <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:10 }}>
              <h3 style={{ fontSize:15, fontWeight:800, color:C.navy }}>{SHOP_CAT_MAP[activeCat].label}</h3>
              <Badge variant="grey">{visibleItems.length}</Badge>
            </div>
          )}

          <div style={{ display:'grid', gridTemplateColumns:'repeat(3, 1fr)', gap:12 }}>
            {visibleItems.map(item => (
              <ParentItemCard key={item.id} item={item} child={child} onOpen={() => { setSel(item.id); setView('item'); }} />
            ))}
          </div>

          {activeCat === 'all' && SHOP_CATEGORIES.map(cat => {
            const items = SHOP_ITEMS.filter(i => i.active && i.category === cat.id);
            if (items.length === 0) return null;
            return null; // shown above already
          })}
        </div>

        {/* Right: cart */}
        <Card padding={16} style={{ position:'sticky', top:16 }}>
          <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:14 }}>
            <p style={{ fontWeight:800, fontSize:15, color:C.navy }}>My Cart</p>
            <Badge variant="blue">{cartCount} item{cartCount===1?'':'s'}</Badge>
          </div>
          {cartLines.length === 0 ? (
            <div style={{ padding:'24px 8px', textAlign:'center' }}>
              <p style={{ fontSize:13, color:C.textMuted }}>Your cart is empty.</p>
              <p style={{ fontSize:11, color:C.textMuted, marginTop:6 }}>Add a treat or privilege to reserve at the counter.</p>
            </div>
          ) : (
            <>
              <div style={{ display:'flex', flexDirection:'column', gap:10 }}>
                {cartLines.map(l => (
                  <div key={l.itemId} style={{ display:'flex', gap:10, alignItems:'center' }}>
                    <div style={{ width:46, height:46, flexShrink:0 }}><ShopTile item={l.item} size="sm" radius={8} /></div>
                    <div style={{ flex:1, minWidth:0 }}>
                      <p style={{ fontSize:12, fontWeight:700, color:C.navy, whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }}>{l.item.name}</p>
                      <p style={{ fontSize:11, color:C.crimson, fontWeight:700 }}>{l.item.price * l.qty} merits</p>
                    </div>
                    <QtyStepper qty={l.qty} onChange={q => setQty(l.itemId, q)} />
                    <button onClick={() => setQty(l.itemId, 0)} style={{ width:26, height:26, borderRadius:6, background:C.bg, border:'none', cursor:'pointer', color:C.textMuted, display:'flex', alignItems:'center', justifyContent:'center' }}>
                      <svg width={12} height={12} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}><path d="M3 6h18M8 6V4a2 2 0 012-2h4a2 2 0 012 2v2m3 0v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6h14z" /></svg>
                    </button>
                  </div>
                ))}
              </div>
              <Divider style={{ margin:'14px 0' }} />
              <CartSummary cartTotal={cartTotal} balanceAfter={balanceAfter} childBalance={child.merits.spend} />
              <Btn variant="navy" style={{ width:'100%', justifyContent:'center', marginTop:12, padding:'12px' }} disabled={balanceAfter < 0 || cartLines.length === 0} onClick={() => setView('placed')}>
                {balanceAfter < 0 ? 'Not enough merits' : `Reserve at Counter · ${cartTotal} merits`}
              </Btn>
              <p style={{ fontSize:11, color:C.textMuted, textAlign:'center', marginTop:8 }}>Merits hold until pickup. A shopkeeper completes the purchase in-centre.</p>
            </>
          )}
        </Card>
      </div>

      {view === 'placed' && (
        <PickupConfirmModal onDone={() => { setView('browse'); setCart([]); }} cartLines={cartLines} cartTotal={cartTotal} child={child} />
      )}
    </div>
  );
};

/* ── Parent: item card on the desktop grid ─────────────────────────────────── */
const ParentItemCard = ({ item, child, onOpen }) => {
  const canAfford = child.merits.spend >= item.price;
  const outOfStock = item.stock === 0;
  return (
    <button onClick={onOpen} style={{
      background:C.surface, border:`1px solid ${C.border}`, borderRadius:14, padding:12,
      textAlign:'left', cursor:'pointer', fontFamily:'inherit', transition:'transform 0.15s, box-shadow 0.15s',
      opacity: outOfStock ? 0.55 : 1,
    }} onMouseEnter={e => { e.currentTarget.style.transform='translateY(-2px)'; e.currentTarget.style.boxShadow='0 8px 24px rgba(27,43,94,0.08)'; }} onMouseLeave={e => { e.currentTarget.style.transform=''; e.currentTarget.style.boxShadow=''; }}>
      <div style={{ aspectRatio:'1 / 1', marginBottom:10 }}><ShopTile item={item} /></div>
      <div style={{ display:'flex', alignItems:'center', gap:6, marginBottom:3 }}>
        <CategoryDot catId={item.category} size={6} />
        <p style={{ fontSize:10, fontWeight:700, color:C.textMuted, textTransform:'uppercase', letterSpacing:'0.5px' }}>{SHOP_CAT_MAP[item.category].label}</p>
      </div>
      <p style={{ fontWeight:700, fontSize:13, color:C.navy, marginBottom:6, lineHeight:1.3 }}>{item.name}</p>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
        <span style={{ fontWeight:800, fontSize:15, color:C.crimson }}>{item.price} <span style={{ fontSize:10, fontWeight:600, color:C.textMuted }}>merits</span></span>
        {outOfStock
          ? <Badge variant="red">Out of stock</Badge>
          : item.stock <= item.lowAt
            ? <Badge variant="amber">Low · {item.stock} left</Badge>
            : <Badge variant={canAfford ? 'green' : 'grey'}>{canAfford ? 'Can afford' : 'Save more'}</Badge>
        }
      </div>
    </button>
  );
};

/* ── Cart summary row ──────────────────────────────────────────────────────── */
const CartSummary = ({ cartTotal, balanceAfter, childBalance }) => (
  <div style={{ display:'flex', flexDirection:'column', gap:6, fontSize:13 }}>
    <Row label="Spend balance" value={`${childBalance} merits`} />
    <Row label="Cart total" value={`−${cartTotal} merits`} valueColor={C.crimson} />
    <div style={{ height:1, background:C.borderLight, margin:'4px 0' }} />
    <Row label="Balance after" value={`${balanceAfter} merits`} bold valueColor={balanceAfter < 0 ? C.danger : C.navy} />
  </div>
);

const Row = ({ label, value, bold, valueColor }) => (
  <div style={{ display:'flex', justifyContent:'space-between' }}>
    <span style={{ color:C.textSecondary, fontWeight: bold ? 700 : 500 }}>{label}</span>
    <span style={{ color: valueColor || C.navy, fontWeight: bold ? 800 : 600 }}>{value}</span>
  </div>
);

/* ── Quantity stepper ──────────────────────────────────────────────────────── */
const QtyStepper = ({ qty, onChange, min=1, max=99 }) => (
  <div style={{ display:'flex', alignItems:'center', background:C.bg, borderRadius:18, padding:2 }}>
    <button onClick={() => onChange(Math.max(min, qty-1))} style={qtyBtnStyle}>−</button>
    <span style={{ minWidth:22, textAlign:'center', fontSize:12, fontWeight:800, color:C.navy }}>{qty}</span>
    <button onClick={() => onChange(Math.min(max, qty+1))} style={qtyBtnStyle}>+</button>
  </div>
);
const qtyBtnStyle = { width:24, height:24, borderRadius:'50%', border:'none', background:'#fff', boxShadow:'0 1px 2px rgba(0,0,0,0.08)', color: '#1B2B5E', fontWeight:700, fontSize:14, cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center', fontFamily:'inherit' };

/* ============================================================================
   MOBILE SUB-SCREENS
   ============================================================================ */

const MobileTopBar = ({ onBack, title, right }) => (
  <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', padding:'0 4px 18px' }}>
    {onBack
      ? <button onClick={onBack} style={iconBtnStyle}><svg width={18} height={18} viewBox="0 0 24 24" fill="none" stroke="#1B2B5E" strokeWidth={2.2} strokeLinecap="round" strokeLinejoin="round"><path d="M15 18l-6-6 6-6"/></svg></button>
      : <div style={{ width:38, height:38 }} />
    }
    {title && <p style={{ fontSize:14, fontWeight:700, color:C.navy }}>{title}</p>}
    {right || <div style={{ width:38, height:38 }} />}
  </div>
);
const iconBtnStyle = { width:38, height:38, borderRadius:10, background:'#F5F7FB', border:'none', cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0 };

const CartIconBtn = ({ count, onClick }) => (
  <button onClick={onClick} style={{ ...iconBtnStyle, position:'relative' }}>
    <svg width={18} height={18} viewBox="0 0 24 24" fill="none" stroke="#1B2B5E" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round"><path d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z"/></svg>
    {count > 0 && (
      <span style={{ position:'absolute', top:4, right:4, minWidth:16, height:16, background:C.crimson, color:'#fff', borderRadius:8, fontSize:9, fontWeight:800, display:'flex', alignItems:'center', justifyContent:'center', padding:'0 4px' }}>{count}</span>
    )}
  </button>
);

/* ── BROWSE (mobile) ───────────────────────────────────────────────────────── */
const ParentBrowseMobile = ({ child, cartCount, onCart, onOpen }) => {
  return (
    <div className="page-fade" style={{ padding:'16px 20px 24px' }}>
      <MobileTopBar
        right={<div style={{ display:'flex', gap:8 }}>
          <button style={iconBtnStyle}><svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke="#1B2B5E" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round"><circle cx={11} cy={11} r={7}/><path d="M21 21l-4.35-4.35"/></svg></button>
          <CartIconBtn count={cartCount} onClick={onCart} />
        </div>}
      />

      {/* Hero */}
      <h1 style={{ fontSize:28, fontWeight:800, color:C.navy, letterSpacing:'-0.6px', marginBottom:8, lineHeight:1.1 }}>Merit Shop</h1>
      <p style={{ fontSize:13, color:C.textSecondary, marginBottom:6 }}>Treats, privileges and rewards.</p>
      <p style={{ fontSize:13, color:C.textSecondary, marginBottom:20 }}>Spend held until pickup at the counter.</p>

      {/* Balance pill */}
      <div style={{ display:'flex', alignItems:'center', gap:10, background:C.crimsonLight, padding:'10px 12px', borderRadius:12, marginBottom:22 }}>
        <Avatar initials={child.initials} size={34} color={child.color} />
        <div style={{ flex:1 }}>
          <p style={{ fontSize:11, fontWeight:700, color:C.textMuted, textTransform:'uppercase', letterSpacing:'0.4px' }}>{child.name} · Spend</p>
          <p style={{ fontSize:18, fontWeight:800, color:C.crimson, lineHeight:1.1 }}>{child.merits.spend} <span style={{ fontSize:11, fontWeight:600 }}>merits</span></p>
        </div>
        <div style={{ background:'#fff', borderRadius:8, padding:'4px 10px', fontSize:10, fontWeight:700, color:C.crimson, letterSpacing:'0.3px' }}>+5 today</div>
      </div>

      {/* Render each category section */}
      {SHOP_CATEGORIES.map(cat => {
        const items = SHOP_ITEMS.filter(i => i.active && i.category === cat.id);
        if (items.length === 0) return null;
        return (
          <div key={cat.id} style={{ marginBottom:22 }}>
            <div style={{ display:'flex', justifyContent:'space-between', alignItems:'baseline', marginBottom:12 }}>
              <h3 style={{ fontSize:17, fontWeight:800, color:C.navy }}>
                {cat.label} <span style={{ color:C.textMuted, fontWeight:600, fontSize:14 }}>{items.length}</span>
              </h3>
              <button style={{ background:'none', border:'none', color:C.navy, fontWeight:700, fontSize:12, cursor:'pointer', fontFamily:'inherit' }}>Show all</button>
            </div>
            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:12 }}>
              {items.slice(0, 2).map(item => (
                <ParentItemCardMobile key={item.id} item={item} child={child} onOpen={() => onOpen(item.id)} />
              ))}
            </div>
          </div>
        );
      })}
    </div>
  );
};

const ParentItemCardMobile = ({ item, child, onOpen }) => {
  const out = item.stock === 0;
  const low = !out && item.stock <= item.lowAt;
  return (
    <button onClick={onOpen} style={{
      background:'transparent', border:'none', padding:0, textAlign:'left', cursor:'pointer', fontFamily:'inherit',
    }}>
      <div style={{ aspectRatio:'1 / 1', marginBottom:10 }}><ShopTile item={item} /></div>
      <p style={{ fontSize:13, fontWeight:700, color:C.navy, marginBottom:4, lineHeight:1.25 }}>{item.name}</p>
      <div style={{ display:'flex', alignItems:'center', gap:6 }}>
        <p style={{ fontSize:13, fontWeight:700, color:C.textSecondary }}>{item.price} merits</p>
        {out && <span style={{ fontSize:10, fontWeight:700, color:C.danger }}>· Unavailable</span>}
        {low && <span style={{ fontSize:10, fontWeight:700, color:C.warning }}>· Low</span>}
      </div>
    </button>
  );
};

/* ── ITEM DETAIL (mobile) ──────────────────────────────────────────────────── */
const ParentItemMobile = ({ item, cartCount, onBack, onAdd, onCart }) => {
  const cat = SHOP_CAT_MAP[item.category];
  const out = item.stock === 0;
  return (
    <div className="page-fade" style={{ display:'flex', flexDirection:'column', height:'100%' }}>
      {/* Top — large tile */}
      <div style={{ background:cat.tint, padding:'16px 20px 30px', position:'relative' }}>
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:8 }}>
          <button onClick={onBack} style={iconBtnStyle}><svg width={18} height={18} viewBox="0 0 24 24" fill="none" stroke="#1B2B5E" strokeWidth={2.2} strokeLinecap="round" strokeLinejoin="round"><path d="M15 18l-6-6 6-6"/></svg></button>
          <CartIconBtn count={cartCount} onClick={onCart} />
        </div>
        <div style={{ height:220, position:'relative', display:'flex', alignItems:'center', justifyContent:'center' }}>
          <ShopTile item={item} size="lg" radius={20} />
        </div>
        {/* Pagination dots */}
        <div style={{ display:'flex', justifyContent:'center', gap:6, marginTop:14 }}>
          <span style={{ width:24, height:4, borderRadius:2, background:cat.ink, opacity:0.9 }} />
          <span style={{ width:6, height:4, borderRadius:2, background:cat.ink, opacity:0.3 }} />
          <span style={{ width:6, height:4, borderRadius:2, background:cat.ink, opacity:0.3 }} />
        </div>
      </div>

      {/* Body */}
      <div style={{ flex:1, padding:'20px 20px 12px', overflowY:'auto' }}>
        <div style={{ display:'flex', alignItems:'center', gap:6, marginBottom:8 }}>
          <CategoryDot catId={item.category} />
          <p style={{ fontSize:11, fontWeight:700, color:cat.ink, textTransform:'uppercase', letterSpacing:'0.6px' }}>{cat.label}</p>
        </div>

        <div style={{ display:'flex', alignItems:'flex-start', justifyContent:'space-between', gap:8, marginBottom:6 }}>
          <h1 style={{ fontSize:24, fontWeight:800, color:C.navy, letterSpacing:'-0.4px', lineHeight:1.15, flex:1 }}>{item.name}</h1>
          <button style={{ width:42, height:42, borderRadius:'50%', background:'#EEF2F9', border:'none', cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0 }}>
            <svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke={C.navy} strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round"><path d="M10 13a5 5 0 007.54.54l3-3a5 5 0 00-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 00-7.54-.54l-3 3a5 5 0 007.07 7.07l1.71-1.71"/></svg>
          </button>
        </div>

        <p style={{ fontSize:13, color:C.textSecondary, marginBottom:18, lineHeight:1.55 }}>{item.description}</p>

        {/* Pickup info row */}
        <div style={{ display:'flex', alignItems:'center', gap:12, padding:'12px 0', borderTop:`1px solid ${C.border}`, borderBottom:`1px solid ${C.border}`, marginBottom:18 }}>
          <div style={{ width:38, height:38, borderRadius:10, background:'#EEF2F9', display:'flex', alignItems:'center', justifyContent:'center' }}>
            <svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke={C.navy} strokeWidth={1.8}><path d="M17.657 16.657L13.414 20.9a2 2 0 01-2.828 0l-4.244-4.243a8 8 0 1111.314 0z"/><circle cx={12} cy={11} r={3}/></svg>
          </div>
          <div style={{ flex:1 }}>
            <p style={{ fontSize:13, fontWeight:700, color:C.navy }}>Pickup at Shopkeeper Counter</p>
            <p style={{ fontSize:11, color:C.textMuted, marginTop:2 }}>Open Mon–Fri break · Reception lobby</p>
          </div>
          <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke={C.textMuted} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round"><path d="M9 18l6-6-6-6"/></svg>
        </div>

        {/* Price + stock */}
        <p style={{ fontSize:30, fontWeight:800, color:C.navy, letterSpacing:'-0.5px' }}>{item.price} <span style={{ fontSize:14, color:C.textSecondary, fontWeight:600 }}>merits</span></p>
        <p style={{ fontSize:12, color:C.textMuted, marginTop:4 }}>
          {out ? 'Currently out of stock — try again next week.' :
           item.stock <= item.lowAt ? `Low stock · ${item.stock} left in shop` :
           `In stock · ${item.stock} available · ${item.sold} purchased this term`}
        </p>
      </div>

      {/* Sticky CTA */}
      <div style={{ padding:'12px 20px 18px', background:'#fff', borderTop:`1px solid ${C.borderLight}` }}>
        <button onClick={out ? undefined : onAdd} disabled={out} style={{
          width:'100%', padding:'16px', background: out ? '#cbd5e1' : C.navy, color:'#fff',
          border:'none', borderRadius:14, fontSize:13, fontWeight:800, letterSpacing:'1.5px',
          textTransform:'uppercase', cursor: out ? 'not-allowed' : 'pointer', fontFamily:'inherit',
        }}>
          {out ? 'Out of Stock' : 'Add to Cart'}
        </button>
      </div>
    </div>
  );
};

/* ── CART (mobile) ─────────────────────────────────────────────────────────── */
const ParentCartMobile = ({ lines, cartTotal, balanceAfter, child, setQty, onBack, onReserve }) => (
  <div className="page-fade" style={{ display:'flex', flexDirection:'column', height:'100%' }}>
    <div style={{ padding:'16px 20px 0' }}>
      <MobileTopBar onBack={onBack} title="Order Details" />
    </div>

    <div style={{ flex:1, overflowY:'auto', padding:'4px 20px 12px' }}>
      <p style={{ fontSize:22, fontWeight:800, color:C.navy, marginBottom:18, letterSpacing:'-0.4px' }}>My Cart</p>

      {lines.length === 0 && (
        <div style={{ padding:'40px 0', textAlign:'center' }}>
          <p style={{ fontSize:14, color:C.textMuted }}>Cart is empty — go and pick a reward.</p>
        </div>
      )}

      {lines.map(l => (
        <div key={l.itemId} style={{ display:'flex', gap:12, alignItems:'center', marginBottom:18 }}>
          <div style={{ width:62, height:62, flexShrink:0 }}><ShopTile item={l.item} size="sm" radius={10} /></div>
          <div style={{ flex:1, minWidth:0 }}>
            <p style={{ fontSize:14, fontWeight:700, color:C.navy, lineHeight:1.25 }}>{l.item.name}</p>
            <p style={{ fontSize:12, color:C.textSecondary, marginTop:3 }}>{l.item.price} merits each</p>
          </div>
          <QtyStepper qty={l.qty} onChange={q => setQty(l.itemId, q)} />
          <button onClick={() => setQty(l.itemId, 0)} style={{ width:30, height:30, borderRadius:'50%', background:'#EEF2F9', border:'none', cursor:'pointer', color:C.textMuted, display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0 }}>
            <svg width={13} height={13} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}><path d="M3 6h18M8 6V4a2 2 0 012-2h4a2 2 0 012 2v2m3 0v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6h14z" /></svg>
          </button>
        </div>
      ))}

      {lines.length > 0 && (
        <>
          {/* Pickup */}
          <p style={{ fontSize:18, fontWeight:800, color:C.navy, marginTop:14, marginBottom:12 }}>Pickup Location</p>
          <div style={{ display:'flex', alignItems:'center', gap:12, padding:'12px 0', borderTop:`1px solid ${C.border}`, borderBottom:`1px solid ${C.border}`, marginBottom:18 }}>
            <div style={{ width:42, height:42, borderRadius:10, background:'#EEF2F9', display:'flex', alignItems:'center', justifyContent:'center' }}>
              <svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke={C.navy} strokeWidth={1.8}><path d="M17.657 16.657L13.414 20.9a2 2 0 01-2.828 0l-4.244-4.243a8 8 0 1111.314 0z"/><circle cx={12} cy={11} r={3}/></svg>
            </div>
            <div style={{ flex:1 }}>
              <p style={{ fontSize:13, fontWeight:700, color:C.navy }}>Shopkeeper Counter</p>
              <p style={{ fontSize:11, color:C.textMuted, marginTop:2 }}>Reception lobby · Mon–Fri break</p>
            </div>
            <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke={C.textMuted} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round"><path d="M9 18l6-6-6-6"/></svg>
          </div>

          {/* Paying with */}
          <p style={{ fontSize:18, fontWeight:800, color:C.navy, marginBottom:12 }}>Paying With</p>
          <div style={{ display:'flex', alignItems:'center', gap:12, padding:'12px 0', borderTop:`1px solid ${C.border}`, borderBottom:`1px solid ${C.border}`, marginBottom:18 }}>
            <div style={{ width:46, height:32, borderRadius:6, background:C.crimson, display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0 }}>
              <span style={{ fontSize:11, fontWeight:800, color:'#fff', letterSpacing:'0.4px' }}>MERIT</span>
            </div>
            <div style={{ flex:1 }}>
              <p style={{ fontSize:13, fontWeight:700, color:C.navy }}>Spend Account</p>
              <p style={{ fontSize:11, color:C.textMuted, marginTop:2 }}>{child.name} · {child.merits.spend} merits available</p>
            </div>
            <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke={C.textMuted} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round"><path d="M9 18l6-6-6-6"/></svg>
          </div>

          {/* Order info */}
          <p style={{ fontSize:18, fontWeight:800, color:C.navy, marginBottom:12 }}>Order Info</p>
          <div style={{ display:'flex', flexDirection:'column', gap:8, fontSize:13, marginBottom:10 }}>
            <Row label="Subtotal" value={`${cartTotal} merits`} />
            <Row label="10% Tithe (suggested)" value="+0 merits" valueColor={C.textMuted} />
            <div style={{ height:1, background:C.borderLight, margin:'4px 0' }} />
            <Row label="Total" value={`${cartTotal} merits`} bold />
            <Row label="Balance after pickup" value={`${balanceAfter} merits`} valueColor={balanceAfter < 0 ? C.danger : C.textSecondary} />
          </div>
        </>
      )}
    </div>

    {lines.length > 0 && (
      <div style={{ padding:'12px 20px 18px', background:'#fff', borderTop:`1px solid ${C.borderLight}` }}>
        <button disabled={balanceAfter < 0} onClick={onReserve} style={{
          width:'100%', padding:'16px', background: balanceAfter < 0 ? '#cbd5e1' : C.navy, color:'#fff',
          border:'none', borderRadius:14, fontSize:13, fontWeight:800, letterSpacing:'1.5px',
          textTransform:'uppercase', cursor: balanceAfter < 0 ? 'not-allowed' : 'pointer', fontFamily:'inherit',
        }}>
          {balanceAfter < 0 ? `Need ${Math.abs(balanceAfter)} more merits` : `Reserve (${cartTotal} merits)`}
        </button>
      </div>
    )}
  </div>
);

/* ── PICKUP CONFIRMATION (mobile) ──────────────────────────────────────────── */
const ParentPickupPlaced = ({ onDone, cartLines, cartTotal, child }) => {
  const orderRef = 'OAS-' + String(Math.floor(Math.random()*9000) + 1000);
  return (
    <div className="page-fade" style={{ display:'flex', flexDirection:'column', height:'100%' }}>
      <div style={{ padding:'16px 20px 0' }}>
        <MobileTopBar />
      </div>
      <div style={{ flex:1, padding:'20px 24px 0', overflowY:'auto' }}>
        <div style={{ width:64, height:64, borderRadius:'50%', background:C.successBg, display:'flex', alignItems:'center', justifyContent:'center', marginBottom:20 }}>
          <svg width={28} height={28} viewBox="0 0 24 24" fill="none" stroke={C.success} strokeWidth={2.2} strokeLinecap="round" strokeLinejoin="round"><path d="M5 13l4 4L19 7"/></svg>
        </div>
        <h1 style={{ fontSize:24, fontWeight:800, color:C.navy, letterSpacing:'-0.4px', marginBottom:8 }}>Reserved at the counter</h1>
        <p style={{ fontSize:13, color:C.textSecondary, lineHeight:1.55, marginBottom:18 }}>{child.name.split(' ')[0]} can collect from the shopkeeper at next break. Merits will be deducted on pickup.</p>

        <div style={{ background:C.bg, borderRadius:12, padding:16, marginBottom:18 }}>
          <div style={{ display:'flex', justifyContent:'space-between', marginBottom:10 }}>
            <p style={{ fontSize:11, fontWeight:700, color:C.textMuted, textTransform:'uppercase', letterSpacing:'0.5px' }}>Reference</p>
            <p style={{ fontSize:13, fontWeight:800, color:C.navy, fontFamily:'ui-monospace, monospace' }}>{orderRef}</p>
          </div>
          {cartLines.map(l => (
            <div key={l.itemId} style={{ display:'flex', justifyContent:'space-between', padding:'6px 0', fontSize:13 }}>
              <span style={{ color:C.textSecondary }}>{l.qty} × {l.item.name}</span>
              <span style={{ fontWeight:700, color:C.navy }}>{l.item.price * l.qty} m</span>
            </div>
          ))}
          <Divider style={{ margin:'8px 0' }} />
          <div style={{ display:'flex', justifyContent:'space-between', fontSize:13 }}>
            <span style={{ fontWeight:700, color:C.navy }}>Total on hold</span>
            <span style={{ fontWeight:800, color:C.crimson }}>{cartTotal} merits</span>
          </div>
        </div>
      </div>
      <div style={{ padding:'12px 20px 18px', background:'#fff', borderTop:`1px solid ${C.borderLight}` }}>
        <button onClick={onDone} style={{
          width:'100%', padding:'16px', background:C.navy, color:'#fff',
          border:'none', borderRadius:14, fontSize:13, fontWeight:800, letterSpacing:'1.5px',
          textTransform:'uppercase', cursor:'pointer', fontFamily:'inherit',
        }}>Back to Shop</button>
      </div>
    </div>
  );
};

/* ── PICKUP CONFIRMATION (desktop modal) ───────────────────────────────────── */
const PickupConfirmModal = ({ onDone, cartLines, cartTotal, child }) => {
  const orderRef = React.useMemo(() => 'OAS-' + String(Math.floor(Math.random()*9000) + 1000), []);
  React.useEffect(() => {
    const h = e => { if (e.key === 'Escape') onDone(); };
    window.addEventListener('keydown', h);
    return () => window.removeEventListener('keydown', h);
  }, [onDone]);
  return (
    <div onClick={onDone} style={{ position:'fixed', inset:0, background:'rgba(10,18,40,0.55)', backdropFilter:'blur(4px)', zIndex:9000, display:'flex', alignItems:'center', justifyContent:'center', padding:24 }}>
      <div onClick={e => e.stopPropagation()} style={{ background:'#fff', borderRadius:18, width:'100%', maxWidth:460, padding:28, boxShadow:'0 32px 80px rgba(0,0,0,0.32)' }}>
        <div style={{ width:56, height:56, borderRadius:'50%', background:C.successBg, display:'flex', alignItems:'center', justifyContent:'center', marginBottom:16 }}>
          <svg width={26} height={26} viewBox="0 0 24 24" fill="none" stroke={C.success} strokeWidth={2.2} strokeLinecap="round" strokeLinejoin="round"><path d="M5 13l4 4L19 7"/></svg>
        </div>
        <h2 style={{ fontSize:22, fontWeight:800, color:C.navy, marginBottom:6 }}>Reserved at the counter</h2>
        <p style={{ fontSize:13, color:C.textSecondary, marginBottom:18 }}>{child.name.split(' ')[0]} can collect at next break. Reference <strong style={{ color:C.navy, fontFamily:'ui-monospace, monospace' }}>{orderRef}</strong>.</p>
        <div style={{ background:C.bg, borderRadius:10, padding:14, marginBottom:18 }}>
          {cartLines.map(l => (
            <div key={l.itemId} style={{ display:'flex', justifyContent:'space-between', padding:'4px 0', fontSize:13 }}>
              <span style={{ color:C.textSecondary }}>{l.qty} × {l.item.name}</span>
              <span style={{ fontWeight:700, color:C.navy }}>{l.item.price * l.qty} m</span>
            </div>
          ))}
          <Divider style={{ margin:'8px 0' }} />
          <div style={{ display:'flex', justifyContent:'space-between', fontSize:13 }}>
            <span style={{ fontWeight:700, color:C.navy }}>Total on hold</span>
            <span style={{ fontWeight:800, color:C.crimson }}>{cartTotal} merits</span>
          </div>
        </div>
        <Btn variant="navy" style={{ width:'100%', justifyContent:'center', padding:'12px' }} onClick={onDone}>Back to Shop</Btn>
      </div>
    </div>
  );
};

/* ============================================================================
   ADMIN SHOP
   ============================================================================ */
const AdminShop = ({ mobile }) => {
  const [tab, setTab]         = React.useState('catalogue');
  const [items, setItems]     = React.useState(SHOP_ITEMS);
  const [pickups, setPickups] = React.useState(SHOP_PICKUPS);
  const [search, setSearch]   = React.useState('');
  const [catFilter, setCatF]  = React.useState('all');
  const [statusFilter, setSF] = React.useState('all');
  const [editing, setEditing] = React.useState(null);   // item id or 'new'
  const [editingPickup, setEP] = React.useState(false);

  // Computed stats
  const totalItems    = items.length;
  const activeItems   = items.filter(i => i.active).length;
  const outOfStock    = items.filter(i => i.stock === 0).length;
  const lowStock      = items.filter(i => i.stock > 0 && i.stock <= i.lowAt).length;
  const pendingPickup = pickups.filter(p => p.status === 'Ready').length;
  const totalSold     = items.reduce((a,i)=>a+(i.sold||0), 0);
  const totalRevenue  = items.reduce((a,i)=>a+(i.sold||0)*i.price, 0);

  // Editing
  const editingItem = editing === 'new'
    ? { id:null, name:'', category:'treats', price:0, stock:0, lowAt:5, active:true, description:'', blurb:'', sold:0 }
    : items.find(i => i.id === editing);

  const saveItem = (it) => {
    setItems(curr => {
      if (it.id == null) {
        const newId = Math.max(0, ...curr.map(c => c.id)) + 1;
        return [...curr, { ...it, id:newId }];
      }
      return curr.map(c => c.id === it.id ? it : c);
    });
    setEditing(null);
  };
  const deleteItem = id => { setItems(c => c.filter(i => i.id !== id)); setEditing(null); };
  const toggleActive = id => setItems(c => c.map(i => i.id === id ? { ...i, active: !i.active } : i));

  const adjustStock = (id, delta) => setItems(c => c.map(i => i.id === id ? { ...i, stock: Math.max(0, i.stock + delta) } : i));
  const setPrice = (id, price) => setItems(c => c.map(i => i.id === id ? { ...i, price: Math.max(0, parseInt(price, 10) || 0) } : i));

  const markCollected = id => setPickups(c => c.map(p => p.id === id ? { ...p, status:'Collected', by:'Mrs Thompson' } : p));

  const filtered = items.filter(i =>
    (catFilter === 'all' || i.category === catFilter) &&
    (statusFilter === 'all'
      || (statusFilter === 'active' && i.active)
      || (statusFilter === 'inactive' && !i.active)
      || (statusFilter === 'low' && i.stock > 0 && i.stock <= i.lowAt)
      || (statusFilter === 'out' && i.stock === 0)) &&
    (!search || i.name.toLowerCase().includes(search.toLowerCase()))
  );

  return (
    <div className="page-fade">
      {/* Header */}
      <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:20, flexWrap:'wrap', gap:12 }}>
        <div>
          <h2 style={{ fontSize:mobile?20:24, fontWeight:800, color:C.navy, letterSpacing:'-0.4px' }}>Merit Shop · Admin</h2>
          <p style={{ fontSize:13, color:C.textSecondary, marginTop:2 }}>Manage catalogue, prices, stock and pickups for the term.</p>
        </div>
        <div style={{ display:'flex', gap:8 }}>
          <Btn variant="secondary" size="sm">Export CSV</Btn>
          <Btn variant="primary" onClick={() => setEditing('new')}>+ Add Item</Btn>
        </div>
      </div>

      {/* Stat cards */}
      <div style={{ display:'grid', gridTemplateColumns: mobile ? '1fr 1fr' : 'repeat(5, 1fr)', gap:12, marginBottom:24 }}>
        <StatCard label="Catalogue" value={totalItems} sub={`${activeItems} active · ${totalItems - activeItems} paused`} accent={C.blue} />
        <StatCard label="Pending Pickups" value={pendingPickup} sub="awaiting collection" accent={pendingPickup > 0 ? C.warning : C.success} />
        <StatCard label="Low Stock" value={lowStock} sub="at or below threshold" accent={lowStock > 0 ? C.warning : C.success} />
        <StatCard label="Out of Stock" value={outOfStock} sub="needs restock" accent={outOfStock > 0 ? C.danger : C.success} />
        <StatCard label="Term Revenue" value={`${totalRevenue}m`} sub={`${totalSold} items sold`} accent={C.crimson} />
      </div>

      {/* Tabs */}
      <div style={{ display:'flex', gap:4, marginBottom:14, background:C.bg, borderRadius:10, padding:4, width:'fit-content', flexWrap:'wrap' }}>
        {[['catalogue','Catalogue', totalItems],['pickups','Pickups', pendingPickup],['activity','Activity', null]].map(([id,label,badge])=>(
          <button key={id} onClick={()=>setTab(id)} style={{ padding:'8px 14px', borderRadius:7, border:'none', background:tab===id?C.navy:'transparent', color:tab===id?'#fff':C.textSecondary, fontWeight:700, fontSize:12, cursor:'pointer', fontFamily:'inherit', display:'inline-flex', alignItems:'center', gap:6 }}>
            {label}
            {badge != null && badge > 0 && <span style={{ background: tab===id ? 'rgba(255,255,255,0.18)' : C.crimsonLight, color: tab===id ? '#fff' : C.crimson, borderRadius:8, padding:'1px 7px', fontSize:10, fontWeight:800 }}>{badge}</span>}
          </button>
        ))}
      </div>

      {/* ── Catalogue tab ── */}
      {tab === 'catalogue' && (
        <>
          <div style={{ display:'flex', gap:10, marginBottom:14, flexWrap:'wrap' }}>
            <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search catalogue…" style={{ flex:1, minWidth:200, padding:'9px 14px', border:`1.5px solid ${C.border}`, borderRadius:8, fontSize:13, fontFamily:'inherit', color:C.navy, outline:'none' }} />
            <select value={catFilter} onChange={e=>setCatF(e.target.value)} style={{ padding:'9px 14px', border:`1.5px solid ${C.border}`, borderRadius:8, fontSize:13, fontFamily:'inherit', color:C.navy, background:'#fff', outline:'none' }}>
              <option value="all">All Categories</option>
              {SHOP_CATEGORIES.map(c => <option key={c.id} value={c.id}>{c.label}</option>)}
            </select>
            <select value={statusFilter} onChange={e=>setSF(e.target.value)} style={{ padding:'9px 14px', border:`1.5px solid ${C.border}`, borderRadius:8, fontSize:13, fontFamily:'inherit', color:C.navy, background:'#fff', outline:'none' }}>
              <option value="all">All Status</option>
              <option value="active">Active</option>
              <option value="inactive">Paused</option>
              <option value="low">Low stock</option>
              <option value="out">Out of stock</option>
            </select>
          </div>

          {mobile ? (
            <div style={{ display:'flex', flexDirection:'column', gap:10 }}>
              {filtered.map(it => <AdminItemCardMobile key={it.id} item={it} onEdit={()=>setEditing(it.id)} onToggle={()=>toggleActive(it.id)} onStock={(d)=>adjustStock(it.id, d)} />)}
            </div>
          ) : (
            <Card padding={0}>
              <table style={{ width:'100%', borderCollapse:'collapse', fontSize:13 }}>
                <thead><tr style={{ background:C.bg }}>
                  {['Item','Category','Price','Stock','Sold','Status','Actions'].map(h =>
                    <th key={h} style={{ padding:'10px 14px', textAlign:'left', fontSize:11, fontWeight:700, color:C.textSecondary, textTransform:'uppercase', letterSpacing:'0.5px' }}>{h}</th>
                  )}
                </tr></thead>
                <tbody>
                  {filtered.map(it => {
                    const cat = SHOP_CAT_MAP[it.category];
                    const stockStatus = it.stock === 0 ? 'out' : it.stock <= it.lowAt ? 'low' : 'ok';
                    return (
                      <tr key={it.id} style={{ borderTop:`1px solid ${C.border}` }} onMouseEnter={e=>e.currentTarget.style.background=C.bg} onMouseLeave={e=>e.currentTarget.style.background=''}>
                        <td style={{ padding:'10px 14px' }}>
                          <div style={{ display:'flex', alignItems:'center', gap:12 }}>
                            <div style={{ width:42, height:42, flexShrink:0 }}><ShopTile item={it} size="sm" radius={8} /></div>
                            <div style={{ minWidth:0 }}>
                              <p style={{ fontWeight:700, color:C.navy }}>{it.name}</p>
                              <p style={{ fontSize:11, color:C.textMuted, marginTop:2, whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis', maxWidth:260 }}>{it.blurb}</p>
                            </div>
                          </div>
                        </td>
                        <td style={{ padding:'10px 14px' }}>
                          <span style={{ display:'inline-flex', alignItems:'center', gap:6, fontSize:12, fontWeight:600, color:cat.ink, background:cat.tint, padding:'4px 9px', borderRadius:8 }}>
                            <CategoryDot catId={it.category} size={6} />
                            {cat.label}
                          </span>
                        </td>
                        <td style={{ padding:'10px 14px' }}>
                          <input type="number" value={it.price} onChange={e=>setPrice(it.id, e.target.value)} style={{ width:78, padding:'6px 8px', border:`1.5px solid ${C.border}`, borderRadius:6, fontSize:13, fontWeight:700, color:C.crimson, fontFamily:'inherit', outline:'none' }} />
                          <span style={{ fontSize:11, color:C.textMuted, marginLeft:4 }}>m</span>
                        </td>
                        <td style={{ padding:'10px 14px' }}>
                          <div style={{ display:'flex', alignItems:'center', gap:4 }}>
                            <button onClick={()=>adjustStock(it.id, -1)} style={stockBtnStyle}>−</button>
                            <span style={{ minWidth:26, textAlign:'center', fontWeight:800, fontSize:14, color: stockStatus==='out'?C.danger : stockStatus==='low'?C.warning : C.navy }}>{it.stock}</span>
                            <button onClick={()=>adjustStock(it.id, 1)} style={stockBtnStyle}>+</button>
                          </div>
                        </td>
                        <td style={{ padding:'10px 14px', color:C.textSecondary }}>{it.sold || 0}</td>
                        <td style={{ padding:'10px 14px' }}>
                          {!it.active
                            ? <Badge variant="grey">Paused</Badge>
                            : it.stock === 0
                              ? <Badge variant="red">Out</Badge>
                              : it.stock <= it.lowAt
                                ? <Badge variant="amber">Low</Badge>
                                : <Badge variant="green">Active</Badge>}
                        </td>
                        <td style={{ padding:'10px 14px' }}>
                          <div style={{ display:'flex', gap:4 }}>
                            <Btn variant="secondary" size="sm" onClick={() => setEditing(it.id)}>Edit</Btn>
                            <Btn variant="ghost" size="sm" onClick={() => toggleActive(it.id)}>{it.active?'Pause':'Resume'}</Btn>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                  {filtered.length === 0 && (
                    <tr><td colSpan={7} style={{ padding:'30px 14px', textAlign:'center', color:C.textMuted, fontSize:13 }}>No items match your filters.</td></tr>
                  )}
                </tbody>
              </table>
            </Card>
          )}
        </>
      )}

      {/* ── Pickups tab ── */}
      {tab === 'pickups' && (
        <div style={{ display:'grid', gridTemplateColumns: mobile ? '1fr' : '1.5fr 1fr', gap:16, alignItems:'start' }}>
          <Card padding={0}>
            <div style={{ padding:'14px 16px', borderBottom:`1px solid ${C.border}`, display:'flex', alignItems:'center', justifyContent:'space-between' }}>
              <div>
                <p style={{ fontWeight:800, fontSize:14, color:C.navy }}>Awaiting Pickup</p>
                <p style={{ fontSize:11, color:C.textMuted, marginTop:2 }}>Hand over at the counter, then mark collected.</p>
              </div>
              <Badge variant="amber">{pendingPickup} ready</Badge>
            </div>
            {pickups.filter(p => p.status === 'Ready').map(p => {
              const it = SHOP_ITEM_MAP[p.itemId];
              const s = STUDENTS.find(st => st.id === p.studentId);
              if (!it || !s) return null;
              return (
                <div key={p.id} style={{ display:'flex', alignItems:'center', gap:12, padding:'12px 16px', borderTop:`1px solid ${C.borderLight}` }}>
                  <div style={{ width:46, height:46, flexShrink:0 }}><ShopTile item={it} size="sm" radius={8} /></div>
                  <div style={{ flex:1, minWidth:0 }}>
                    <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:3 }}>
                      <p style={{ fontWeight:700, fontSize:13, color:C.navy }}>{p.qty} × {it.name}</p>
                      <Badge variant="grey">{p.qty * it.price} m</Badge>
                    </div>
                    <p style={{ fontSize:11, color:C.textSecondary }}>{s.name} · {s.year} · placed {p.placed}</p>
                  </div>
                  <Btn variant="primary" size="sm" onClick={() => markCollected(p.id)}>Mark Collected</Btn>
                </div>
              );
            })}
            {pendingPickup === 0 && (
              <div style={{ padding:'30px 16px', textAlign:'center', color:C.textMuted, fontSize:13 }}>No pickups in the queue.</div>
            )}
          </Card>
          <Card padding={0}>
            <div style={{ padding:'14px 16px', borderBottom:`1px solid ${C.border}` }}>
              <p style={{ fontWeight:800, fontSize:14, color:C.navy }}>Recently Collected</p>
              <p style={{ fontSize:11, color:C.textMuted, marginTop:2 }}>Last 7 days</p>
            </div>
            {pickups.filter(p => p.status === 'Collected').map(p => {
              const it = SHOP_ITEM_MAP[p.itemId];
              const s = STUDENTS.find(st => st.id === p.studentId);
              if (!it || !s) return null;
              return (
                <div key={p.id} style={{ display:'flex', alignItems:'center', gap:10, padding:'10px 16px', borderTop:`1px solid ${C.borderLight}` }}>
                  <Avatar initials={s.initials} size={28} color={s.color} />
                  <div style={{ flex:1, minWidth:0 }}>
                    <p style={{ fontSize:12, fontWeight:700, color:C.navy }}>{s.name}</p>
                    <p style={{ fontSize:11, color:C.textMuted }}>{p.qty} × {it.name} · {p.placed} · by {p.by}</p>
                  </div>
                  <span style={{ fontSize:12, fontWeight:700, color:C.success }}>−{p.qty*it.price}m</span>
                </div>
              );
            })}
          </Card>
        </div>
      )}

      {/* ── Activity tab ── */}
      {tab === 'activity' && (
        <div style={{ display:'grid', gridTemplateColumns: mobile ? '1fr' : '2fr 1fr', gap:16, alignItems:'start' }}>
          <Card>
            <p style={{ fontWeight:800, fontSize:14, color:C.navy, marginBottom:14 }}>Top Sellers · This Term</p>
            {[...items].sort((a,b)=>b.sold - a.sold).slice(0, 6).map((it, i) => {
              const cat = SHOP_CAT_MAP[it.category];
              const maxSold = Math.max(...items.map(x=>x.sold));
              const pct = (it.sold / maxSold) * 100;
              return (
                <div key={it.id} style={{ padding:'10px 0', borderBottom: i < 5 ? `1px solid ${C.borderLight}` : 'none' }}>
                  <div style={{ display:'flex', justifyContent:'space-between', marginBottom:6 }}>
                    <div style={{ display:'flex', alignItems:'center', gap:8 }}>
                      <CategoryDot catId={it.category} />
                      <span style={{ fontWeight:700, fontSize:13, color:C.navy }}>{it.name}</span>
                      <span style={{ fontSize:11, color:C.textMuted }}>· {cat.label}</span>
                    </div>
                    <span style={{ fontWeight:800, fontSize:13, color:C.navy }}>{it.sold} <span style={{ fontSize:11, fontWeight:600, color:C.textMuted }}>sold · {it.sold*it.price}m</span></span>
                  </div>
                  <div style={{ height:6, background:C.bg, borderRadius:3, overflow:'hidden' }}>
                    <div style={{ height:'100%', width:`${pct}%`, background:cat.ink, borderRadius:3 }} />
                  </div>
                </div>
              );
            })}
          </Card>

          <Card>
            <p style={{ fontWeight:800, fontSize:14, color:C.navy, marginBottom:14 }}>Restock Alerts</p>
            {items.filter(i => i.stock <= i.lowAt && i.active).map(it => (
              <div key={it.id} style={{ display:'flex', alignItems:'center', gap:10, padding:'8px 0' }}>
                <div style={{ width:8, height:8, borderRadius:'50%', background: it.stock === 0 ? C.danger : C.warning }} />
                <div style={{ flex:1 }}>
                  <p style={{ fontSize:13, fontWeight:700, color:C.navy }}>{it.name}</p>
                  <p style={{ fontSize:11, color:C.textMuted }}>{it.stock === 0 ? 'Out of stock' : `${it.stock} left · threshold ${it.lowAt}`}</p>
                </div>
                <Btn variant="secondary" size="sm" onClick={()=>setEditing(it.id)}>Restock</Btn>
              </div>
            ))}
            {items.filter(i => i.stock <= i.lowAt && i.active).length === 0 && (
              <p style={{ fontSize:12, color:C.textMuted, padding:'12px 0' }}>All stock levels healthy.</p>
            )}
          </Card>
        </div>
      )}

      {/* ── Edit modal ── */}
      {editing != null && editingItem && (
        <AdminItemEditModal
          item={editingItem}
          isNew={editing === 'new'}
          onSave={saveItem}
          onDelete={() => deleteItem(editingItem.id)}
          onClose={() => setEditing(null)}
        />
      )}
    </div>
  );
};

const stockBtnStyle = { width:22, height:22, borderRadius:5, border:'1.5px solid #DDE3F0', background:'#fff', cursor:'pointer', fontWeight:700, color:'#1B2B5E', fontFamily:'inherit' };

/* ── Admin mobile item card ──────────────────────────────────────────────── */
const AdminItemCardMobile = ({ item, onEdit, onToggle, onStock }) => {
  const cat = SHOP_CAT_MAP[item.category];
  return (
    <Card padding={14}>
      <div style={{ display:'flex', gap:12 }}>
        <div style={{ width:64, height:64, flexShrink:0 }}><ShopTile item={item} size="sm" radius={10} /></div>
        <div style={{ flex:1, minWidth:0 }}>
          <div style={{ display:'flex', alignItems:'center', gap:6, marginBottom:4 }}>
            <CategoryDot catId={item.category} size={6} />
            <p style={{ fontSize:10, fontWeight:700, color:cat.ink, textTransform:'uppercase', letterSpacing:'0.5px' }}>{cat.label}</p>
          </div>
          <p style={{ fontWeight:700, fontSize:14, color:C.navy }}>{item.name}</p>
          <p style={{ fontSize:11, color:C.textSecondary, marginTop:2 }}>{item.price} merits · {item.sold||0} sold</p>
        </div>
        <div>
          {!item.active ? <Badge variant="grey">Paused</Badge>
            : item.stock === 0 ? <Badge variant="red">Out</Badge>
            : item.stock <= item.lowAt ? <Badge variant="amber">Low</Badge>
            : <Badge variant="green">Active</Badge>}
        </div>
      </div>
      <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginTop:12, gap:8 }}>
        <div style={{ display:'flex', alignItems:'center', gap:6 }}>
          <span style={{ fontSize:11, color:C.textMuted, fontWeight:600 }}>Stock</span>
          <button onClick={()=>onStock(-1)} style={stockBtnStyle}>−</button>
          <span style={{ minWidth:26, textAlign:'center', fontWeight:800, fontSize:14, color:C.navy }}>{item.stock}</span>
          <button onClick={()=>onStock(+1)} style={stockBtnStyle}>+</button>
        </div>
        <div style={{ display:'flex', gap:6 }}>
          <Btn variant="secondary" size="sm" onClick={onEdit}>Edit</Btn>
          <Btn variant="ghost" size="sm" onClick={onToggle}>{item.active?'Pause':'Resume'}</Btn>
        </div>
      </div>
    </Card>
  );
};

/* ── Edit Item Modal ──────────────────────────────────────────────────────── */
const AdminItemEditModal = ({ item, isNew, onSave, onDelete, onClose }) => {
  const [form, setForm] = React.useState({ ...item });
  const [confirmDelete, setCD] = React.useState(false);

  React.useEffect(() => {
    const h = e => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', h);
    return () => window.removeEventListener('keydown', h);
  }, [onClose]);

  const update = (k, v) => setForm(f => ({ ...f, [k]: v }));
  const valid = form.name.trim() && form.price >= 0 && form.stock >= 0;

  return (
    <div onClick={onClose} style={{ position:'fixed', inset:0, background:'rgba(10,18,40,0.55)', backdropFilter:'blur(4px)', zIndex:9000, display:'flex', alignItems:'center', justifyContent:'center', padding:24, animation:'pageFadeIn 0.18s ease' }}>
      <div onClick={e=>e.stopPropagation()} style={{ background:'#fff', borderRadius:18, width:'100%', maxWidth:560, maxHeight:'calc(100vh - 48px)', overflow:'hidden', boxShadow:'0 32px 80px rgba(0,0,0,0.32)', display:'flex', flexDirection:'column' }}>

        {/* Header */}
        <div style={{ background:`linear-gradient(130deg, ${C.navy} 0%, ${C.navyMid} 100%)`, padding:'20px 24px', display:'flex', alignItems:'center', gap:14 }}>
          <div style={{ width:42, height:42, borderRadius:12, background:'rgba(255,255,255,0.12)', display:'flex', alignItems:'center', justifyContent:'center' }}>
            <svg width={22} height={22} viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round"><path d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"/></svg>
          </div>
          <div style={{ flex:1 }}>
            <p style={{ fontSize:17, fontWeight:800, color:'#fff' }}>{isNew ? 'Add Shop Item' : 'Edit Shop Item'}</p>
            <p style={{ fontSize:12, color:'rgba(255,255,255,0.65)', marginTop:3 }}>{isNew ? 'Create a new reward to put on the shelf.' : `Editing · ID #${form.id}`}</p>
          </div>
          <button onClick={onClose} style={{ width:32, height:32, borderRadius:8, background:'rgba(255,255,255,0.12)', border:'none', display:'flex', alignItems:'center', justifyContent:'center', cursor:'pointer', color:'#fff' }}>
            <svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2.5} strokeLinecap="round"><path d="M18 6L6 18M6 6l12 12"/></svg>
          </button>
        </div>

        {/* Body */}
        <div style={{ flex:1, overflowY:'auto', padding:'22px 24px' }}>
          {/* Preview */}
          <div style={{ display:'flex', gap:14, marginBottom:18 }}>
            <div style={{ width:96, height:96, flexShrink:0 }}><ShopTile item={form.name ? form : {...form, name:'New Item'}} size="md" radius={12} /></div>
            <div style={{ flex:1 }}>
              <p style={{ fontSize:11, fontWeight:700, color:C.textMuted, textTransform:'uppercase', letterSpacing:'0.5px', marginBottom:6 }}>Preview</p>
              <p style={{ fontSize:11, color:C.textMuted, lineHeight:1.5 }}>Real photography can be uploaded later via the photo button. Tinted tile is a placeholder so the list stays scannable.</p>
              <button style={{ marginTop:8, padding:'5px 10px', background:C.bg, border:`1px dashed ${C.border}`, borderRadius:6, fontSize:11, fontWeight:600, color:C.textSecondary, cursor:'pointer', fontFamily:'inherit' }}>📷 Upload photo</button>
            </div>
          </div>

          {/* Form rows */}
          <div style={{ marginBottom:14 }}>
            <label style={fieldLabel}>Item Name</label>
            <input value={form.name} onChange={e=>update('name', e.target.value)} placeholder="e.g. Iced Lemonade" style={fieldInput} />
          </div>

          <div style={{ marginBottom:14 }}>
            <label style={fieldLabel}>Short Blurb · shown on cards</label>
            <input value={form.blurb} onChange={e=>update('blurb', e.target.value)} placeholder="One-line description, ~6 words" style={fieldInput} />
          </div>

          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:12, marginBottom:14 }}>
            <div>
              <label style={fieldLabel}>Category</label>
              <select value={form.category} onChange={e=>update('category', e.target.value)} style={fieldInput}>
                {SHOP_CATEGORIES.map(c => <option key={c.id} value={c.id}>{c.label}</option>)}
              </select>
            </div>
            <div>
              <label style={fieldLabel}>Price (merits)</label>
              <input type="number" min={0} value={form.price} onChange={e=>update('price', parseInt(e.target.value, 10) || 0)} style={{ ...fieldInput, fontWeight:800, color:C.crimson }} />
            </div>
          </div>

          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:12, marginBottom:14 }}>
            <div>
              <label style={fieldLabel}>Stock Level</label>
              <input type="number" min={0} value={form.stock} onChange={e=>update('stock', parseInt(e.target.value, 10) || 0)} style={fieldInput} />
            </div>
            <div>
              <label style={fieldLabel}>Low-Stock Threshold</label>
              <input type="number" min={0} value={form.lowAt} onChange={e=>update('lowAt', parseInt(e.target.value, 10) || 0)} style={fieldInput} />
            </div>
          </div>

          <div style={{ marginBottom:14 }}>
            <label style={fieldLabel}>Full Description</label>
            <textarea value={form.description} onChange={e=>update('description', e.target.value)} rows={3} placeholder="Detailed description, allergens, redemption rules…" style={{ ...fieldInput, fontFamily:'inherit', resize:'vertical' }} />
          </div>

          {/* Active toggle */}
          <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', padding:'12px 14px', background:C.bg, borderRadius:10, marginBottom:14 }}>
            <div>
              <p style={{ fontSize:13, fontWeight:700, color:C.navy }}>Visible in Shop</p>
              <p style={{ fontSize:11, color:C.textMuted, marginTop:2 }}>Parents & students can see and reserve this item.</p>
            </div>
            <button onClick={()=>update('active', !form.active)} style={{ width:46, height:26, borderRadius:13, background: form.active ? C.success : '#cbd5e1', border:'none', position:'relative', cursor:'pointer', transition:'background 0.15s' }}>
              <span style={{ position:'absolute', top:3, left: form.active ? 23 : 3, width:20, height:20, borderRadius:'50%', background:'#fff', transition:'left 0.15s', boxShadow:'0 1px 3px rgba(0,0,0,0.2)' }} />
            </button>
          </div>

          {!isNew && (
            <div style={{ paddingTop:14, borderTop:`1px solid ${C.border}` }}>
              {!confirmDelete ? (
                <button onClick={()=>setCD(true)} style={{ background:'none', border:'none', color:C.danger, fontWeight:700, fontSize:13, cursor:'pointer', fontFamily:'inherit' }}>Delete this item</button>
              ) : (
                <div style={{ padding:12, background:C.dangerBg, borderRadius:8, display:'flex', alignItems:'center', gap:10 }}>
                  <p style={{ flex:1, fontSize:12, color:C.danger, fontWeight:600 }}>Delete permanently? Sales history is preserved.</p>
                  <Btn variant="secondary" size="sm" onClick={()=>setCD(false)}>Cancel</Btn>
                  <Btn variant="primary" size="sm" onClick={onDelete}>Confirm Delete</Btn>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Footer */}
        <div style={{ padding:'16px 24px', borderTop:`1px solid ${C.border}`, background:C.bg, display:'flex', gap:10, justifyContent:'flex-end' }}>
          <Btn variant="secondary" onClick={onClose}>Cancel</Btn>
          <Btn variant="navy" onClick={()=>valid && onSave(form)} disabled={!valid}>{isNew ? 'Add to Catalogue' : 'Save Changes'}</Btn>
        </div>
      </div>
    </div>
  );
};

const fieldLabel = { fontSize:11, fontWeight:700, color:'#5A6A8A', display:'block', marginBottom:6, textTransform:'uppercase', letterSpacing:'0.4px' };
const fieldInput = { width:'100%', padding:'10px 12px', border:'1.5px solid #DDE3F0', borderRadius:8, fontSize:13, fontFamily:'inherit', color:'#1B2B5E', background:'#fff', outline:'none' };

/* Export to window so admin-portal.jsx and parent-portal.jsx can use them */
Object.assign(window, { ParentShop, AdminShop, ShopTile, SHOP_CAT_MAP, SHOP_ITEM_MAP });
