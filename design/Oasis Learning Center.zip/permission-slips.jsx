// permission-slips.jsx — Admin (Staff) + Parent views for permission slips.
//
// Admin can:
//   - See Active / Inactive slip lists with signed / pending / declined counts
//   - Drill into a slip to see per-student responses, send reminders, export CSV
//   - Compose a new slip in the form builder (title, description, event details,
//     cost, custom text questions, required-field toggles, deadline, recipients)
//   - Archive a slip (moves to Inactive) or duplicate as template
//
// Parent can:
//   - See Outstanding (still pending response) and Completed (signed / declined) lists
//   - Read the full slip preview, then sign (typed e-signature) or decline (with reason)
//
// "Inactive" = deadline already passed OR manually archived by admin.

(() => {
  const { useState, useMemo, useRef, useEffect } = React;

  // ── Date helpers ─────────────────────────────────────────────────────────
  // Use the literal string (a global `TODAY` Date object from another file
  // shadows the shared-data string — avoid that and read it from shared-data).
  const TODAY_STR = window.TODAY && typeof window.TODAY === 'string' ? window.TODAY : '2026-04-25';
  const parseDate = s => s ? new Date(s + 'T00:00:00') : null;
  const today = parseDate(TODAY_STR);

  const fmtDate = (iso) => {
    if (!iso) return '—';
    const d = parseDate(iso);
    return d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
  };
  const fmtDateShort = (iso) => {
    if (!iso) return '—';
    const d = parseDate(iso);
    return d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short' });
  };
  const daysUntil = (iso) => {
    const d = parseDate(iso);
    return Math.round((d - today) / (1000 * 60 * 60 * 24));
  };

  // ── Slip status helpers ──────────────────────────────────────────────────
  const tallyResponses = (slip) => {
    const total = slip.studentIds.length;
    let signed = 0, declined = 0, pending = 0;
    slip.studentIds.forEach(id => {
      const r = slip.responses[id];
      if (!r || r.status === 'pending') pending++;
      else if (r.status === 'signed') signed++;
      else if (r.status === 'declined') declined++;
    });
    return { total, signed, declined, pending,
             pctSigned:   total ? signed   / total * 100 : 0,
             pctDeclined: total ? declined / total * 100 : 0,
             pctPending:  total ? pending  / total * 100 : 0 };
  };

  const isActive = (slip, archivedSet) =>
    !archivedSet.has(slip.id) && daysUntil(slip.deadline) >= 0;

  const categoryStyle = (cat) => ({
    'School Trip':  { bg:'#E8F1FB', fg:'#1E4D86' },
    'Activity':     { bg:'#E6F3EC', fg:'#1F6B45' },
    'Reward':       { bg:'#FBF3D9', fg:'#7E6315' },
    'Consent':      { bg:'#F1ECFA', fg:'#5E47A8' },
  }[cat] || { bg:C.bg, fg:C.textSecondary });

  // ── Response breakdown bar (stacked) ─────────────────────────────────────
  const ResponseBar = ({ slip, height = 8, showCounts = false }) => {
    const t = tallyResponses(slip);
    return (
      <div>
        <div style={{
          width:'100%', height, background:'#EEF2F9',
          borderRadius:height/2, overflow:'hidden', display:'flex',
        }}>
          {t.signed   > 0 && <div title={`${t.signed} signed`}     style={{ width:`${t.pctSigned}%`,   background:C.success }} />}
          {t.declined > 0 && <div title={`${t.declined} declined`} style={{ width:`${t.pctDeclined}%`, background:C.danger  }} />}
          {t.pending  > 0 && <div title={`${t.pending} pending`}   style={{ width:`${t.pctPending}%`,  background:'#C5CDE0' }} />}
        </div>
        {showCounts && (
          <div style={{ display:'flex', gap:14, marginTop:8, fontSize:12, fontWeight:600 }}>
            <span style={{ color:C.success }}>● {t.signed} signed</span>
            <span style={{ color:C.danger  }}>● {t.declined} declined</span>
            <span style={{ color:C.textSecondary }}>● {t.pending} pending</span>
          </div>
        )}
      </div>
    );
  };

  // ── Deadline pill ────────────────────────────────────────────────────────
  const DeadlinePill = ({ iso, archived }) => {
    if (archived) return <Badge variant="grey">Archived</Badge>;
    const days = daysUntil(iso);
    if (days < 0)  return <Badge variant="grey">Closed · {Math.abs(days)}d ago</Badge>;
    if (days === 0) return <Badge variant="red">Due today</Badge>;
    if (days <= 3)  return <Badge variant="amber">{days}d left</Badge>;
    return <Badge variant="blue">{days}d left</Badge>;
  };

  // ── SVG icons (small set) ────────────────────────────────────────────────
  const SvgIcon = ({ d, size=16, stroke=1.8, color='currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round"><path d={d} /></svg>
  );
  const ICON = {
    calendar:  'M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z',
    clock:     'M12 8v4l3 3M21 12a9 9 0 11-18 0 9 9 0 0118 0z',
    pin:       'M17.657 16.657L13.414 20.9a2 2 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0zM15 11a3 3 0 11-6 0 3 3 0 016 0z',
    coin:      'M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z',
    bus:       'M8 7h8m-8 4h8m-9 8h10a2 2 0 002-2V8a4 4 0 00-4-4H9a4 4 0 00-4 4v9a2 2 0 002 2zm1-2a1 1 0 100-2 1 1 0 000 2zm8 0a1 1 0 100-2 1 1 0 000 2z',
    plus:      'M12 4v16m8-8H4',
    download:  'M4 16v2a2 2 0 002 2h12a2 2 0 002-2v-2M7 10l5 5 5-5M12 15V3',
    bell:      'M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6 6 0 00-12 0v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9',
    archive:   'M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4',
    copy:      'M8 5H6a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2v-2m-8-2h10a2 2 0 002-2V5a2 2 0 00-2-2H10a2 2 0 00-2 2v12a2 2 0 002 2z',
    chevron:   'M9 5l7 7-7 7',
    check:     'M5 13l4 4L19 7',
    x:         'M18 6L6 18M6 6l12 12',
    edit:      'M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z',
  };

  // ─────────────────────────────────────────────────────────────────────────
  // ADMIN — Slip card (used in lists)
  // ─────────────────────────────────────────────────────────────────────────
  const AdminSlipCard = ({ slip, archived, onOpen }) => {
    const t = tallyResponses(slip);
    const cat = categoryStyle(slip.category);
    return (
      <Card style={{ padding:18, cursor:'pointer', transition:'all 0.15s' }}>
        <div onClick={onOpen}
          onMouseEnter={e => { e.currentTarget.style.borderColor = C.blue; e.currentTarget.style.boxShadow = '0 4px 12px rgba(91,144,197,0.12)'; }}
          onMouseLeave={e => { e.currentTarget.style.borderColor = ''; e.currentTarget.style.boxShadow = ''; }}>
          <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', gap:12, marginBottom:10 }}>
            <div style={{ flex:1, minWidth:0 }}>
              <div style={{ display:'flex', gap:8, alignItems:'center', marginBottom:6, flexWrap:'wrap' }}>
                <span style={{ display:'inline-flex', padding:'3px 9px', borderRadius:5, fontSize:10, fontWeight:700, background:cat.bg, color:cat.fg, textTransform:'uppercase', letterSpacing:'0.5px' }}>{slip.category}</span>
                <DeadlinePill iso={slip.deadline} archived={archived} />
              </div>
              <p style={{ fontSize:16, fontWeight:800, color:C.navy, marginBottom:3 }}>{slip.title}</p>
              <p style={{ fontSize:12, color:C.textSecondary }}>
                {slip.recipients} · Deadline {fmtDate(slip.deadline)} · Issued by {slip.issuedBy}
              </p>
            </div>
            <div style={{ textAlign:'right', flexShrink:0 }}>
              <p style={{ fontSize:22, fontWeight:800, color:C.navy, lineHeight:1 }}>{t.signed}<span style={{ fontSize:14, color:C.textMuted, fontWeight:600 }}>/{t.total}</span></p>
              <p style={{ fontSize:10, color:C.textMuted, marginTop:2, textTransform:'uppercase', letterSpacing:'0.4px' }}>signed</p>
            </div>
          </div>
          <ResponseBar slip={slip} showCounts />
        </div>
      </Card>
    );
  };

  // ─────────────────────────────────────────────────────────────────────────
  // ADMIN — Slip detail (per-student response list + actions)
  // ─────────────────────────────────────────────────────────────────────────
  const AdminSlipDetail = ({ slip, archived, onBack, onArchive, onUnarchive, onDuplicate, mobile }) => {
    const t = tallyResponses(slip);
    const [filter, setFilter] = useState('all');
    const [remindToast, setRemindToast] = useState('');

    const rows = slip.studentIds.map(id => {
      const s = STUDENTS.find(x => x.id === id);
      const r = slip.responses[id] || { status:'pending' };
      return { student:s, response:r };
    }).filter(row => filter === 'all' || row.response.status === filter);

    const sendReminder = (name) => {
      setRemindToast(name ? `Reminder sent to ${name}'s parent` : `Reminder sent to ${t.pending} pending families`);
      setTimeout(() => setRemindToast(''), 2400);
    };

    return (
      <div className="page-fade">
        {/* Back link */}
        <button onClick={onBack} style={{ display:'flex', alignItems:'center', gap:6, background:'none', border:'none', color:C.blue, fontWeight:600, fontSize:13, cursor:'pointer', marginBottom:16, fontFamily:'inherit' }}>← Back to Permission Slips</button>

        {/* Header card */}
        <Card style={{ marginBottom:16 }}>
          <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', gap:16, flexWrap:'wrap', marginBottom:14 }}>
            <div style={{ flex:1, minWidth:240 }}>
              <div style={{ display:'flex', gap:8, marginBottom:8, flexWrap:'wrap' }}>
                {(() => { const cat = categoryStyle(slip.category); return <span style={{ display:'inline-flex', padding:'3px 9px', borderRadius:5, fontSize:10, fontWeight:700, background:cat.bg, color:cat.fg, textTransform:'uppercase', letterSpacing:'0.5px' }}>{slip.category}</span>; })()}
                <DeadlinePill iso={slip.deadline} archived={archived} />
                <Badge variant="grey">{slip.id}</Badge>
              </div>
              <h2 style={{ fontSize:mobile?20:24, fontWeight:800, color:C.navy, marginBottom:6 }}>{slip.title}</h2>
              <p style={{ fontSize:13, color:C.textSecondary }}>Issued {fmtDate(slip.issued)} by {slip.issuedBy} · Recipients: {slip.recipients}</p>
            </div>
            <div style={{ display:'flex', gap:8, flexWrap:'wrap' }}>
              {!archived && t.pending > 0 && <Btn variant="primary" size="sm" onClick={() => sendReminder(null)}><SvgIcon d={ICON.bell} size={13} /> Remind {t.pending} parents</Btn>}
              <Btn variant="secondary" size="sm"><SvgIcon d={ICON.download} size={13} /> Export CSV</Btn>
              <Btn variant="secondary" size="sm" onClick={onDuplicate}><SvgIcon d={ICON.copy} size={13} /> Duplicate</Btn>
              {archived
                ? <Btn variant="secondary" size="sm" onClick={onUnarchive}>Restore</Btn>
                : <Btn variant="secondary" size="sm" onClick={onArchive}><SvgIcon d={ICON.archive} size={13} /> Archive</Btn>}
            </div>
          </div>

          {/* Event details strip */}
          {(slip.eventDate || slip.location || slip.cost) && (
            <div style={{ display:'grid', gridTemplateColumns:mobile?'1fr 1fr':'repeat(auto-fit, minmax(140px, 1fr))', gap:10, padding:'14px', background:C.bg, borderRadius:10, marginBottom:14 }}>
              {slip.eventDate    && <Detail icon={ICON.calendar} label="Event date" value={fmtDate(slip.eventDate)} />}
              {slip.departureTime && <Detail icon={ICON.clock}    label="Departure"   value={slip.departureTime} />}
              {slip.location     && <Detail icon={ICON.pin}       label="Location"    value={slip.location} />}
              {slip.transport    && <Detail icon={ICON.bus}       label="Transport"   value={slip.transport} />}
              {slip.cost         && <Detail icon={ICON.coin}      label="Cost"        value={slip.cost} />}
            </div>
          )}

          <p style={{ fontSize:13, color:C.textPrimary, lineHeight:1.7 }}>{slip.description}</p>
        </Card>

        {/* Response stats */}
        <div style={{ display:'grid', gridTemplateColumns:mobile?'1fr 1fr':'repeat(4,1fr)', gap:12, marginBottom:16 }}>
          <StatCard label="Recipients"   value={t.total}                         sub={`${Math.round((t.signed/t.total)*100)}% complete`} accent={C.navy} />
          <StatCard label="Signed"       value={t.signed}                         sub="Permission granted" accent={C.success} />
          <StatCard label="Declined"     value={t.declined}                       sub="Permission refused" accent={C.danger} />
          <StatCard label="Awaiting"     value={t.pending}                        sub="No response yet"    accent={C.warning} />
        </div>

        {/* Progress bar */}
        <Card style={{ marginBottom:16 }}>
          <p style={{ fontSize:12, fontWeight:700, color:C.textSecondary, textTransform:'uppercase', letterSpacing:'0.5px', marginBottom:10 }}>Response breakdown</p>
          <ResponseBar slip={slip} height={12} showCounts />
        </Card>

        {/* Filter tabs */}
        <div style={{ display:'flex', gap:4, marginBottom:12, background:C.bg, borderRadius:9, padding:4, width:'fit-content', flexWrap:'wrap' }}>
          {[['all','All',t.total],['signed','Signed',t.signed],['declined','Declined',t.declined],['pending','Pending',t.pending]].map(([id,l,n]) => (
            <button key={id} onClick={() => setFilter(id)} style={{ padding:'7px 14px', borderRadius:6, border:'none', background:filter===id?C.surface:'transparent', color:filter===id?C.navy:C.textSecondary, fontWeight:700, fontSize:12, cursor:'pointer', fontFamily:'inherit', boxShadow:filter===id?'0 1px 2px rgba(0,0,0,0.08)':'none' }}>{l} <span style={{ color:C.textMuted, fontWeight:600 }}>{n}</span></button>
          ))}
        </div>

        {/* Response rows */}
        <Card padding={0}>
          {rows.length === 0
            ? <p style={{ padding:24, fontSize:13, color:C.textMuted, textAlign:'center' }}>No students match this filter.</p>
            : rows.map((row, i) => (
              <ResponseRow key={row.student.id} row={row} last={i===rows.length-1} onRemind={() => sendReminder(row.student.name.split(' ')[0])} mobile={mobile} />
            ))
          }
        </Card>

        {/* Toast */}
        {remindToast && (
          <div style={{ position:'fixed', bottom:80, left:'50%', transform:'translateX(-50%)', background:C.navy, color:'#fff', padding:'12px 20px', borderRadius:10, fontSize:13, fontWeight:600, boxShadow:'0 8px 24px rgba(0,0,0,0.2)', zIndex:9000, animation:'pageFadeIn 0.18s ease' }}>
            ✓ {remindToast}
          </div>
        )}
      </div>
    );
  };

  const Detail = ({ icon, label, value }) => (
    <div style={{ display:'flex', alignItems:'flex-start', gap:8, minWidth:0 }}>
      <div style={{ color:C.blue, flexShrink:0, marginTop:1 }}><SvgIcon d={icon} size={15} /></div>
      <div style={{ minWidth:0 }}>
        <p style={{ fontSize:10, fontWeight:700, color:C.textMuted, textTransform:'uppercase', letterSpacing:'0.4px' }}>{label}</p>
        <p style={{ fontSize:13, fontWeight:600, color:C.navy, marginTop:1, overflow:'hidden', textOverflow:'ellipsis' }}>{value}</p>
      </div>
    </div>
  );

  const ResponseRow = ({ row, last, onRemind, mobile }) => {
    const { student, response } = row;
    const [expanded, setExpanded] = useState(false);
    const hasDetails = response.medicalInfo || response.emergency || response.declineReason;
    const statusBadge = {
      signed:   <Badge variant="green">✓ Signed</Badge>,
      declined: <Badge variant="red">✗ Declined</Badge>,
      pending:  <Badge variant="grey">⌛ Awaiting</Badge>,
    }[response.status];

    return (
      <>
        <div style={{ display:'flex', alignItems:'center', gap:12, padding:'12px 16px', borderBottom:last?'none':`1px solid ${C.border}` }}>
          <Avatar initials={student.initials} size={34} color={student.color} />
          <div style={{ flex:1, minWidth:0 }}>
            <p style={{ fontWeight:700, fontSize:13, color:C.navy }}>{student.name}</p>
            <p style={{ fontSize:11, color:C.textSecondary }}>
              {student.year}
              {response.parentName && ` · ${response.parentName}`}
              {response.signedAt && ` · ${response.signedAt}`}
            </p>
          </div>
          {statusBadge}
          {response.status === 'pending'
            ? <Btn variant="secondary" size="sm" onClick={onRemind}><SvgIcon d={ICON.bell} size={12} /> Remind</Btn>
            : hasDetails
              ? <button onClick={() => setExpanded(e=>!e)} style={{ padding:'5px 10px', background:'none', border:`1px solid ${C.border}`, borderRadius:6, fontSize:11, fontWeight:600, color:C.textSecondary, cursor:'pointer', fontFamily:'inherit' }}>{expanded?'Hide':'Details'}</button>
              : null
          }
        </div>
        {expanded && hasDetails && (
          <div style={{ padding:'14px 16px 16px 62px', background:C.bg, borderBottom:last?'none':`1px solid ${C.border}` }}>
            {response.medicalInfo && <DetailRow label="Medical info" value={response.medicalInfo} />}
            {response.emergency   && <DetailRow label="Emergency contact" value={response.emergency} />}
            {response.declineReason && <DetailRow label="Reason for declining" value={response.declineReason} />}
          </div>
        )}
      </>
    );
  };

  const DetailRow = ({ label, value }) => (
    <div style={{ marginBottom:8 }}>
      <p style={{ fontSize:10, fontWeight:700, color:C.textMuted, textTransform:'uppercase', letterSpacing:'0.4px', marginBottom:2 }}>{label}</p>
      <p style={{ fontSize:13, color:C.textPrimary }}>{value}</p>
    </div>
  );

  // ─────────────────────────────────────────────────────────────────────────
  // ADMIN — Form Builder (compose / edit a slip)
  // ─────────────────────────────────────────────────────────────────────────
  const BUILDER_DEFAULT = {
    title: '',
    category: 'School Trip',
    description: '',
    eventDate: '',
    deadline: '',
    departureTime: '',
    returnTime: '',
    location: '',
    transport: '',
    cost: '',
    whatToBring: [],
    consentText: 'I give permission for my child to take part in this activity. I understand that my child will be supervised by school staff at all times.',
    requireMedical: true,
    requireEmergencyContact: true,
    requirePayment: false,
    perChild: true,
    recipients: 'Years 7–10',
    studentIds: [1,2,3,4,5,6,7,8,9,10],
    customQuestions: [],
  };

  const AdminBuilder = ({ initial, onCancel, onSave, mobile }) => {
    const [f, setF] = useState({ ...BUILDER_DEFAULT, ...(initial || {}) });
    const [bringDraft, setBringDraft] = useState('');
    const [showPreview, setShowPreview] = useState(false);
    const set = (k, v) => setF(s => ({ ...s, [k]: v }));

    const addBring = () => {
      if (!bringDraft.trim()) return;
      setF(s => ({ ...s, whatToBring: [...s.whatToBring, bringDraft.trim()] }));
      setBringDraft('');
    };
    const removeBring = (i) => setF(s => ({ ...s, whatToBring: s.whatToBring.filter((_,j)=>j!==i) }));

    const addQuestion = () => setF(s => ({ ...s, customQuestions: [...s.customQuestions, { id: Date.now(), label:'', required:true }] }));
    const updateQuestion = (id, patch) => setF(s => ({ ...s, customQuestions: s.customQuestions.map(q => q.id===id ? {...q, ...patch} : q) }));
    const removeQuestion = (id) => setF(s => ({ ...s, customQuestions: s.customQuestions.filter(q => q.id !== id) }));

    const toggleStudent = (id) => setF(s => ({ ...s, studentIds: s.studentIds.includes(id) ? s.studentIds.filter(x => x !== id) : [...s.studentIds, id] }));

    const canSend = f.title.trim() && f.deadline && f.studentIds.length > 0;

    return (
      <div className="page-fade">
        <button onClick={onCancel} style={{ display:'flex', alignItems:'center', gap:6, background:'none', border:'none', color:C.blue, fontWeight:600, fontSize:13, cursor:'pointer', marginBottom:16, fontFamily:'inherit' }}>← Cancel and return to list</button>

        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', gap:16, marginBottom:20, flexWrap:'wrap' }}>
          <div>
            <h2 style={{ fontSize:mobile?20:26, fontWeight:800, color:C.navy }}>{initial ? 'Duplicate slip' : 'New permission slip'}</h2>
            <p style={{ fontSize:13, color:C.textSecondary, marginTop:4 }}>Compose the form parents will sign. Fields you toggle on become required.</p>
          </div>
          <div style={{ display:'flex', gap:8 }}>
            <Btn variant="secondary" onClick={() => setShowPreview(p => !p)}>{showPreview ? 'Back to editor' : 'Preview as parent'}</Btn>
            <Btn variant="primary" disabled={!canSend} onClick={() => onSave(f)}>{canSend ? `Send to ${f.studentIds.length} families` : 'Save draft'}</Btn>
          </div>
        </div>

        {showPreview ? <BuilderPreview f={f} /> : (
          <div style={{ display:'grid', gridTemplateColumns:mobile?'1fr':'1fr 320px', gap:16, alignItems:'start' }}>
            {/* Left column — the form */}
            <div style={{ display:'flex', flexDirection:'column', gap:16 }}>
              <BuilderSection title="Title & description" num={1}>
                <Field label="Form title">
                  <input value={f.title} onChange={e=>set('title', e.target.value)} placeholder="e.g. Cadbury World — Spring Trip"
                    style={inputStyle(20, 700)} />
                </Field>
                <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:12 }}>
                  <Field label="Category">
                    <select value={f.category} onChange={e=>set('category', e.target.value)} style={inputStyle()}>
                      {['School Trip','Activity','Reward','Consent'].map(c => <option key={c} value={c}>{c}</option>)}
                    </select>
                  </Field>
                  <Field label="Recipient label (display)">
                    <input value={f.recipients} onChange={e=>set('recipients', e.target.value)} placeholder="e.g. Years 7–10" style={inputStyle()} />
                  </Field>
                </div>
                <Field label="Description">
                  <textarea value={f.description} onChange={e=>set('description', e.target.value)} placeholder="Describe the trip / activity / consent in full. Parents see this before signing." rows={4} style={{ ...inputStyle(), resize:'vertical' }} />
                </Field>
              </BuilderSection>

              <BuilderSection title="Event details" num={2} subtitle="Leave blank for non-event consent forms (e.g. photography).">
                <div style={{ display:'grid', gridTemplateColumns:mobile?'1fr':'1fr 1fr', gap:12 }}>
                  <Field label="Event date">
                    <input type="date" value={f.eventDate} onChange={e=>set('eventDate', e.target.value)} style={inputStyle()} />
                  </Field>
                  <Field label="Cost">
                    <input value={f.cost} onChange={e=>set('cost', e.target.value)} placeholder="e.g. £25 or 150 merits" style={inputStyle()} />
                  </Field>
                  <Field label="Departure time">
                    <input value={f.departureTime} onChange={e=>set('departureTime', e.target.value)} placeholder="e.g. 09:00" style={inputStyle()} />
                  </Field>
                  <Field label="Return time">
                    <input value={f.returnTime} onChange={e=>set('returnTime', e.target.value)} placeholder="e.g. 15:30" style={inputStyle()} />
                  </Field>
                  <Field label="Location">
                    <input value={f.location} onChange={e=>set('location', e.target.value)} placeholder="e.g. Howletts Wild Animal Park, Kent" style={inputStyle()} />
                  </Field>
                  <Field label="Transport">
                    <input value={f.transport} onChange={e=>set('transport', e.target.value)} placeholder="e.g. Minibus" style={inputStyle()} />
                  </Field>
                </div>

                <Field label="What to bring" hint="Add items one at a time. Parents see these as a checklist.">
                  <div style={{ display:'flex', gap:8 }}>
                    <input value={bringDraft} onChange={e=>setBringDraft(e.target.value)} onKeyDown={e => e.key==='Enter' && (e.preventDefault(), addBring())} placeholder="e.g. Packed lunch" style={{ ...inputStyle(), flex:1 }} />
                    <Btn variant="secondary" size="md" onClick={addBring}>Add</Btn>
                  </div>
                  {f.whatToBring.length > 0 && (
                    <div style={{ display:'flex', flexWrap:'wrap', gap:6, marginTop:10 }}>
                      {f.whatToBring.map((b, i) => (
                        <span key={i} style={{ display:'inline-flex', alignItems:'center', gap:6, padding:'5px 10px', background:C.blueLight, borderRadius:6, fontSize:12, fontWeight:600, color:C.navy }}>
                          {b}
                          <button onClick={() => removeBring(i)} style={{ background:'none', border:'none', cursor:'pointer', color:C.navy, padding:0, lineHeight:1, fontSize:14 }} aria-label="Remove">×</button>
                        </span>
                      ))}
                    </div>
                  )}
                </Field>
              </BuilderSection>

              <BuilderSection title="Required from parents" num={3} subtitle="Standard fields parents must complete when signing.">
                <Toggle label="Medical / allergy information" desc="Parent enters any medical notes or allergies." value={f.requireMedical}          onChange={v=>set('requireMedical', v)} />
                <Toggle label="Emergency contact"               desc="Name, phone number and relationship."       value={f.requireEmergencyContact} onChange={v=>set('requireEmergencyContact', v)} />
                <Toggle label="Payment / merit acknowledgement" desc="Parent confirms they will pay or merit-spend the cost." value={f.requirePayment}          onChange={v=>set('requirePayment', v)} />
                <Toggle label="One signature per child"         desc="Off: one signature covers the whole family. On: parent signs separately for each child."  value={f.perChild}                onChange={v=>set('perChild', v)} />
              </BuilderSection>

              <BuilderSection title="Custom questions" num={4} subtitle="Free-text questions specific to this slip.">
                {f.customQuestions.length === 0 && <p style={{ fontSize:12, color:C.textMuted, marginBottom:10 }}>No custom questions added yet.</p>}
                {f.customQuestions.map((q, i) => (
                  <div key={q.id} style={{ display:'flex', gap:8, marginBottom:10, alignItems:'flex-start' }}>
                    <span style={{ width:24, height:36, display:'flex', alignItems:'center', justifyContent:'center', fontSize:11, fontWeight:700, color:C.textMuted, flexShrink:0 }}>{i+1}.</span>
                    <input value={q.label} onChange={e=>updateQuestion(q.id, { label:e.target.value })} placeholder="Question text…" style={{ ...inputStyle(), flex:1 }} />
                    <label style={{ display:'flex', alignItems:'center', gap:5, fontSize:12, color:C.textSecondary, fontWeight:600, padding:'0 4px', whiteSpace:'nowrap', height:36 }}>
                      <input type="checkbox" checked={q.required} onChange={e=>updateQuestion(q.id, { required:e.target.checked })} /> Required
                    </label>
                    <button onClick={() => removeQuestion(q.id)} style={{ background:'none', border:`1.5px solid ${C.border}`, borderRadius:7, cursor:'pointer', color:C.textMuted, height:36, width:36, fontSize:16, fontFamily:'inherit' }}>×</button>
                  </div>
                ))}
                <Btn variant="secondary" size="sm" onClick={addQuestion}><SvgIcon d={ICON.plus} size={12} /> Add question</Btn>
              </BuilderSection>

              <BuilderSection title="Consent statement" num={5} subtitle="The exact wording above the parent's signature.">
                <textarea value={f.consentText} onChange={e=>set('consentText', e.target.value)} rows={3} style={{ ...inputStyle(), resize:'vertical' }} />
              </BuilderSection>
            </div>

            {/* Right column — sticky sidebar */}
            <div style={{ position:mobile?'static':'sticky', top:0, display:'flex', flexDirection:'column', gap:16 }}>
              <Card>
                <p style={{ fontSize:12, fontWeight:700, color:C.textSecondary, textTransform:'uppercase', letterSpacing:'0.5px', marginBottom:12 }}>Deadline</p>
                <Field label="Parents must respond by">
                  <input type="date" value={f.deadline} onChange={e=>set('deadline', e.target.value)} style={inputStyle()} />
                </Field>
                <p style={{ fontSize:11, color:C.textMuted, marginTop:8, lineHeight:1.5 }}>After this date the slip moves to the Inactive list and parents can no longer respond.</p>
              </Card>

              <Card padding={0}>
                <div style={{ padding:'14px 16px', borderBottom:`1px solid ${C.border}` }}>
                  <p style={{ fontSize:12, fontWeight:700, color:C.textSecondary, textTransform:'uppercase', letterSpacing:'0.5px' }}>Recipients · {f.studentIds.length}/{STUDENTS.length}</p>
                </div>
                <div style={{ maxHeight:260, overflowY:'auto' }}>
                  {STUDENTS.map((s, i) => {
                    const on = f.studentIds.includes(s.id);
                    return (
                      <label key={s.id} style={{ display:'flex', alignItems:'center', gap:10, padding:'8px 16px', borderBottom:i<STUDENTS.length-1?`1px solid ${C.borderLight}`:'none', cursor:'pointer', background:on?'transparent':'#FAFBFD' }}>
                        <input type="checkbox" checked={on} onChange={()=>toggleStudent(s.id)} />
                        <Avatar initials={s.initials} size={24} color={s.color} />
                        <div style={{ flex:1, minWidth:0 }}>
                          <p style={{ fontSize:12, fontWeight:600, color:C.navy }}>{s.name}</p>
                          <p style={{ fontSize:10, color:C.textMuted }}>{s.year}</p>
                        </div>
                      </label>
                    );
                  })}
                </div>
                <div style={{ display:'flex', gap:6, padding:10, borderTop:`1px solid ${C.border}` }}>
                  <Btn variant="ghost" size="sm" onClick={()=>set('studentIds', STUDENTS.map(s=>s.id))}>All</Btn>
                  <Btn variant="ghost" size="sm" onClick={()=>set('studentIds', [])}>None</Btn>
                  <Btn variant="ghost" size="sm" onClick={()=>set('studentIds', STUDENTS.filter(s=>['Y7','Y8'].includes(s.year)).map(s=>s.id))}>Y7–8</Btn>
                </div>
              </Card>
            </div>
          </div>
        )}
      </div>
    );
  };

  const inputStyle = (fs=13, fw=400) => ({ width:'100%', padding:'9px 12px', border:`1.5px solid ${C.border}`, borderRadius:8, fontSize:fs, fontWeight:fw, fontFamily:'inherit', color:C.textPrimary, outline:'none', background:C.surface });

  const BuilderSection = ({ title, num, subtitle, children }) => (
    <Card>
      <div style={{ display:'flex', alignItems:'center', gap:10, marginBottom: subtitle ? 4 : 14 }}>
        <span style={{ width:24, height:24, borderRadius:'50%', background:C.navy, color:'#fff', fontSize:11, fontWeight:800, display:'inline-flex', alignItems:'center', justifyContent:'center' }}>{num}</span>
        <p style={{ fontSize:14, fontWeight:700, color:C.navy }}>{title}</p>
      </div>
      {subtitle && <p style={{ fontSize:11, color:C.textMuted, marginLeft:34, marginBottom:14 }}>{subtitle}</p>}
      <div style={{ display:'flex', flexDirection:'column', gap:12 }}>{children}</div>
    </Card>
  );

  const Field = ({ label, hint, children }) => (
    <div>
      <label style={{ fontSize:11, fontWeight:700, color:C.textSecondary, display:'block', marginBottom:5, textTransform:'uppercase', letterSpacing:'0.4px' }}>{label}</label>
      {children}
      {hint && <p style={{ fontSize:11, color:C.textMuted, marginTop:5 }}>{hint}</p>}
    </div>
  );

  const Toggle = ({ label, desc, value, onChange }) => (
    <button onClick={() => onChange(!value)} style={{ display:'flex', alignItems:'center', gap:14, padding:'12px 14px', background: value ? '#F0F7FF' : C.bg, border:`1.5px solid ${value ? C.blue : C.border}`, borderRadius:9, cursor:'pointer', fontFamily:'inherit', textAlign:'left', width:'100%' }}>
      <div style={{ width:38, height:22, borderRadius:11, background:value?C.blue:'#C5CDE0', position:'relative', flexShrink:0, transition:'background 0.15s' }}>
        <div style={{ width:18, height:18, borderRadius:'50%', background:'#fff', position:'absolute', top:2, left: value ? 18 : 2, transition:'left 0.15s', boxShadow:'0 1px 3px rgba(0,0,0,0.2)' }} />
      </div>
      <div style={{ flex:1, minWidth:0 }}>
        <p style={{ fontSize:13, fontWeight:700, color:C.navy }}>{label}</p>
        <p style={{ fontSize:11, color:C.textSecondary, marginTop:2 }}>{desc}</p>
      </div>
    </button>
  );

  // Preview pane inside the builder
  const BuilderPreview = ({ f }) => (
    <Card>
      <div style={{ padding:6 }}>
        <p style={{ fontSize:11, color:C.textMuted, marginBottom:10, fontWeight:700, textTransform:'uppercase', letterSpacing:'0.5px' }}>Parent preview</p>
        <ParentSlipBody slip={{ ...f, id:'PREVIEW' }} />
      </div>
    </Card>
  );

  // ─────────────────────────────────────────────────────────────────────────
  // ADMIN — Main page
  // ─────────────────────────────────────────────────────────────────────────
  const AdminPermissionSlips = ({ mobile }) => {
    const [slips, setSlips]           = useState(PERMISSION_SLIPS);
    const [archived, setArchived]     = useState(new Set());
    const [view, setView]             = useState('list');         // 'list' | 'detail' | 'builder'
    const [tab, setTab]               = useState('active');       // 'active' | 'inactive'
    const [selectedId, setSelectedId] = useState(null);
    const [builderInit, setBuilderInit] = useState(null);

    const activeSlips   = slips.filter(s => isActive(s, archived));
    const inactiveSlips = slips.filter(s => !isActive(s, archived));
    const list = tab === 'active' ? activeSlips : inactiveSlips;
    const selected = slips.find(s => s.id === selectedId);

    const handleArchive   = (id) => { setArchived(a => new Set([...a, id])); };
    const handleUnarchive = (id) => { setArchived(a => { const n = new Set(a); n.delete(id); return n; }); };
    const handleDuplicate = (slip) => {
      const { id, issued, responses, ...rest } = slip;
      setBuilderInit({ ...rest, title: slip.title + ' (Copy)' });
      setView('builder');
    };
    const handleSave = (f) => {
      const newSlip = {
        ...f,
        id: 'PS-' + String(Date.now()).slice(-4),
        issued: TODAY_STR,
        issuedBy: 'Mrs Thompson',
        responses: Object.fromEntries(f.studentIds.map(id => [id, { status:'pending' }])),
      };
      setSlips(s => [newSlip, ...s]);
      setView('list');
      setBuilderInit(null);
    };

    // Aggregate stats across all active slips
    const stats = activeSlips.reduce((acc, s) => {
      const t = tallyResponses(s);
      acc.totalRecipients += t.total;
      acc.signed          += t.signed;
      acc.pending         += t.pending;
      acc.declined        += t.declined;
      return acc;
    }, { totalRecipients:0, signed:0, pending:0, declined:0 });

    // ── Routes ──
    if (view === 'builder') {
      return <AdminBuilder initial={builderInit} onCancel={() => { setView('list'); setBuilderInit(null); }} onSave={handleSave} mobile={mobile} />;
    }
    if (view === 'detail' && selected) {
      return <AdminSlipDetail
        slip={selected}
        archived={archived.has(selected.id)}
        onBack={() => { setView('list'); setSelectedId(null); }}
        onArchive={() => handleArchive(selected.id)}
        onUnarchive={() => handleUnarchive(selected.id)}
        onDuplicate={() => handleDuplicate(selected)}
        mobile={mobile}
      />;
    }

    // ── List view ──
    return (
      <div className="page-fade">
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:20, flexWrap:'wrap', gap:12 }}>
          <div>
            <h2 style={{ fontSize:mobile?20:26, fontWeight:800, color:C.navy }}>Permission Slips</h2>
            <p style={{ fontSize:13, color:C.textSecondary, marginTop:4 }}>Compose, send and track consent forms for trips and activities.</p>
          </div>
          <Btn variant="primary" onClick={() => { setBuilderInit(null); setView('builder'); }}><SvgIcon d={ICON.plus} size={14} /> New permission slip</Btn>
        </div>

        {/* Aggregate stats */}
        <div style={{ display:'grid', gridTemplateColumns:mobile?'1fr 1fr':'repeat(4,1fr)', gap:12, marginBottom:20 }}>
          <StatCard label="Active slips"        value={activeSlips.length}            sub={`${inactiveSlips.length} inactive`}     accent={C.blue}    />
          <StatCard label="Signatures pending"  value={stats.pending}                  sub="awaiting parent response"               accent={C.warning} />
          <StatCard label="Signatures received" value={stats.signed}                   sub={`${stats.totalRecipients ? Math.round(stats.signed/stats.totalRecipients*100) : 0}% of active recipients`} accent={C.success} />
          <StatCard label="Declined"            value={stats.declined}                 sub="across active slips"                    accent={C.danger}  />
        </div>

        {/* Tabs */}
        <div style={{ display:'flex', gap:4, marginBottom:16, background:C.bg, borderRadius:10, padding:4, width:'fit-content' }}>
          {[['active', `Active · ${activeSlips.length}`], ['inactive', `Inactive · ${inactiveSlips.length}`]].map(([id, l]) => (
            <button key={id} onClick={() => setTab(id)} style={{ padding:'9px 18px', borderRadius:7, border:'none', background:tab===id?C.navy:'transparent', color:tab===id?'#fff':C.textSecondary, fontWeight:700, fontSize:13, cursor:'pointer', fontFamily:'inherit' }}>{l}</button>
          ))}
        </div>

        {tab === 'inactive' && (
          <div style={{ padding:'10px 14px', background:C.bg, border:`1px solid ${C.border}`, borderRadius:8, marginBottom:14, fontSize:12, color:C.textSecondary, lineHeight:1.6 }}>
            Slips appear here once their deadline has passed <em>or</em> when manually archived. Past responses remain visible for records.
          </div>
        )}

        <div style={{ display:'flex', flexDirection:'column', gap:12 }}>
          {list.length === 0
            ? <Card><p style={{ textAlign:'center', color:C.textMuted, fontSize:13, padding:'24px 0' }}>No {tab} slips.</p></Card>
            : list.map(s => <AdminSlipCard key={s.id} slip={s} archived={archived.has(s.id)} onOpen={() => { setSelectedId(s.id); setView('detail'); }} />)
          }
        </div>
      </div>
    );
  };

  // ─────────────────────────────────────────────────────────────────────────
  // PARENT — Slip body (read-only preview, used both in parent-view and builder)
  // ─────────────────────────────────────────────────────────────────────────
  const ParentSlipBody = ({ slip }) => {
    const cat = categoryStyle(slip.category);
    return (
      <div>
        <div style={{ display:'flex', gap:8, marginBottom:10, flexWrap:'wrap' }}>
          <span style={{ display:'inline-flex', padding:'3px 9px', borderRadius:5, fontSize:10, fontWeight:700, background:cat.bg, color:cat.fg, textTransform:'uppercase', letterSpacing:'0.5px' }}>{slip.category}</span>
        </div>
        <h2 style={{ fontSize:22, fontWeight:800, color:C.navy, marginBottom:6, lineHeight:1.25 }}>{slip.title || 'Untitled slip'}</h2>
        <p style={{ fontSize:13, color:C.textSecondary, marginBottom:18 }}>
          Respond by <strong style={{ color:C.crimson }}>{fmtDate(slip.deadline)}</strong>
          {slip.issuedBy && ` · Issued by ${slip.issuedBy}`}
        </p>

        {(slip.eventDate || slip.location || slip.cost || slip.transport || slip.departureTime || slip.returnTime) && (
          <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit, minmax(150px, 1fr))', gap:12, padding:'16px', background:C.bg, borderRadius:12, marginBottom:18 }}>
            {slip.eventDate     && <Detail icon={ICON.calendar} label="Event date"   value={fmtDate(slip.eventDate)} />}
            {slip.departureTime && <Detail icon={ICON.clock}    label="Departure"    value={slip.departureTime} />}
            {slip.returnTime    && <Detail icon={ICON.clock}    label="Return"       value={slip.returnTime} />}
            {slip.location      && <Detail icon={ICON.pin}      label="Location"     value={slip.location} />}
            {slip.transport     && <Detail icon={ICON.bus}      label="Transport"    value={slip.transport} />}
            {slip.cost          && <Detail icon={ICON.coin}     label="Cost"         value={slip.cost} />}
          </div>
        )}

        {slip.description && (
          <div style={{ marginBottom:18 }}>
            <p style={{ fontSize:11, fontWeight:700, color:C.textSecondary, textTransform:'uppercase', letterSpacing:'0.5px', marginBottom:8 }}>About this {slip.category?.toLowerCase() || 'form'}</p>
            <p style={{ fontSize:14, color:C.textPrimary, lineHeight:1.7 }}>{slip.description}</p>
          </div>
        )}

        {slip.whatToBring && slip.whatToBring.length > 0 && (
          <div style={{ marginBottom:18 }}>
            <p style={{ fontSize:11, fontWeight:700, color:C.textSecondary, textTransform:'uppercase', letterSpacing:'0.5px', marginBottom:8 }}>What to bring</p>
            <div style={{ display:'flex', flexDirection:'column', gap:6 }}>
              {slip.whatToBring.map((b,i) => (
                <div key={i} style={{ display:'flex', alignItems:'center', gap:10, padding:'8px 12px', background:'#FAFBFD', border:`1px solid ${C.borderLight}`, borderRadius:7 }}>
                  <div style={{ width:18, height:18, borderRadius:4, border:`2px solid ${C.border}`, flexShrink:0 }} />
                  <span style={{ fontSize:13, color:C.textPrimary }}>{b}</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    );
  };

  // ─────────────────────────────────────────────────────────────────────────
  // PARENT — Slip sign view
  // ─────────────────────────────────────────────────────────────────────────
  const ParentSlipSign = ({ slip, child, onBack, onSubmit, mobile }) => {
    const [decision,  setDecision]  = useState(null);            // 'sign' | 'decline'
    const [parentName, setParentName] = useState('');
    const [medical,   setMedical]   = useState('');
    const [emergency, setEmergency] = useState('');
    const [reason,    setReason]    = useState('');
    const [customAnswers, setCustomAnswers] = useState({});
    const [agreed,    setAgreed]    = useState(false);
    const [submitted, setSubmitted] = useState(false);

    const canSubmit = decision &&
      parentName.trim() &&
      (decision === 'sign' ? agreed && (!slip.requireMedical || medical.trim()) && (!slip.requireEmergencyContact || emergency.trim()) : true) &&
      (slip.customQuestions || []).every(q => !q.required || (customAnswers[q.id] || '').trim());

    const submit = () => {
      setSubmitted(true);
      setTimeout(() => onSubmit({ decision, parentName, medical, emergency, reason, customAnswers }), 1400);
    };

    if (submitted) {
      return (
        <div className="page-fade" style={{ maxWidth:600, margin:'40px auto', textAlign:'center' }}>
          <div style={{ width:80, height:80, margin:'0 auto 20px', borderRadius:'50%', background:decision==='sign'?C.successBg:C.bg, display:'flex', alignItems:'center', justifyContent:'center' }}>
            <SvgIcon d={decision==='sign'?ICON.check:ICON.x} size={40} color={decision==='sign'?C.success:C.textSecondary} stroke={2.4} />
          </div>
          <h2 style={{ fontSize:24, fontWeight:800, color:C.navy, marginBottom:8 }}>{decision==='sign' ? 'Permission granted' : 'Response recorded'}</h2>
          <p style={{ fontSize:14, color:C.textSecondary }}>
            {decision==='sign'
              ? `Thank you, ${parentName}. Your e-signature has been recorded for ${child.name}.`
              : `Thank you, ${parentName}. ${child.name} will not take part.`}
          </p>
          <p style={{ fontSize:12, color:C.textMuted, marginTop:12 }}>A copy has been emailed to you.</p>
        </div>
      );
    }

    return (
      <div className="page-fade" style={{ maxWidth:780, margin:'0 auto' }}>
        <button onClick={onBack} style={{ display:'flex', alignItems:'center', gap:6, background:'none', border:'none', color:C.blue, fontWeight:600, fontSize:13, cursor:'pointer', marginBottom:16, fontFamily:'inherit' }}>← Back to Permission Slips</button>

        {/* Read-only preview */}
        <Card style={{ marginBottom:16 }}>
          <ParentSlipBody slip={slip} />

          {slip.consentText && (
            <div style={{ padding:'14px 16px', background:'#FFF8F0', border:`1.5px solid #F0DCC0`, borderRadius:10, marginTop:8 }}>
              <p style={{ fontSize:11, fontWeight:700, color:'#9C5A2F', textTransform:'uppercase', letterSpacing:'0.5px', marginBottom:6 }}>Consent statement</p>
              <p style={{ fontSize:13, color:'#4F3415', lineHeight:1.7, fontStyle:'italic' }}>"{slip.consentText}"</p>
            </div>
          )}
        </Card>

        {/* Sign form */}
        <Card>
          <div style={{ marginBottom:18 }}>
            <p style={{ fontSize:11, fontWeight:700, color:C.textSecondary, textTransform:'uppercase', letterSpacing:'0.5px', marginBottom:8 }}>Signing for</p>
            <div style={{ display:'flex', alignItems:'center', gap:12, padding:'10px 14px', background:C.bg, borderRadius:9 }}>
              <Avatar initials={child.initials} size={36} color={child.color} />
              <div>
                <p style={{ fontSize:14, fontWeight:700, color:C.navy }}>{child.name}</p>
                <p style={{ fontSize:11, color:C.textSecondary }}>{child.year} · Supervisor: {child.tutor}</p>
              </div>
            </div>
          </div>

          {/* Decision */}
          <p style={{ fontSize:11, fontWeight:700, color:C.textSecondary, textTransform:'uppercase', letterSpacing:'0.5px', marginBottom:8 }}>Your decision</p>
          <div style={{ display:'grid', gridTemplateColumns:mobile?'1fr':'1fr 1fr', gap:10, marginBottom:18 }}>
            <DecisionCard active={decision==='sign'}    color={C.success} onClick={()=>setDecision('sign')}    label="Give permission"     desc={`Yes — ${child.name.split(' ')[0]} will take part`} />
            <DecisionCard active={decision==='decline'} color={C.danger}  onClick={()=>setDecision('decline')} label="Decline permission"  desc={`No — ${child.name.split(' ')[0]} will not take part`} />
          </div>

          {decision && (
            <>
              {decision === 'sign' && slip.requireMedical && (
                <Field label="Medical / allergy info *">
                  <textarea value={medical} onChange={e=>setMedical(e.target.value)} rows={2} placeholder="Any medications, allergies or medical conditions staff should know about. Type 'None' if not applicable." style={{ ...inputStyle(), resize:'vertical' }} />
                </Field>
              )}
              {decision === 'sign' && slip.requireEmergencyContact && (
                <div style={{ marginTop:12 }}>
                  <Field label="Emergency contact *" hint="Format: Name · Phone · Relationship">
                    <input value={emergency} onChange={e=>setEmergency(e.target.value)} placeholder="e.g. Sarah Johnson · 07700 902222 · Mother" style={inputStyle()} />
                  </Field>
                </div>
              )}
              {decision === 'decline' && (
                <div style={{ marginTop:12 }}>
                  <Field label="Reason (optional)" hint="Helps us understand and follow up sensitively.">
                    <textarea value={reason} onChange={e=>setReason(e.target.value)} rows={2} placeholder="e.g. Family commitment that day" style={{ ...inputStyle(), resize:'vertical' }} />
                  </Field>
                </div>
              )}

              {decision === 'sign' && (slip.customQuestions || []).length > 0 && (
                <div style={{ marginTop:12, display:'flex', flexDirection:'column', gap:12 }}>
                  {slip.customQuestions.map(q => (
                    <Field key={q.id} label={`${q.label || 'Question'}${q.required?' *':''}`}>
                      <input value={customAnswers[q.id] || ''} onChange={e=>setCustomAnswers(a => ({ ...a, [q.id]: e.target.value }))} style={inputStyle()} />
                    </Field>
                  ))}
                </div>
              )}

              {/* Signature */}
              <div style={{ marginTop:18, paddingTop:18, borderTop:`1px solid ${C.border}` }}>
                <Field label="Your full name *" hint="Typing your name acts as your e-signature.">
                  <input value={parentName} onChange={e=>setParentName(e.target.value)} placeholder="e.g. Robert Johnson"
                    style={{ ...inputStyle(20, 600), fontFamily:'"Plus Jakarta Sans", cursive', fontStyle:'italic', letterSpacing:'0.5px', color:C.navy }} />
                </Field>
                {parentName.trim() && decision === 'sign' && (
                  <div style={{ marginTop:12, padding:'14px 16px', background:'#F7FAF7', border:`1.5px solid ${C.successMid}`, borderRadius:9 }}>
                    <p style={{ fontSize:11, color:C.textMuted, marginBottom:6 }}>Preview of signed name</p>
                    <p style={{ fontFamily:'"Plus Jakarta Sans", cursive', fontStyle:'italic', fontSize:24, fontWeight:600, color:C.navy, letterSpacing:'0.5px' }}>{parentName}</p>
                    <p style={{ fontSize:11, color:C.textMuted, marginTop:6 }}>Signed on {fmtDate(TODAY_STR)} · IP recorded · Will appear on the slip record</p>
                  </div>
                )}
              </div>

              {decision === 'sign' && (
                <label style={{ display:'flex', alignItems:'flex-start', gap:10, marginTop:16, padding:'12px 14px', background:agreed?'#F0F7FF':C.bg, border:`1.5px solid ${agreed?C.blue:C.border}`, borderRadius:9, cursor:'pointer' }}>
                  <input type="checkbox" checked={agreed} onChange={e=>setAgreed(e.target.checked)} style={{ marginTop:3 }} />
                  <span style={{ fontSize:13, color:C.textPrimary, lineHeight:1.6 }}>I confirm I have read the consent statement above and agree on behalf of <strong>{child.name}</strong>.</span>
                </label>
              )}

              <div style={{ display:'flex', gap:10, marginTop:20 }}>
                <Btn variant="secondary" onClick={onBack} style={{ flex:1, justifyContent:'center' }}>Cancel</Btn>
                <Btn variant={decision==='decline'?'navy':'primary'} disabled={!canSubmit} onClick={submit} style={{ flex:2, justifyContent:'center' }}>
                  {decision==='sign' ? 'Submit signed slip' : 'Submit decline'}
                </Btn>
              </div>
            </>
          )}
        </Card>
      </div>
    );
  };

  const DecisionCard = ({ active, color, onClick, label, desc }) => (
    <button onClick={onClick} style={{ padding:'14px 16px', background:active?'#fff':C.bg, border:`2px solid ${active?color:C.border}`, borderRadius:10, textAlign:'left', cursor:'pointer', fontFamily:'inherit', boxShadow:active?`0 0 0 3px ${color}22`:'none', transition:'all 0.15s' }}>
      <div style={{ display:'flex', alignItems:'center', gap:10, marginBottom:4 }}>
        <div style={{ width:18, height:18, borderRadius:'50%', border:`2px solid ${active?color:C.border}`, background:active?color:'transparent', display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0 }}>
          {active && <div style={{ width:6, height:6, borderRadius:'50%', background:'#fff' }} />}
        </div>
        <p style={{ fontSize:14, fontWeight:700, color:active?color:C.navy }}>{label}</p>
      </div>
      <p style={{ fontSize:12, color:C.textSecondary, marginLeft:28 }}>{desc}</p>
    </button>
  );

  // ─────────────────────────────────────────────────────────────────────────
  // PARENT — List page
  // ─────────────────────────────────────────────────────────────────────────
  const ParentPermissionSlips = ({ mobile }) => {
    const child = MY_CHILD;
    const [slips, setSlips]   = useState(PERMISSION_SLIPS);
    const [tab, setTab]       = useState('outstanding');
    const [selectedId, setSelectedId] = useState(null);

    // Show only slips that include this child
    const mySlips = useMemo(() => slips.filter(s => s.studentIds.includes(child.id)), [slips, child.id]);

    const outstandingSlips = mySlips.filter(s => {
      const r = s.responses[child.id];
      return (!r || r.status === 'pending') && daysUntil(s.deadline) >= 0;
    });
    const completedSlips = mySlips.filter(s => {
      const r = s.responses[child.id];
      return (r && r.status !== 'pending') || daysUntil(s.deadline) < 0;
    });
    const list = tab === 'outstanding' ? outstandingSlips : completedSlips;

    const selected = slips.find(s => s.id === selectedId);

    const submitResponse = (data) => {
      setSlips(curr => curr.map(s => s.id !== selectedId ? s : ({
        ...s,
        responses: {
          ...s.responses,
          [child.id]: {
            status: data.decision === 'sign' ? 'signed' : 'declined',
            parentName: data.parentName,
            signedAt: fmtDate(TODAY_STR) + ' · just now',
            medicalInfo: data.medical || undefined,
            emergency: data.emergency || undefined,
            declineReason: data.reason || undefined,
          }
        }
      })));
      setSelectedId(null);
    };

    if (selected) {
      return <ParentSlipSign slip={selected} child={child} onBack={() => setSelectedId(null)} onSubmit={submitResponse} mobile={mobile} />;
    }

    return (
      <div className="page-fade">
        <div style={{ marginBottom:20 }}>
          <h2 style={{ fontSize:mobile?20:26, fontWeight:800, color:C.navy }}>Permission Slips</h2>
          <p style={{ fontSize:13, color:C.textSecondary, marginTop:4 }}>Sign or decline consent forms for {child.name.split(' ')[0]}'s trips and activities.</p>
        </div>

        {/* Tabs */}
        <div style={{ display:'flex', gap:4, marginBottom:16, background:C.bg, borderRadius:10, padding:4, width:'fit-content' }}>
          {[['outstanding', `Outstanding · ${outstandingSlips.length}`], ['completed', `Completed · ${completedSlips.length}`]].map(([id, l]) => (
            <button key={id} onClick={() => setTab(id)} style={{ padding:'9px 18px', borderRadius:7, border:'none', background:tab===id?C.crimson:'transparent', color:tab===id?'#fff':C.textSecondary, fontWeight:700, fontSize:13, cursor:'pointer', fontFamily:'inherit' }}>{l}</button>
          ))}
        </div>

        <div style={{ display:'flex', flexDirection:'column', gap:12 }}>
          {list.length === 0
            ? <Card><p style={{ textAlign:'center', color:C.textMuted, fontSize:13, padding:'24px 0' }}>{tab === 'outstanding' ? '🎉 You\'re all caught up — nothing waiting for you.' : 'No completed slips yet.'}</p></Card>
            : list.map(s => <ParentSlipCard key={s.id} slip={s} response={s.responses[child.id]} onOpen={() => setSelectedId(s.id)} mobile={mobile} />)
          }
        </div>
      </div>
    );
  };

  const ParentSlipCard = ({ slip, response, onOpen, mobile }) => {
    const cat = categoryStyle(slip.category);
    const days = daysUntil(slip.deadline);
    const status = response?.status || 'pending';
    const isClosed = days < 0 && status === 'pending';
    const ribbonColor = status === 'signed' ? C.success : status === 'declined' ? C.danger : isClosed ? C.textMuted : days <= 3 ? C.crimson : C.blue;

    return (
      <Card style={{ padding:0, overflow:'hidden', cursor: isClosed ? 'default' : 'pointer', borderLeft: `4px solid ${ribbonColor}` }}>
        <div onClick={() => !isClosed && onOpen()}
          onMouseEnter={e => !isClosed && (e.currentTarget.style.background = '#FAFBFD')}
          onMouseLeave={e => (e.currentTarget.style.background = '')}
          style={{ padding:'16px 18px', transition:'background 0.15s' }}>

          <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', gap:12, marginBottom:8, flexWrap:'wrap' }}>
            <div style={{ flex:1, minWidth:0 }}>
              <div style={{ display:'flex', gap:6, alignItems:'center', marginBottom:6, flexWrap:'wrap' }}>
                <span style={{ display:'inline-flex', padding:'3px 9px', borderRadius:5, fontSize:10, fontWeight:700, background:cat.bg, color:cat.fg, textTransform:'uppercase', letterSpacing:'0.5px' }}>{slip.category}</span>
                {status === 'signed'   && <Badge variant="green">✓ Signed {response.signedAt && `· ${response.signedAt.split(' ').slice(0,3).join(' ')}`}</Badge>}
                {status === 'declined' && <Badge variant="red">✗ Declined</Badge>}
                {status === 'pending'  && !isClosed && <DeadlinePill iso={slip.deadline} />}
                {isClosed && <Badge variant="grey">Closed · no response</Badge>}
              </div>
              <p style={{ fontSize:16, fontWeight:800, color:C.navy }}>{slip.title}</p>
              <p style={{ fontSize:12, color:C.textSecondary, marginTop:3 }}>
                {slip.eventDate && `Event ${fmtDate(slip.eventDate)} · `}
                Respond by {fmtDateShort(slip.deadline)}
                {slip.cost && ` · ${slip.cost}`}
              </p>
            </div>
            {!isClosed && status === 'pending' && (
              <Btn variant="primary" size="sm">Open & sign</Btn>
            )}
            {(status !== 'pending' || isClosed) && (
              <button onClick={() => onOpen()} style={{ background:'none', border:'none', color:C.textMuted, cursor:'pointer', fontFamily:'inherit', fontSize:12, fontWeight:600 }}>View →</button>
            )}
          </div>
        </div>
      </Card>
    );
  };

  // Expose to portals
  Object.assign(window, { AdminPermissionSlips, ParentPermissionSlips });
})();
