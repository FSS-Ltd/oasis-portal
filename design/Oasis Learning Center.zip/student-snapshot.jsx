// student-snapshot.jsx — Supervisor Student Progress Snapshot

// ── Rich per-student timeline data ──────────────────────────────────────────
// Each entry has a date (YYYY-MM-DD), type, and detail.
// "today" = 2026-04-30, "yesterday" = 2026-04-29
const SNAPSHOT_DATA = {
  // Joshua Johnson (id 1)
  1: {
    attendance: [
      { date:'2026-04-30', status:'Present' },
      { date:'2026-04-29', status:'Present' },
      { date:'2026-04-28', status:'Present' },
      { date:'2026-04-25', status:'Present' },
      { date:'2026-04-24', status:'Late',    note:'Arrived 9:22 — parent notified' },
      { date:'2026-04-23', status:'Present' },
      { date:'2026-04-22', status:'Present' },
      { date:'2026-04-15', status:'Absent',  note:'Sick leave — parent called' },
    ],
    behaviour: [
      { date:'2026-04-30', type:'Merit',   delta:+5,  category:'Helpfulness',         note:'Helped set up the science lab before class without being asked. Showed real initiative.', by:'Mrs Thompson' },
      { date:'2026-04-30', type:'Merit',   delta:+10, category:'Scripture Memory',     note:'Recited Proverbs 3:5-6 perfectly from memory during morning assembly.', by:'Mrs Thompson' },
      { date:'2026-04-29', type:'Merit',   delta:+5,  category:'Character',            note:'Patiently supported a younger student who was struggling with their PACE worksheet.', by:'Mr Osei' },
      { date:'2026-04-28', type:'Demerit', delta:-5,  category:'Punctuality',          note:'Late returning from lunch break — second occurrence this week.', by:'Mrs Thompson' },
      { date:'2026-04-25', type:'Merit',   delta:+15, category:'Academic Excellence',  note:'Outstanding score on Mathematics PACE 1097 self-test — 96%.', by:'Mrs Thompson' },
      { date:'2026-04-24', type:'Merit',   delta:+5,  category:'Helpfulness',          note:'Volunteered to tidy the classroom at end of day.', by:'Mr Osei' },
      { date:'2026-04-23', type:'Demerit', delta:-5,  category:'Conduct',              note:'Talking during silent study period despite two verbal reminders.', by:'Mrs Thompson' },
      { date:'2026-04-22', type:'Merit',   delta:+10, category:'Leadership',           note:'Led morning devotional reading with confidence and clarity.', by:'Mr Osei' },
      { date:'2026-04-17', type:'Merit',   delta:+5,  category:'Character',            note:'Showed kindness and encouragement to a peer who was upset.', by:'Mrs Thompson' },
      { date:'2026-04-15', type:'Merit',   delta:+10, category:'Scripture Memory',     note:'Memorised full passage of John 3:16-17.', by:'Mrs Thompson' },
    ],
    paceScores: [
      { date:'2026-04-30', subject:'Mathematics',    paceNumber:1097, type:'Self-Test', score:96, maxScore:100, supervisor:'Mrs Thompson' },
      { date:'2026-04-29', subject:'English',        paceNumber:1089, type:'PACE Test', score:88, maxScore:100, supervisor:'Mrs Thompson' },
      { date:'2026-04-28', subject:'Bible',          paceNumber:1094, type:'Self-Test', score:100,maxScore:100, supervisor:'Mr Osei' },
      { date:'2026-04-25', subject:'Science',        paceNumber:1086, type:'PACE Test', score:79, maxScore:100, supervisor:'Mrs Thompson' },
      { date:'2026-04-23', subject:'Social Studies', paceNumber:1091, type:'Self-Test', score:85, maxScore:100, supervisor:'Mr Osei' },
      { date:'2026-04-22', subject:'Mathematics',    paceNumber:1096, type:'PACE Test', score:91, maxScore:100, supervisor:'Mrs Thompson' },
      { date:'2026-04-17', subject:'English',        paceNumber:1088, type:'Self-Test', score:94, maxScore:100, supervisor:'Mrs Thompson' },
      { date:'2026-04-15', subject:'Bible',          paceNumber:1093, type:'PACE Test', score:98, maxScore:100, supervisor:'Mr Osei' },
    ],
    supervisorNotes: [
      { date:'2026-04-30', note:'Joshua is performing very well this week. His scripture memory is excellent and he has a positive influence on others around him.', by:'Mrs Thompson' },
      { date:'2026-04-28', note:'Slight concern about punctuality after lunch — had a quiet word with him. He was receptive and apologetic.', by:'Mrs Thompson' },
      { date:'2026-04-22', note:'A wonderful student this week. Led devotional reading with real confidence. Parents should be very proud.', by:'Mr Osei' },
      { date:'2026-04-15', note:'Joshua was absent today. Mum called to say he had a temperature. Work sent home digitally.', by:'Mrs Thompson' },
    ],
  },

  // Grace Williams (id 2)
  2: {
    attendance: [
      { date:'2026-04-30', status:'Present' },
      { date:'2026-04-29', status:'Present' },
      { date:'2026-04-28', status:'Present' },
      { date:'2026-04-25', status:'Present' },
      { date:'2026-04-24', status:'Present' },
      { date:'2026-04-23', status:'Present' },
    ],
    behaviour: [
      { date:'2026-04-30', type:'Merit',   delta:+10, category:'Scripture Memory',    note:'Memorised Psalm 23 in full, word-perfect recitation during assembly.', by:'Mrs Thompson' },
      { date:'2026-04-29', type:'Merit',   delta:+15, category:'Academic Excellence', note:'Scored 97% on English PACE 1090 — highest in the class.', by:'Mrs Thompson' },
      { date:'2026-04-28', type:'Merit',   delta:+10, category:'Leadership',          note:'Organised and led a small group study session for younger students.', by:'Mr Osei' },
      { date:'2026-04-25', type:'Merit',   delta:+5,  category:'Character',           note:'Noticed a classmate was distressed and alerted a supervisor quietly.', by:'Mrs Thompson' },
      { date:'2026-04-22', type:'Merit',   delta:+10, category:'Scripture Memory',    note:'Recited all of Romans 8:28 perfectly.', by:'Mr Osei' },
    ],
    paceScores: [
      { date:'2026-04-30', subject:'English',        paceNumber:1090, type:'PACE Test', score:97, maxScore:100, supervisor:'Mrs Thompson' },
      { date:'2026-04-29', subject:'Mathematics',    paceNumber:1098, type:'Self-Test', score:94, maxScore:100, supervisor:'Mrs Thompson' },
      { date:'2026-04-28', subject:'Bible',          paceNumber:1095, type:'PACE Test', score:100,maxScore:100, supervisor:'Mr Osei' },
      { date:'2026-04-25', subject:'Science',        paceNumber:1087, type:'Self-Test', score:88, maxScore:100, supervisor:'Mrs Thompson' },
    ],
    supervisorNotes: [
      { date:'2026-04-30', note:'Grace is an exceptional student. She leads by example and her academic results speak for themselves. A genuine joy to supervise.', by:'Mrs Thompson' },
      { date:'2026-04-25', note:'Grace showed real emotional maturity today — quietly and appropriately flagged a concern about a classmate without making a fuss.', by:'Mrs Thompson' },
    ],
  },

  // Samuel Okafor (id 3)
  3: {
    attendance: [
      { date:'2026-04-30', status:'Absent', note:'No contact from parent — follow up required' },
      { date:'2026-04-29', status:'Present' },
      { date:'2026-04-28', status:'Late',   note:'Arrived 9:45 — no prior notice' },
      { date:'2026-04-25', status:'Present' },
      { date:'2026-04-24', status:'Absent', note:'Parent texted — hospital appointment' },
      { date:'2026-04-23', status:'Present' },
    ],
    behaviour: [
      { date:'2026-04-29', type:'Demerit', delta:-5,  category:'Conduct',     note:'Disruptive during silent study — repeatedly distracting nearby students.', by:'Mr Osei' },
      { date:'2026-04-28', type:'Merit',   delta:+5,  category:'Helpfulness', note:'Helped carry materials in from storage without being asked.', by:'Mrs Thompson' },
      { date:'2026-04-25', type:'Demerit', delta:-5,  category:'Punctuality', note:'Late returning from morning break.', by:'Mr Osei' },
      { date:'2026-04-23', type:'Merit',   delta:+5,  category:'Character',   note:'Apologised sincerely to a classmate he had upset the previous day.', by:'Mrs Thompson' },
    ],
    paceScores: [
      { date:'2026-04-29', subject:'Mathematics',    paceNumber:1085, type:'Self-Test', score:71, maxScore:100, supervisor:'Mr Osei' },
      { date:'2026-04-25', subject:'English',        paceNumber:1080, type:'PACE Test', score:68, maxScore:100, supervisor:'Mrs Thompson' },
      { date:'2026-04-23', subject:'Bible',          paceNumber:1082, type:'Self-Test', score:80, maxScore:100, supervisor:'Mr Osei' },
    ],
    supervisorNotes: [
      { date:'2026-04-30', note:'Samuel absent today with no contact. Will try to reach parent by phone before end of day.', by:'Mr Osei' },
      { date:'2026-04-29', note:'Difficult day for Samuel — two behaviour issues. Had a supportive conversation with him at end of day. He is struggling to focus and seems distracted. May be worth a pastoral check-in.', by:'Mr Osei' },
      { date:'2026-04-23', note:'Samuel showed good character today by apologising unprompted. Encouraged him to channel that positivity into his academic work.', by:'Mrs Thompson' },
    ],
  },

  // Stubs for other students
  4: {
    attendance: [
      { date:'2026-04-30', status:'Present' },{ date:'2026-04-29', status:'Present' },
      { date:'2026-04-28', status:'Present' },{ date:'2026-04-25', status:'Late', note:'Parent messaged ahead' },
    ],
    behaviour: [
      { date:'2026-04-30', type:'Merit', delta:+10, category:'Character',           note:'Displayed exceptional kindness and patience with a peer during group work.', by:'Mrs Thompson' },
      { date:'2026-04-29', type:'Merit', delta:+5,  category:'Scripture Memory',    note:'Memorised Philippians 4:13 perfectly.', by:'Mrs Thompson' },
      { date:'2026-04-25', type:'Merit', delta:+10, category:'Academic Excellence', note:'Scored 93% on Science PACE 1090 self-test.', by:'Mr Osei' },
    ],
    paceScores: [
      { date:'2026-04-30', subject:'Science',     paceNumber:1090, type:'Self-Test', score:93, maxScore:100, supervisor:'Mrs Thompson' },
      { date:'2026-04-29', subject:'Mathematics', paceNumber:1091, type:'PACE Test', score:87, maxScore:100, supervisor:'Mr Osei' },
    ],
    supervisorNotes: [
      { date:'2026-04-30', note:'Ruth is making excellent progress. Very focused and a positive presence in the room.', by:'Mrs Thompson' },
    ],
  },
  5: {
    attendance: [
      { date:'2026-04-30', status:'Late', note:'Arrived 9:18' }, { date:'2026-04-29', status:'Present' },
      { date:'2026-04-28', status:'Present' }, { date:'2026-04-25', status:'Present' },
    ],
    behaviour: [
      { date:'2026-04-30', type:'Demerit', delta:-5, category:'Punctuality', note:'Late to Morning Assembly without prior notification — third occasion this term.', by:'Mr Osei' },
      { date:'2026-04-29', type:'Merit',   delta:+5, category:'Helpfulness', note:'Assisted with tidying the workroom after afternoon session.', by:'Mrs Thompson' },
    ],
    paceScores: [
      { date:'2026-04-29', subject:'English', paceNumber:1082, type:'Self-Test', score:74, maxScore:100, supervisor:'Mrs Thompson' },
    ],
    supervisorNotes: [
      { date:'2026-04-30', note:'Daniel\'s punctuality remains a concern — third late arrival this term. Will raise with Head of Centre. Academically progressing but inconsistently.', by:'Mr Osei' },
    ],
  },
};
// Fill remaining students with minimal data
[6,7,8,9,10].forEach(id => {
  SNAPSHOT_DATA[id] = {
    attendance: [
      { date:'2026-04-30', status:'Present' }, { date:'2026-04-29', status:'Present' },
      { date:'2026-04-28', status:'Present' }, { date:'2026-04-25', status:'Present' },
    ],
    behaviour: [
      { date:'2026-04-30', type:'Merit', delta:+5, category:'Character', note:'Positive contribution in morning circle time.', by:'Mrs Thompson' },
      { date:'2026-04-29', type:'Merit', delta:+10, category:'Academic Excellence', note:'Strong self-test results this week.', by:'Mr Osei' },
    ],
    paceScores: [
      { date:'2026-04-30', subject:'Mathematics', paceNumber:1090 + id, type:'Self-Test', score:80+id, maxScore:100, supervisor:'Mrs Thompson' },
      { date:'2026-04-29', subject:'English',     paceNumber:1080 + id, type:'PACE Test',  score:78+id, maxScore:100, supervisor:'Mr Osei' },
    ],
    supervisorNotes: [
      { date:'2026-04-30', note:'Performing well this week. Consistent effort and good attitude.', by:'Mrs Thompson' },
    ],
  };
});

// ── Helpers ──────────────────────────────────────────────────────────────────
const parseDate = str => new Date(str + 'T00:00:00');
const TODAY     = new Date('2026-04-30T00:00:00');
const YESTERDAY = new Date('2026-04-29T00:00:00');

const inRange = (dateStr, from, to) => {
  const d = parseDate(dateStr);
  return d >= from && d <= to;
};

const fmt = dateStr => {
  const d = parseDate(dateStr);
  return d.toLocaleDateString('en-GB', { day:'numeric', month:'short', year:'numeric' });
};

const fmtShort = dateStr => {
  const d = parseDate(dateStr);
  return d.toLocaleDateString('en-GB', { weekday:'short', day:'numeric', month:'short' });
};

const scoreColor = s => s >= 90 ? C.success : s >= 75 ? C.warning : C.danger;
const scoreBg    = s => s >= 90 ? C.successBg : s >= 75 ? C.warningBg : C.dangerBg;

// ── Mini bar chart (merit delta per day) ─────────────────────────────────────
const MeritSparkline = ({ entries }) => {
  if (!entries.length) return <p style={{ fontSize:12, color:C.textMuted }}>No data</p>;
  const byDay = {};
  entries.forEach(e => {
    if (!byDay[e.date]) byDay[e.date] = 0;
    byDay[e.date] += e.delta;
  });
  const days = Object.keys(byDay).sort().slice(-7);
  const max = Math.max(...days.map(d => Math.abs(byDay[d])), 5);
  return (
    <div style={{ display:'flex', alignItems:'flex-end', gap:4, height:48 }}>
      {days.map(d => {
        const val = byDay[d];
        const pct = Math.abs(val) / max;
        const col = val >= 0 ? C.success : C.danger;
        const bg  = val >= 0 ? C.successBg : C.dangerBg;
        return (
          <div key={d} style={{ flex:1, display:'flex', flexDirection:'column', alignItems:'center', gap:2 }}>
            <div style={{ width:'100%', height: Math.max(4, pct * 40), background:col, borderRadius:'3px 3px 0 0', minHeight:4 }} title={`${fmtShort(d)}: ${val > 0 ? '+' : ''}${val}`} />
            <span style={{ fontSize:9, color:C.textMuted, writingMode:'horizontal-tb', transform:'rotate(-35deg)', transformOrigin:'top left', whiteSpace:'nowrap', marginTop:2, marginLeft:2 }}>{fmtShort(d).slice(0,3)}</span>
          </div>
        );
      })}
    </div>
  );
};

// ── Donut ring (attendance breakdown) ────────────────────────────────────────
const AttendanceRing = ({ present, late, absent }) => {
  const total = present + late + absent || 1;
  const r = 28, cx = 36, cy = 36, stroke = 7;
  const circ = 2 * Math.PI * r;
  const pPct = present / total, lPct = late / total, aPct = absent / total;
  const pDash = pPct * circ, lDash = lPct * circ, aDash = aPct * circ;
  return (
    <svg width={72} height={72} viewBox="0 0 72 72">
      <circle cx={cx} cy={cy} r={r} fill="none" stroke={C.border} strokeWidth={stroke} />
      <circle cx={cx} cy={cy} r={r} fill="none" stroke={C.success} strokeWidth={stroke}
        strokeDasharray={`${pDash} ${circ - pDash}`} strokeDashoffset={circ * 0.25} strokeLinecap="round" />
      <circle cx={cx} cy={cy} r={r} fill="none" stroke={C.warning} strokeWidth={stroke}
        strokeDasharray={`${lDash} ${circ - lDash}`} strokeDashoffset={circ * 0.25 - pDash} strokeLinecap="round" />
      <circle cx={cx} cy={cy} r={r} fill="none" stroke={C.danger} strokeWidth={stroke}
        strokeDasharray={`${aDash} ${circ - aDash}`} strokeDashoffset={circ * 0.25 - pDash - lDash} strokeLinecap="round" />
      <text x={cx} y={cy+1} textAnchor="middle" dominantBaseline="middle" fontSize={14} fontWeight={800} fill={C.navy}>{total}</text>
      <text x={cx} y={cy+14} textAnchor="middle" dominantBaseline="middle" fontSize={9} fill={C.textMuted}>days</text>
    </svg>
  );
};

// ── Score pill ────────────────────────────────────────────────────────────────
const ScorePill = ({ score }) => (
  <span style={{ display:'inline-flex', alignItems:'center', justifyContent:'center', width:44, height:24, borderRadius:20, background:scoreBg(score), color:scoreColor(score), fontSize:12, fontWeight:800 }}>{score}%</span>
);

// ── Main Snapshot Component ───────────────────────────────────────────────────
const StudentSnapshot = ({ mobile }) => {
  const [studentId,  setStudentId]  = React.useState(1);
  const [range,      setRange]      = React.useState('yesterday'); // 'yesterday'|'week'|'custom'
  const [customFrom, setCustomFrom] = React.useState('2026-04-22');
  const [customTo,   setCustomTo]   = React.useState('2026-04-30');
  const [activeTab,  setActiveTab]  = React.useState('overview');

  const student = STUDENTS.find(s => s.id === studentId);
  const data    = SNAPSHOT_DATA[studentId] || { attendance:[], behaviour:[], paceScores:[], supervisorNotes:[] };

  // Compute date range boundaries
  const { from, to, label } = React.useMemo(() => {
    if (range === 'yesterday') return { from: YESTERDAY, to: YESTERDAY, label: 'Yesterday — Wed 29 Apr' };
    if (range === 'week') {
      const w = new Date(TODAY); w.setDate(w.getDate() - 6);
      return { from: w, to: TODAY, label: 'Last 7 days — 24–30 Apr' };
    }
    return {
      from: parseDate(customFrom),
      to:   parseDate(customTo),
      label: `${fmt(customFrom)} – ${fmt(customTo)}`,
    };
  }, [range, customFrom, customTo]);

  // Filter data to range
  const filteredAttendance = data.attendance.filter(e => inRange(e.date, from, to));
  const filteredBehaviour  = data.behaviour.filter(e  => inRange(e.date, from, to));
  const filteredPace       = data.paceScores.filter(e => inRange(e.date, from, to));
  const filteredNotes      = data.supervisorNotes.filter(e => inRange(e.date, from, to));

  const meritsEarned  = filteredBehaviour.filter(e => e.delta > 0).reduce((a,b) => a + b.delta, 0);
  const demeritsTotal = filteredBehaviour.filter(e => e.delta < 0).reduce((a,b) => a + b.delta, 0);
  const netMerits     = meritsEarned + demeritsTotal;
  const presentDays   = filteredAttendance.filter(e => e.status === 'Present').length;
  const lateDays      = filteredAttendance.filter(e => e.status === 'Late').length;
  const absentDays    = filteredAttendance.filter(e => e.status === 'Absent').length;
  const avgScore      = filteredPace.length ? Math.round(filteredPace.reduce((a,b) => a + b.score, 0) / filteredPace.length) : null;

  const tabs = ['overview', 'behaviour', 'pace', 'notes'];

  // ── Student picker carousel ─────────────────────────────────────────────
  const StudentPicker = () => (
    <div style={{ display:'flex', gap:8, overflowX:'auto', paddingBottom:4 }}>
      {STUDENTS.map(s => (
        <button key={s.id} onClick={() => { setStudentId(s.id); setActiveTab('overview'); }}
          style={{
            display:'flex', flexDirection:'column', alignItems:'center', gap:5,
            padding:'10px 12px', borderRadius:12, border:`2px solid ${studentId === s.id ? s.color : C.border}`,
            background: studentId === s.id ? s.color + '18' : C.surface,
            cursor:'pointer', flexShrink:0, transition:'all 0.15s', fontFamily:'inherit',
            minWidth: mobile ? 64 : 72,
          }}>
          <Avatar initials={s.initials} size={32} color={s.color} />
          <span style={{ fontSize:10, fontWeight:700, color: studentId === s.id ? s.color : C.textSecondary, whiteSpace:'nowrap' }}>
            {s.name.split(' ')[0]}
          </span>
          <span style={{ fontSize:9, color:C.textMuted }}>{s.year}</span>
        </button>
      ))}
    </div>
  );

  // ── Range picker ───────────────────────────────────────────────────────
  const RangePicker = () => (
    <div style={{ display:'flex', gap:8, alignItems:'center', flexWrap:'wrap' }}>
      <div style={{ display:'flex', background:C.bg, borderRadius:9, padding:3, gap:2 }}>
        {[['yesterday','Yesterday'],['week','Last 7 days'],['custom','Custom']].map(([id, lbl]) => (
          <button key={id} onClick={() => setRange(id)}
            style={{ padding:'7px 14px', borderRadius:7, border:'none', fontFamily:'inherit', fontSize:12, fontWeight:600, cursor:'pointer', transition:'all 0.15s',
              background: range === id ? C.navy : 'transparent',
              color:       range === id ? '#fff' : C.textSecondary,
            }}>{lbl}</button>
        ))}
      </div>
      {range === 'custom' && (
        <div style={{ display:'flex', gap:8, alignItems:'center', flexWrap:'wrap' }}>
          <input type="date" value={customFrom} onChange={e => setCustomFrom(e.target.value)}
            style={{ padding:'7px 10px', border:`1.5px solid ${C.border}`, borderRadius:8, fontSize:12, fontFamily:'inherit', color:C.textPrimary, background:C.surface, outline:'none' }} />
          <span style={{ fontSize:12, color:C.textMuted }}>to</span>
          <input type="date" value={customTo} onChange={e => setCustomTo(e.target.value)}
            style={{ padding:'7px 10px', border:`1.5px solid ${C.border}`, borderRadius:8, fontSize:12, fontFamily:'inherit', color:C.textPrimary, background:C.surface, outline:'none' }} />
        </div>
      )}
    </div>
  );

  // ── Overview tab ────────────────────────────────────────────────────────
  const OverviewTab = () => (
    <div style={{ display:'flex', flexDirection:'column', gap:16 }}>
      {/* Stat row */}
      <div style={{ display:'grid', gridTemplateColumns: mobile ? '1fr 1fr' : 'repeat(4,1fr)', gap:12 }}>
        {/* Attendance ring */}
        <Card style={{ display:'flex', flexDirection:'column', gap:10 }}>
          <p style={{ fontSize:11, fontWeight:700, color:C.textSecondary, textTransform:'uppercase', letterSpacing:'0.6px' }}>Attendance</p>
          <div style={{ display:'flex', alignItems:'center', gap:12 }}>
            <AttendanceRing present={presentDays} late={lateDays} absent={absentDays} />
            <div style={{ display:'flex', flexDirection:'column', gap:5 }}>
              {[[C.success,'Present',presentDays],[C.warning,'Late',lateDays],[C.danger,'Absent',absentDays]].map(([c,l,v]) => (
                <div key={l} style={{ display:'flex', alignItems:'center', gap:6 }}>
                  <div style={{ width:8, height:8, borderRadius:2, background:c, flexShrink:0 }} />
                  <span style={{ fontSize:11, color:C.textSecondary }}>{l}</span>
                  <span style={{ fontSize:12, fontWeight:700, color:c, marginLeft:'auto' }}>{v}</span>
                </div>
              ))}
            </div>
          </div>
        </Card>

        {/* Merits earned */}
        <Card style={{ borderTop:`3px solid ${C.success}` }}>
          <p style={{ fontSize:11, fontWeight:700, color:C.textSecondary, textTransform:'uppercase', letterSpacing:'0.6px', marginBottom:8 }}>Merits Earned</p>
          <p style={{ fontSize:32, fontWeight:800, color:C.success, lineHeight:1 }}>+{meritsEarned}</p>
          <p style={{ fontSize:11, color:C.textMuted, marginTop:6 }}>across {filteredBehaviour.filter(e=>e.delta>0).length} entries</p>
        </Card>

        {/* Demerits */}
        <Card style={{ borderTop:`3px solid ${demeritsTotal < 0 ? C.danger : C.border}` }}>
          <p style={{ fontSize:11, fontWeight:700, color:C.textSecondary, textTransform:'uppercase', letterSpacing:'0.6px', marginBottom:8 }}>Demerits</p>
          <p style={{ fontSize:32, fontWeight:800, color: demeritsTotal < 0 ? C.danger : C.textMuted, lineHeight:1 }}>{demeritsTotal || '—'}</p>
          <p style={{ fontSize:11, color:C.textMuted, marginTop:6 }}>net: {netMerits >= 0 ? '+' : ''}{netMerits} this period</p>
        </Card>

        {/* Avg PACE score */}
        <Card style={{ borderTop:`3px solid ${avgScore ? scoreColor(avgScore) : C.border}` }}>
          <p style={{ fontSize:11, fontWeight:700, color:C.textSecondary, textTransform:'uppercase', letterSpacing:'0.6px', marginBottom:8 }}>Avg PACE Score</p>
          <p style={{ fontSize:32, fontWeight:800, color: avgScore ? scoreColor(avgScore) : C.textMuted, lineHeight:1 }}>{avgScore ? `${avgScore}%` : '—'}</p>
          <p style={{ fontSize:11, color:C.textMuted, marginTop:6 }}>{filteredPace.length} test{filteredPace.length !== 1 ? 's' : ''} this period</p>
        </Card>
      </div>

      {/* Merit sparkline + recent notes side-by-side */}
      <div style={{ display:'grid', gridTemplateColumns: mobile ? '1fr' : '1fr 1fr', gap:16 }}>
        <Card>
          <p style={{ fontSize:13, fontWeight:700, color:C.navy, marginBottom:12 }}>Merit Activity (last 7 days)</p>
          <MeritSparkline entries={data.behaviour.filter(e => inRange(e.date, (() => { const w=new Date(TODAY); w.setDate(w.getDate()-6); return w; })(), TODAY))} />
          <div style={{ display:'flex', gap:12, marginTop:14, paddingTop:12, borderTop:`1px solid ${C.borderLight}` }}>
            <div style={{ flex:1, textAlign:'center' }}>
              <p style={{ fontSize:18, fontWeight:800, color:C.success }}>{meritsEarned > 0 ? `+${meritsEarned}` : '0'}</p>
              <p style={{ fontSize:11, color:C.textMuted, marginTop:2 }}>Merits</p>
            </div>
            <div style={{ width:1, background:C.border }} />
            <div style={{ flex:1, textAlign:'center' }}>
              <p style={{ fontSize:18, fontWeight:800, color: demeritsTotal < 0 ? C.danger : C.textMuted }}>{demeritsTotal || '0'}</p>
              <p style={{ fontSize:11, color:C.textMuted, marginTop:2 }}>Demerits</p>
            </div>
            <div style={{ width:1, background:C.border }} />
            <div style={{ flex:1, textAlign:'center' }}>
              <p style={{ fontSize:18, fontWeight:800, color: netMerits >= 0 ? C.navy : C.danger }}>{netMerits >= 0 ? `+${netMerits}` : netMerits}</p>
              <p style={{ fontSize:11, color:C.textMuted, marginTop:2 }}>Net</p>
            </div>
          </div>
        </Card>

        {/* Latest note */}
        <Card style={{ borderLeft:`4px solid ${C.blue}` }}>
          <p style={{ fontSize:13, fontWeight:700, color:C.navy, marginBottom:12 }}>Latest Supervisor Note</p>
          {filteredNotes.length > 0 ? (
            <>
              <p style={{ fontSize:13, color:C.textPrimary, lineHeight:1.7, fontStyle:'italic' }}>"{filteredNotes[0].note}"</p>
              <div style={{ display:'flex', justifyContent:'space-between', marginTop:12, paddingTop:10, borderTop:`1px solid ${C.borderLight}` }}>
                <span style={{ fontSize:12, fontWeight:600, color:C.textSecondary }}>{filteredNotes[0].by}</span>
                <span style={{ fontSize:11, color:C.textMuted }}>{fmtShort(filteredNotes[0].date)}</span>
              </div>
            </>
          ) : (
            <p style={{ fontSize:13, color:C.textMuted }}>No supervisor notes in this period.</p>
          )}
        </Card>
      </div>

      {/* PACE scores compact */}
      {filteredPace.length > 0 && (
        <Card>
          <p style={{ fontSize:13, fontWeight:700, color:C.navy, marginBottom:12 }}>PACE Tests this period</p>
          <div style={{ display:'flex', flexDirection:'column', gap:8 }}>
            {filteredPace.map((p,i) => (
              <div key={i} style={{ display:'flex', alignItems:'center', gap:12, padding:'8px 10px', background:C.bg, borderRadius:8 }}>
                <ScorePill score={p.score} />
                <div style={{ flex:1, minWidth:0 }}>
                  <p style={{ fontSize:12, fontWeight:700, color:C.navy }}>{p.subject} <span style={{ color:C.blue, fontWeight:600 }}>#{p.paceNumber}</span></p>
                  <p style={{ fontSize:11, color:C.textSecondary }}>{p.type} · {fmtShort(p.date)} · {p.supervisor}</p>
                </div>
                <Badge variant={p.type === 'PACE Test' ? 'navy' : 'blue'}>{p.type}</Badge>
              </div>
            ))}
          </div>
        </Card>
      )}
    </div>
  );

  // ── Behaviour tab ───────────────────────────────────────────────────────
  const BehaviourTab = () => (
    <div style={{ display:'flex', flexDirection:'column', gap:10 }}>
      {filteredBehaviour.length === 0 ? (
        <Card><p style={{ color:C.textMuted, fontSize:13 }}>No behaviour entries in this period.</p></Card>
      ) : filteredBehaviour.map((e, i) => (
        <Card key={i} style={{ borderLeft:`4px solid ${e.delta > 0 ? C.success : C.danger}` }} padding={16}>
          <div style={{ display:'flex', alignItems:'flex-start', gap:12 }}>
            {/* Delta bubble */}
            <div style={{ width:44, height:44, borderRadius:10, background: e.delta > 0 ? C.successBg : C.dangerBg, display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0 }}>
              <span style={{ fontSize:15, fontWeight:800, color: e.delta > 0 ? C.success : C.danger }}>{e.delta > 0 ? `+${e.delta}` : e.delta}</span>
            </div>
            <div style={{ flex:1, minWidth:0 }}>
              <div style={{ display:'flex', gap:8, alignItems:'center', flexWrap:'wrap', marginBottom:6 }}>
                <Badge variant={e.delta > 0 ? 'green' : 'red'}>{e.type}</Badge>
                <Badge variant="grey">{e.category}</Badge>
                <span style={{ fontSize:11, color:C.textMuted, marginLeft:'auto' }}>{fmtShort(e.date)}</span>
              </div>
              <p style={{ fontSize:13, color:C.textPrimary, lineHeight:1.6 }}>{e.note}</p>
              <p style={{ fontSize:11, color:C.textMuted, marginTop:6 }}>Recorded by <strong style={{ color:C.textSecondary }}>{e.by}</strong></p>
            </div>
          </div>
        </Card>
      ))}
    </div>
  );

  // ── PACE tab ────────────────────────────────────────────────────────────
  const PACETab = () => (
    <div style={{ display:'flex', flexDirection:'column', gap:10 }}>
      {filteredPace.length === 0 ? (
        <Card><p style={{ color:C.textMuted, fontSize:13 }}>No PACE scores recorded in this period.</p></Card>
      ) : filteredPace.map((p, i) => (
        <Card key={i} padding={16}>
          <div style={{ display:'flex', alignItems:'center', gap:14, flexWrap:'wrap' }}>
            {/* Score donut */}
            <div style={{ position:'relative', width:64, height:64, flexShrink:0 }}>
              <svg width={64} height={64} viewBox="0 0 64 64">
                <circle cx={32} cy={32} r={26} fill="none" stroke={C.border} strokeWidth={6} />
                <circle cx={32} cy={32} r={26} fill="none" stroke={scoreColor(p.score)} strokeWidth={6}
                  strokeDasharray={`${(p.score/100)*163.4} ${163.4}`}
                  strokeDashoffset={163.4*0.25} strokeLinecap="round" />
              </svg>
              <div style={{ position:'absolute', inset:0, display:'flex', alignItems:'center', justifyContent:'center' }}>
                <span style={{ fontSize:14, fontWeight:800, color:scoreColor(p.score) }}>{p.score}</span>
              </div>
            </div>
            <div style={{ flex:1, minWidth:0 }}>
              <div style={{ display:'flex', gap:8, alignItems:'center', marginBottom:6, flexWrap:'wrap' }}>
                <p style={{ fontSize:15, fontWeight:800, color:C.navy }}>{p.subject}</p>
                <Badge variant={p.type === 'PACE Test' ? 'navy' : 'blue'}>{p.type}</Badge>
              </div>
              <p style={{ fontSize:13, color:C.blue, fontWeight:600, marginBottom:4 }}>PACE #{p.paceNumber}</p>
              <div style={{ display:'flex', gap:16, flexWrap:'wrap' }}>
                <span style={{ fontSize:12, color:C.textSecondary }}>Date: <strong>{fmtShort(p.date)}</strong></span>
                <span style={{ fontSize:12, color:C.textSecondary }}>Supervisor: <strong>{p.supervisor}</strong></span>
              </div>
            </div>
            {/* Score bar */}
            <div style={{ width: mobile ? '100%' : 160 }}>
              <div style={{ display:'flex', justifyContent:'space-between', marginBottom:4 }}>
                <span style={{ fontSize:11, color:C.textSecondary }}>Score</span>
                <span style={{ fontSize:12, fontWeight:700, color:scoreColor(p.score) }}>{p.score}/{p.maxScore}</span>
              </div>
              <div style={{ height:8, background:C.bg, borderRadius:4, overflow:'hidden' }}>
                <div style={{ height:'100%', width:`${p.score}%`, background:scoreColor(p.score), borderRadius:4, transition:'width 0.4s ease' }} />
              </div>
              <p style={{ fontSize:10, color:C.textMuted, marginTop:4 }}>
                {p.score >= 90 ? '✓ Excellent' : p.score >= 80 ? '✓ Good' : p.score >= 70 ? '△ Satisfactory' : '✗ Needs support'}
              </p>
            </div>
          </div>
        </Card>
      ))}
    </div>
  );

  // ── Notes tab ───────────────────────────────────────────────────────────
  const NotesTab = () => (
    <div style={{ display:'flex', flexDirection:'column', gap:12 }}>
      {filteredNotes.length === 0 ? (
        <Card><p style={{ color:C.textMuted, fontSize:13 }}>No supervisor notes in this period.</p></Card>
      ) : filteredNotes.map((n, i) => (
        <Card key={i} style={{ borderLeft:`4px solid ${C.blue}` }} padding={18}>
          <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:10 }}>
            <div style={{ display:'flex', alignItems:'center', gap:10 }}>
              <Avatar initials={n.by.split(' ').map(w=>w[0]).join('').slice(0,2)} size={30} color={n.by.includes('Thompson') ? C.navy : C.blue} />
              <div>
                <p style={{ fontSize:13, fontWeight:700, color:C.navy }}>{n.by}</p>
                <p style={{ fontSize:11, color:C.textMuted }}>Supervisor note</p>
              </div>
            </div>
            <div style={{ textAlign:'right' }}>
              <p style={{ fontSize:12, fontWeight:600, color:C.textSecondary }}>{fmtShort(n.date)}</p>
            </div>
          </div>
          <p style={{ fontSize:13, color:C.textPrimary, lineHeight:1.75 }}>{n.note}</p>
        </Card>
      ))}
    </div>
  );

  const tabContent = { overview: <OverviewTab />, behaviour: <BehaviourTab />, pace: <PACETab />, notes: <NotesTab /> };

  // ── Full render ─────────────────────────────────────────────────────────
  return (
    <div className="page-fade">

      {/* Header */}
      <div style={{ marginBottom:20 }}>
        <h2 style={{ fontSize: mobile ? 18 : 24, fontWeight:800, color:C.navy }}>Student Progress Snapshot</h2>
        <p style={{ fontSize:13, color:C.textSecondary, marginTop:2 }}>Review a child's attendance, behaviour, PACE scores and notes for any period.</p>
      </div>

      {/* Student picker */}
      <Card style={{ marginBottom:16 }} padding={14}>
        <p style={{ fontSize:11, fontWeight:700, color:C.textSecondary, textTransform:'uppercase', letterSpacing:'0.5px', marginBottom:10 }}>Select student</p>
        <StudentPicker />
      </Card>

      {/* Selected student hero + range picker */}
      <Card style={{ marginBottom:16, background:`linear-gradient(130deg, ${C.navy} 0%, ${C.navyLight} 100%)`, border:'none' }} padding={mobile ? 16 : 20}>
        <div style={{ display:'flex', alignItems:'center', gap:14, marginBottom:16, flexWrap:'wrap' }}>
          <Avatar initials={student.initials} size={mobile ? 44 : 52} color={student.color} />
          <div style={{ flex:1 }}>
            <p style={{ fontSize: mobile ? 18 : 22, fontWeight:800, color:'#fff', margin:0 }}>{student.name}</p>
            <p style={{ fontSize:13, color:'rgba(255,255,255,0.65)', marginTop:2 }}>{student.year} · Supervisor: {student.tutor}</p>
          </div>
          <div style={{ background:'rgba(255,255,255,0.12)', borderRadius:10, padding:'8px 14px', textAlign:'center' }}>
            <p style={{ fontSize:18, fontWeight:800, color:'#fff', margin:0 }}>{student.merits.spend + student.merits.saving + student.merits.investment}</p>
            <p style={{ fontSize:10, color:'rgba(255,255,255,0.55)', marginTop:1 }}>total merits</p>
          </div>
        </div>
        <div style={{ paddingTop:14, borderTop:'1px solid rgba(255,255,255,0.12)' }}>
          <p style={{ fontSize:11, fontWeight:700, color:'rgba(255,255,255,0.5)', textTransform:'uppercase', letterSpacing:'0.5px', marginBottom:10 }}>Viewing period</p>
          <RangePicker />
          <p style={{ fontSize:12, color:'rgba(255,255,255,0.55)', marginTop:8 }}>📅 {label}</p>
        </div>
      </Card>

      {/* Tab bar */}
      <div style={{ display:'flex', gap:2, marginBottom:16, background:C.bg, borderRadius:10, padding:4, width:'fit-content' }}>
        {tabs.map(t => {
          const counts = { overview:'', behaviour: filteredBehaviour.length || '', pace: filteredPace.length || '', notes: filteredNotes.length || '' };
          return (
            <button key={t} onClick={() => setActiveTab(t)}
              style={{ padding:'8px 16px', borderRadius:7, border:'none', cursor:'pointer', fontFamily:'inherit', fontWeight:600, fontSize:12, textTransform:'capitalize', transition:'all 0.15s', display:'flex', alignItems:'center', gap:6,
                background: activeTab === t ? C.navy : 'transparent',
                color:       activeTab === t ? '#fff' : C.textSecondary,
              }}>
              {t}
              {counts[t] !== '' && <span style={{ background: activeTab === t ? 'rgba(255,255,255,0.2)' : C.blueLight, color: activeTab === t ? '#fff' : C.navy, fontSize:10, fontWeight:700, borderRadius:10, padding:'1px 6px' }}>{counts[t]}</span>}
            </button>
          );
        })}
      </div>

      {/* Tab content */}
      <div className="page-fade" key={`${studentId}-${range}-${customFrom}-${customTo}-${activeTab}`}>
        {tabContent[activeTab]}
      </div>
    </div>
  );
};

Object.assign(window, { StudentSnapshot });
