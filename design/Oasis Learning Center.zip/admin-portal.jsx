// admin-portal.jsx — Staff / Admin Portal

const ADMIN_NAV = [
  { id:'dashboard',   label:'Dashboard',   icon:'M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6' },
  { id:'students',    label:'Students',    icon:'M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z' },
  { id:'attendance',  label:'Attendance',  icon:'M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4' },
  { id:'behaviour',   label:'Behaviour',   icon:'M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z' },
  { id:'pace',        label:'PACE',        icon:'M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253' },
  { id:'shop',        label:'Merit Shop',  icon:'M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z' },
  { id:'leaderboard', label:'Leaderboard', icon:'M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z' },
  { id:'reports',     label:'Reports',     icon:'M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z' },
  { id:'fees',        label:'Invoices',    icon:'M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z' },
  { id:'messages',    label:'Messages',    icon:'M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z', badge:2 },
  { id:'noticeboard', label:'Noticeboard', icon:'M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9' },
  { id:'slips',       label:'Permission Slips', icon:'M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2zM9 8h6' },
  { id:'snapshot',    label:'Progress Snapshot', icon:'M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z', highlight: true },
  { id:'profiles',    label:'People & Profiles', icon:'M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z', highlight: true },
  { id:'audit',       label:'Audit Log', icon:'M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2zM9 8h.01', highlight: true },
];

const MOBILE_NAV = ['dashboard','students','attendance','shop','messages'];

// ── SVG Icon helper ──────────────────────────────────────────────────────────
const Icon = ({ path, size=20, color='currentColor' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round">
    <path d={path} />
  </svg>
);

// ── Admin Dashboard ──────────────────────────────────────────────────────────
const AdminDashboard = ({ mobile }) => {
  const present = Object.values(ATTENDANCE_TODAY).filter(s=>s==='Present').length;
  const absent  = Object.values(ATTENDANCE_TODAY).filter(s=>s==='Absent').length;
  const late    = Object.values(ATTENDANCE_TODAY).filter(s=>s==='Late').length;
  const totalMerits = BEHAVIOUR_ENTRIES.filter(e=>e.type==='Merit').reduce((a,b)=>a+b.delta,0);

  return (
    <div className="page-fade">
      <div style={{ marginBottom:24 }}>
        <p style={{ fontSize:13, color:C.textSecondary }}>Friday, 25 April 2026 · Spring Term 2</p>
        <h2 style={{ fontSize:mobile?20:26, fontWeight:800, color:C.navy, marginTop:2 }}>Good morning, Mrs Thompson</h2>
        <p style={{ fontSize:13, color:C.textSecondary, marginTop:2 }}>Head of Centre · Oasis Learning Centre</p>
      </div>

      {/* Stat cards */}
      <div style={{ display:'grid', gridTemplateColumns:mobile?'1fr 1fr':'repeat(4,1fr)', gap:12, marginBottom:24 }}>
        <StatCard label="Present Today" value={`${present}/${STUDENTS.length}`} sub={`${absent} absent · ${late} late`} accent={C.success} />
        <StatCard label="Merits Awarded" value={`+${totalMerits}`} sub="today across all students" accent={C.blue} />
        <StatCard label="Unread Messages" value="2" sub="from parents" accent={C.warning} />
        <StatCard label="Reports Due" value="3" sub="end of term deadline" accent={C.crimson} />
      </div>

      <div style={{ display:'grid', gridTemplateColumns:mobile?'1fr':'2fr 1fr', gap:16 }}>
        {/* Activity feed */}
        <Card>
          <p style={{ fontWeight:700, fontSize:14, color:C.navy, marginBottom:14 }}>Today's Activity</p>
          {BEHAVIOUR_ENTRIES.map(e => (
            <div key={e.id} style={{ display:'flex', alignItems:'flex-start', gap:12, paddingBottom:12, marginBottom:12, borderBottom:`1px solid ${C.borderLight}` }}>
              <Avatar initials={STUDENTS.find(s=>s.id===e.studentId)?.initials} size={32} color={STUDENTS.find(s=>s.id===e.studentId)?.color} />
              <div style={{ flex:1, minWidth:0 }}>
                <div style={{ display:'flex', alignItems:'center', gap:8, flexWrap:'wrap' }}>
                  <span style={{ fontWeight:600, fontSize:13, color:C.navy }}>{e.studentName}</span>
                  <Badge variant={e.type==='Merit'?'green':'red'}>{e.type==='Merit'?`+${e.delta} merits`:`${e.delta} merits`}</Badge>
                  {e.visibility==='Sensitive' && <Badge variant="amber">Sensitive</Badge>}
                </div>
                <p style={{ fontSize:12, color:C.textSecondary, marginTop:3 }}>{e.category} · {e.note.length>60?e.note.slice(0,60)+'…':e.note}</p>
              </div>
              <span style={{ fontSize:11, color:C.textMuted, whiteSpace:'nowrap' }}>{e.time}</span>
            </div>
          ))}
        </Card>

        {/* Quick actions + Attendance summary */}
        <div style={{ display:'flex', flexDirection:'column', gap:16 }}>
          <Card>
            <p style={{ fontWeight:700, fontSize:14, color:C.navy, marginBottom:12 }}>Quick Actions</p>
            <div style={{ display:'flex', flexDirection:'column', gap:8 }}>
              {[['Mark Attendance','attendance'],['Log Behaviour','behaviour'],['Record PACE Score','pace'],['Generate Report','reports']].map(([l])=>(
                <div key={l} style={{ padding:'10px 14px', background:C.bg, borderRadius:8, fontSize:13, fontWeight:600, color:C.navy, cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'space-between' }}>
                  <span>{l}</span><span style={{ color:C.blue }}>→</span>
                </div>
              ))}
            </div>
          </Card>
          <Card>
            <p style={{ fontWeight:700, fontSize:14, color:C.navy, marginBottom:12 }}>Attendance Today</p>
            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:8, textAlign:'center' }}>
              {[['Present',present,C.success],[`Absent`,absent,C.danger],[`Late`,late,C.warning]].map(([l,v,col])=>(
                <div key={l} style={{ background:C.bg, borderRadius:8, padding:'10px 4px' }}>
                  <p style={{ fontSize:20, fontWeight:800, color:col }}>{v}</p>
                  <p style={{ fontSize:11, color:C.textSecondary, marginTop:2 }}>{l}</p>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
};

// ── Admin Students ───────────────────────────────────────────────────────────
const AdminStudents = ({ mobile }) => {
  const [search, setSearch] = React.useState('');
  const [selected, setSelected] = React.useState(null);
  const [tab, setTab] = React.useState('overview');
  const filtered = STUDENTS.filter(s => s.name.toLowerCase().includes(search.toLowerCase()));

  if (selected) {
    const s = selected;
    const totalMerits = s.merits.spend + s.merits.saving + s.merits.investment;
    const tabs = ['overview','attendance','behaviour','pace','merits'];
    return (
      <div className="page-fade">
        <button onClick={()=>{setSelected(null);setTab('overview');}} style={{ display:'flex', alignItems:'center', gap:6, background:'none', border:'none', color:C.blue, fontWeight:600, fontSize:13, cursor:'pointer', marginBottom:16, fontFamily:'inherit' }}>← Back to Students</button>
        <Card style={{ marginBottom:16 }}>
          <div style={{ display:'flex', alignItems:'center', gap:16, flexWrap:'wrap' }}>
            <Avatar initials={s.initials} size={56} color={s.color} />
            <div style={{ flex:1 }}>
              <h3 style={{ fontSize:20, fontWeight:800, color:C.navy, margin:0 }}>{s.name}</h3>
              <p style={{ fontSize:13, color:C.textSecondary, marginTop:2 }}>{s.year} · Supervisor: {s.tutor} · Enrolled Jan 2024</p>
            </div>
            <div style={{ display:'flex', gap:8 }}>
              <Badge variant="green">Active</Badge>
              <Btn variant="secondary" size="sm">Edit Profile</Btn>
            </div>
          </div>
          <div style={{ display:'flex', gap:4, marginTop:16, borderBottom:`1px solid ${C.border}`, paddingBottom:0 }}>
            {tabs.map(t=>(
              <button key={t} onClick={()=>setTab(t)} style={{ padding:'8px 14px', fontWeight:600, fontSize:12, textTransform:'capitalize', background:'none', border:'none', borderBottom:tab===t?`2px solid ${C.crimson}`:'2px solid transparent', color:tab===t?C.crimson:C.textSecondary, cursor:'pointer', fontFamily:'inherit', letterSpacing:'0.3px' }}>{t}</button>
            ))}
          </div>
        </Card>

        {tab==='overview' && (
          <div style={{ display:'grid', gridTemplateColumns:mobile?'1fr':'1fr 1fr 1fr', gap:12 }}>
            <StatCard label="Total Merit Balance" value={totalMerits} sub={`Spend: ${s.merits.spend} · Saving: ${s.merits.saving}`} accent={C.blue} />
            <StatCard label="PACEs Completed" value={s.pacesCompleted} sub="this academic year" accent={C.navy} />
            <StatCard label="Attendance Rate" value="92%" sub="18/20 days this term" accent={C.success} />
          </div>
        )}

        {tab==='attendance' && (
          <Card>
            <p style={{ fontWeight:700, fontSize:14, color:C.navy, marginBottom:12 }}>April 2026</p>
            <div style={{ display:'grid', gridTemplateColumns:'repeat(7,1fr)', gap:4, textAlign:'center' }}>
              {['M','T','W','T','F','S','S'].map((d,i)=><div key={i} style={{ fontSize:11, fontWeight:700, color:C.textMuted, padding:'4px 0' }}>{d}</div>)}
              {Array.from({length:30},(_,i)=>i+1).map(d=>{
                const status = d===3||d===14?'Absent':d===7?'Late':'Present';
                const isWeekend = [5,6,12,13,19,20,26,27].includes(d);
                const bg = isWeekend?'transparent':status==='Present'?C.successBg:status==='Absent'?C.dangerBg:C.warningBg;
                const col = isWeekend?C.textMuted:status==='Present'?C.success:status==='Absent'?C.danger:C.warning;
                return <div key={d} style={{ padding:'6px 2px', borderRadius:6, background:bg, fontSize:11, fontWeight:600, color:col }}>{d}</div>;
              })}
            </div>
            <div style={{ display:'flex', gap:12, marginTop:12, flexWrap:'wrap' }}>
              {[['Present',C.successBg,C.success],['Absent',C.dangerBg,C.danger],['Late',C.warningBg,C.warning]].map(([l,bg,c])=>(
                <div key={l} style={{ display:'flex', alignItems:'center', gap:6 }}><div style={{ width:12,height:12,borderRadius:3,background:bg,border:`1px solid ${c}` }}></div><span style={{ fontSize:12, color:C.textSecondary }}>{l}</span></div>
              ))}
            </div>
          </Card>
        )}

        {tab==='behaviour' && (
          <div style={{ display:'flex', flexDirection:'column', gap:10 }}>
            {BEHAVIOUR_ENTRIES.filter(e=>e.studentId===s.id).length===0
              ? <Card><p style={{ color:C.textMuted, fontSize:13 }}>No behaviour entries for this student today.</p></Card>
              : BEHAVIOUR_ENTRIES.filter(e=>e.studentId===s.id).map(e=>(
                <Card key={e.id}>
                  <div style={{ display:'flex', alignItems:'flex-start', justifyContent:'space-between', gap:12 }}>
                    <div>
                      <div style={{ display:'flex', gap:8, alignItems:'center', marginBottom:6 }}>
                        <Badge variant={e.type==='Merit'?'green':'red'}>{e.type} {e.delta > 0 ? `+${e.delta}` : e.delta}</Badge>
                        <Badge variant="grey">{e.category}</Badge>
                        {e.visibility==='Sensitive' && <Badge variant="amber">Sensitive</Badge>}
                      </div>
                      <p style={{ fontSize:13, color:C.textPrimary }}>{e.note}</p>
                      <p style={{ fontSize:11, color:C.textMuted, marginTop:4 }}>Recorded by {e.recordedBy} · {e.time}</p>
                    </div>
                  </div>
                </Card>
              ))
            }
          </div>
        )}

        {tab==='pace' && (
          <Card padding={0}>
            <table style={{ width:'100%', borderCollapse:'collapse', fontSize:13 }}>
              <thead><tr style={{ background:C.bg }}>{['Subject','Current PACE','Self-Test','PACE Test','Completed','Status'].map(h=><th key={h} style={{ padding:'10px 14px', textAlign:'left', fontSize:11, fontWeight:700, color:C.textSecondary, textTransform:'uppercase', letterSpacing:'0.5px' }}>{h}</th>)}</tr></thead>
              <tbody>{PACE_SUBJECTS.map((p,i)=>(
                <tr key={i} style={{ borderTop:`1px solid ${C.border}` }}>
                  <td style={{ padding:'12px 14px', fontWeight:600, color:C.navy }}>{p.subject}</td>
                  <td style={{ padding:'12px 14px', color:C.blue, fontWeight:700 }}>#{p.paceNumber}</td>
                  <td style={{ padding:'12px 14px' }}><span style={{ color:p.selfTest>=90?C.success:p.selfTest>=75?C.warning:C.danger, fontWeight:600 }}>{p.selfTest}%</span></td>
                  <td style={{ padding:'12px 14px' }}><span style={{ color:p.paceTest>=90?C.success:p.paceTest>=75?C.warning:C.danger, fontWeight:600 }}>{p.paceTest}%</span></td>
                  <td style={{ padding:'12px 14px', color:C.textSecondary, fontSize:12 }}>{p.completedAt}</td>
                  <td style={{ padding:'12px 14px' }}><Badge variant={p.status==='Ahead'?'green':p.status==='On Track'?'blue':'red'}>{p.status}</Badge></td>
                </tr>
              ))}</tbody>
            </table>
          </Card>
        )}

        {tab==='merits' && (
          <div style={{ display:'grid', gridTemplateColumns:mobile?'1fr':'1fr 1fr 1fr', gap:12 }}>
            {[['Spend Account',s.merits.spend,C.crimson,'Available to spend in Merit Shop'],['Saving Account',s.merits.saving,C.navy,'Transferred from Spend; earns no interest'],['Investment Account',s.merits.investment,C.blue,'Units × current NAV · ~10% p.a. avg']].map(([label,val,col,desc])=>(
              <Card key={label} style={{ borderTop:`3px solid ${col}` }}>
                <p style={{ fontSize:12, fontWeight:700, color:C.textSecondary, marginBottom:8 }}>{label}</p>
                <p style={{ fontSize:32, fontWeight:800, color:col }}>{val}</p>
                <p style={{ fontSize:11, color:C.textMuted, marginTop:6 }}>{desc}</p>
              </Card>
            ))}
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="page-fade">
      <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:20, flexWrap:'wrap', gap:12 }}>
        <h2 style={{ fontSize:mobile?18:22, fontWeight:800, color:C.navy }}>Students</h2>
        <div style={{ display:'flex', gap:10, flexWrap:'wrap' }}>
          <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search students…" style={{ padding:'8px 14px', border:`1.5px solid ${C.border}`, borderRadius:8, fontSize:13, fontFamily:'inherit', color:C.navy, outline:'none', width:mobile?'100%':220 }} />
          <Btn variant="primary" size="sm">+ Add Student</Btn>
        </div>
      </div>
      {mobile ? (
        <div style={{ display:'flex', flexDirection:'column', gap:10 }}>
          {filtered.map(s=>(
            <Card key={s.id} style={{ cursor:'pointer' }} padding={14}>
              <div onClick={()=>setSelected(s)} style={{ display:'flex', alignItems:'center', gap:12 }}>
                <Avatar initials={s.initials} size={40} color={s.color} />
                <div style={{ flex:1 }}>
                  <p style={{ fontWeight:700, fontSize:14, color:C.navy }}>{s.name}</p>
                  <p style={{ fontSize:12, color:C.textSecondary }}>{s.year} · {s.merits.spend+s.merits.saving+s.merits.investment} merits total</p>
                </div>
                <Badge variant={ATTENDANCE_TODAY[s.id]==='Present'?'green':ATTENDANCE_TODAY[s.id]==='Late'?'amber':'red'}>{ATTENDANCE_TODAY[s.id]}</Badge>
              </div>
            </Card>
          ))}
        </div>
      ) : (
        <Card padding={0}>
          <table style={{ width:'100%', borderCollapse:'collapse', fontSize:13 }}>
            <thead><tr style={{ background:C.bg }}>{['Student','Year','Supervisor','Merit Total','PACEs Done','Today'].map(h=><th key={h} style={{ padding:'10px 14px', textAlign:'left', fontSize:11, fontWeight:700, color:C.textSecondary, textTransform:'uppercase', letterSpacing:'0.5px' }}>{h}</th>)}</tr></thead>
            <tbody>{filtered.map(s=>(
              <tr key={s.id} onClick={()=>setSelected(s)} style={{ borderTop:`1px solid ${C.border}`, cursor:'pointer' }} onMouseEnter={e=>e.currentTarget.style.background=C.bg} onMouseLeave={e=>e.currentTarget.style.background=''}>
                <td style={{ padding:'12px 14px' }}>
                  <div style={{ display:'flex', alignItems:'center', gap:10 }}>
                    <Avatar initials={s.initials} size={30} color={s.color} />
                    <span style={{ fontWeight:600, color:C.navy }}>{s.name}</span>
                  </div>
                </td>
                <td style={{ padding:'12px 14px', color:C.textSecondary }}>{s.year}</td>
                <td style={{ padding:'12px 14px', color:C.textSecondary }}>{s.tutor}</td>
                <td style={{ padding:'12px 14px', fontWeight:700, color:C.navy }}>{s.merits.spend+s.merits.saving+s.merits.investment}</td>
                <td style={{ padding:'12px 14px', color:C.textSecondary }}>{s.pacesCompleted}</td>
                <td style={{ padding:'12px 14px' }}><Badge variant={ATTENDANCE_TODAY[s.id]==='Present'?'green':ATTENDANCE_TODAY[s.id]==='Late'?'amber':'red'}>{ATTENDANCE_TODAY[s.id]}</Badge></td>
              </tr>
            ))}</tbody>
          </table>
        </Card>
      )}
    </div>
  );
};

// ── Admin Attendance ─────────────────────────────────────────────────────────
const AdminAttendance = ({ mobile }) => {
  const [att, setAtt] = React.useState({...ATTENDANCE_TODAY});
  const [saved, setSaved] = React.useState(false);
  const mark = (id, status) => { setAtt(a=>({...a,[id]:status})); setSaved(false); };
  const save = () => { setSaved(true); };
  const statuses = ['Present','Late','Absent'];
  const statusColor = { Present:C.success, Late:C.warning, Absent:C.danger };
  const statusBg = { Present:C.successBg, Late:C.warningBg, Absent:C.dangerBg };

  return (
    <div className="page-fade">
      <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:20, flexWrap:'wrap', gap:12 }}>
        <div>
          <h2 style={{ fontSize:mobile?18:22, fontWeight:800, color:C.navy }}>Attendance Register</h2>
          <p style={{ fontSize:13, color:C.textSecondary, marginTop:2 }}>Friday, 25 April 2026</p>
        </div>
        <div style={{ display:'flex', gap:8, alignItems:'center' }}>
          {saved && <Badge variant="green">Saved ✓</Badge>}
          <Btn onClick={save} variant="primary">Save Register</Btn>
        </div>
      </div>
      <Card padding={0}>
        {STUDENTS.map((s,i)=>(
          <div key={s.id} style={{ display:'flex', alignItems:'center', gap:12, padding:'12px 16px', borderBottom:i<STUDENTS.length-1?`1px solid ${C.border}`:'none', background:att[s.id]==='Absent'?'#FFF8F8':'' }}>
            <Avatar initials={s.initials} size={34} color={s.color} />
            <div style={{ flex:1, minWidth:0 }}>
              <p style={{ fontWeight:600, fontSize:13, color:C.navy }}>{s.name}</p>
              <p style={{ fontSize:11, color:C.textSecondary }}>{s.year}</p>
            </div>
            <div style={{ display:'flex', gap:6 }}>
              {statuses.map(status=>(
                <button key={status} onClick={()=>mark(s.id,status)} style={{ padding:mobile?'6px 10px':'6px 14px', borderRadius:6, border:`1.5px solid ${att[s.id]===status?statusColor[status]:C.border}`, background:att[s.id]===status?statusBg[status]:'transparent', color:att[s.id]===status?statusColor[status]:C.textSecondary, fontWeight:600, fontSize:mobile?11:12, cursor:'pointer', fontFamily:'inherit', transition:'all 0.1s' }}>{mobile?status.slice(0,1):status}</button>
              ))}
            </div>
          </div>
        ))}
      </Card>
      <div style={{ display:'flex', gap:12, marginTop:14, flexWrap:'wrap' }}>
        {[['Present',C.success],[`Late`,C.warning],[`Absent`,C.danger]].map(([l,col])=>(
          <div key={l} style={{ fontSize:13, fontWeight:600, color:col }}>{Object.values(att).filter(v=>v===l).length} {l}</div>
        ))}
      </div>
    </div>
  );
};

// ── Admin Behaviour ──────────────────────────────────────────────────────────
const AdminBehaviour = ({ mobile }) => {
  const [type, setType] = React.useState('Merit');
  const [studentId, setStudentId] = React.useState('1');
  const [category, setCategory] = React.useState('Scripture Memory');
  const [note, setNote] = React.useState('');
  const [visibility, setVisibility] = React.useState('General');

  const meritCategories = ['Scripture Memory','Academic Excellence','Helpfulness','Character','Leadership','Punctuality','Creativity'];
  const demeritCategories = ['Punctuality','Conduct','Disrespect','Negligence','Dishonesty'];

  return (
    <div className="page-fade">
      <h2 style={{ fontSize:mobile?18:22, fontWeight:800, color:C.navy, marginBottom:20 }}>Behaviour Log</h2>
      <div style={{ display:'grid', gridTemplateColumns:mobile?'1fr':'1fr 1.5fr', gap:16, alignItems:'start' }}>
        <Card>
          <p style={{ fontWeight:700, fontSize:14, color:C.navy, marginBottom:14 }}>Log New Entry</p>
          {/* Merit / Demerit toggle */}
          <div style={{ display:'flex', background:C.bg, borderRadius:8, padding:4, marginBottom:14 }}>
            {['Merit','Demerit'].map(t=>(
              <button key={t} onClick={()=>setType(t)} style={{ flex:1, padding:'8px', borderRadius:6, border:'none', background:type===t?(t==='Merit'?C.success:C.danger):'transparent', color:type===t?'#fff':C.textSecondary, fontWeight:700, fontSize:13, cursor:'pointer', fontFamily:'inherit', transition:'all 0.15s' }}>{t}</button>
            ))}
          </div>
          <Select label="Student" value={studentId} onChange={e=>setStudentId(e.target.value)} options={STUDENTS.map(s=>({value:String(s.id),label:s.name}))} style={{ marginBottom:12 }} />
          <Select label="Category" value={category} onChange={e=>setCategory(e.target.value)} options={(type==='Merit'?meritCategories:demeritCategories).map(c=>({value:c,label:c}))} style={{ marginBottom:12 }} />
          <div style={{ marginBottom:12 }}>
            <label style={{ fontSize:12, fontWeight:600, color:C.textSecondary, display:'block', marginBottom:5 }}>Notes</label>
            <textarea value={note} onChange={e=>setNote(e.target.value)} placeholder="Describe the behaviour…" rows={3} style={{ width:'100%', padding:'9px 12px', border:`1.5px solid ${C.border}`, borderRadius:8, fontSize:13, fontFamily:'inherit', color:C.textPrimary, resize:'vertical', outline:'none' }} />
          </div>
          <div style={{ marginBottom:16 }}>
            <label style={{ fontSize:12, fontWeight:600, color:C.textSecondary, display:'block', marginBottom:8 }}>Visibility</label>
            <div style={{ display:'flex', gap:8 }}>
              {['General','Sensitive'].map(v=>(
                <button key={v} onClick={()=>setVisibility(v)} style={{ flex:1, padding:'8px', borderRadius:6, border:`1.5px solid ${visibility===v?C.navy:C.border}`, background:visibility===v?C.navy:'transparent', color:visibility===v?'#fff':C.textSecondary, fontWeight:600, fontSize:12, cursor:'pointer', fontFamily:'inherit' }}>{v}</button>
              ))}
            </div>
            {visibility==='Sensitive' && <p style={{ fontSize:11, color:C.warning, marginTop:6 }}>⚠ Sensitive entries are only visible to full admin roles</p>}
          </div>
          <Btn variant={type==='Merit'?'navy':'primary'} style={{ width:'100%', justifyContent:'center' }}>
            {type==='Merit'?`Record +5 Merit`:`Record −5 Demerit`}
          </Btn>
        </Card>

        <div>
          <p style={{ fontWeight:700, fontSize:14, color:C.navy, marginBottom:12 }}>Recent Entries — Today</p>
          <div style={{ display:'flex', flexDirection:'column', gap:10 }}>
            {BEHAVIOUR_ENTRIES.map(e=>(
              <Card key={e.id} padding={14}>
                <div style={{ display:'flex', alignItems:'flex-start', gap:10 }}>
                  <Avatar initials={STUDENTS.find(s=>s.id===e.studentId)?.initials} size={32} color={STUDENTS.find(s=>s.id===e.studentId)?.color} />
                  <div style={{ flex:1, minWidth:0 }}>
                    <div style={{ display:'flex', gap:6, alignItems:'center', flexWrap:'wrap', marginBottom:4 }}>
                      <span style={{ fontWeight:700, fontSize:13, color:C.navy }}>{e.studentName}</span>
                      <Badge variant={e.type==='Merit'?'green':'red'}>{e.delta>0?`+${e.delta}`:e.delta} merits</Badge>
                      <Badge variant="grey">{e.category}</Badge>
                      {e.visibility==='Sensitive' && <Badge variant="amber">🔒 Sensitive</Badge>}
                    </div>
                    <p style={{ fontSize:12, color:C.textSecondary }}>{e.note}</p>
                    <p style={{ fontSize:11, color:C.textMuted, marginTop:3 }}>by {e.recordedBy} · {e.time}</p>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

// ── Admin Leaderboard ────────────────────────────────────────────────────────
const AdminLeaderboard = ({ mobile }) => {
  const [tab, setTab] = React.useState('tithers');
  const sorted = {
    tithers: [...STUDENTS].sort((a,b)=>(b.merits.spend+b.merits.saving+b.merits.investment)*b.tithe/100-(a.merits.spend+a.merits.saving+a.merits.investment)*a.tithe/100),
    investors: [...STUDENTS].sort((a,b)=>b.merits.investment-a.merits.investment),
    savers: [...STUDENTS].sort((a,b)=>b.merits.saving-a.merits.saving),
    demerits: [...STUDENTS].sort((a,b)=>a.merits.spend-b.merits.spend),
  };
  const vals = { tithers:s=>Math.round((s.merits.spend+s.merits.saving+s.merits.investment)*s.tithe/100)+' tithed', investors:s=>s.merits.investment+' in investment', savers:s=>s.merits.saving+' saved', demerits:s=>s.merits.spend+' spend balance' };
  const medals = ['🥇','🥈','🥉'];
  const tabDefs = [['tithers','Top Tithers'],['investors','Top Investors'],['savers','Top Savers'],['demerits','⚠ Demerits']];

  return (
    <div className="page-fade">
      <h2 style={{ fontSize:mobile?18:22, fontWeight:800, color:C.navy, marginBottom:20 }}>Leaderboard</h2>
      <div style={{ display:'flex', gap:4, marginBottom:16, background:C.bg, borderRadius:10, padding:4, width:'fit-content', flexWrap:'wrap' }}>
        {tabDefs.map(([id,label])=>(
          <button key={id} onClick={()=>setTab(id)} style={{ padding:'8px 16px', borderRadius:7, border:'none', background:tab===id?C.navy:'transparent', color:tab===id?'#fff':C.textSecondary, fontWeight:600, fontSize:12, cursor:'pointer', fontFamily:'inherit' }}>{label}</button>
        ))}
      </div>
      {tab==='demerits' && <div style={{ padding:'10px 14px', background:C.dangerBg, borderRadius:8, marginBottom:12, fontSize:12, color:C.danger, fontWeight:600 }}>🔒 Admin only — visible to leaderboard-admin tag holders</div>}
      <Card padding={0}>
        {sorted[tab].map((s,i)=>(
          <div key={s.id} style={{ display:'flex', alignItems:'center', gap:12, padding:'14px 16px', borderBottom:i<9?`1px solid ${C.border}`:'none' }}>
            <span style={{ fontSize:i<3?20:14, width:28, textAlign:'center', fontWeight:700, color:i<3?'':C.textMuted }}>{i<3?medals[i]:`#${i+1}`}</span>
            <Avatar initials={s.initials} size={34} color={s.color} />
            <div style={{ flex:1 }}>
              <p style={{ fontWeight:600, fontSize:13, color:C.navy }}>{s.name}</p>
              <p style={{ fontSize:11, color:C.textSecondary }}>{s.year}</p>
            </div>
            <p style={{ fontWeight:700, fontSize:13, color:C.blue }}>{vals[tab](s)}</p>
          </div>
        ))}
      </Card>
    </div>
  );
};

// ── Admin Messages ───────────────────────────────────────────────────────────
const AdminMessages = ({ mobile }) => {
  const [selected, setSelected] = React.useState(mobile?null:MESSAGES[0]);
  const [reply, setReply] = React.useState('');
  if (mobile) {
    if (selected) return (
      <div className="page-fade" style={{ display:'flex', flexDirection:'column', height:'100%' }}>
        <button onClick={()=>setSelected(null)} style={{ display:'flex', alignItems:'center', gap:6, background:'none', border:'none', color:C.blue, fontWeight:600, fontSize:13, cursor:'pointer', marginBottom:12, fontFamily:'inherit' }}>← Back</button>
        <Card style={{ marginBottom:12 }}><p style={{ fontWeight:700, fontSize:14, color:C.navy }}>{selected.from}</p><p style={{ fontSize:12, color:C.textSecondary }}>{selected.role}</p></Card>
        <Card style={{ flex:1, marginBottom:12 }}><p style={{ fontSize:13, color:C.textPrimary, lineHeight:1.6 }}>{selected.body}</p></Card>
        <div style={{ display:'flex', gap:8 }}>
          <input value={reply} onChange={e=>setReply(e.target.value)} placeholder="Type a reply…" style={{ flex:1, padding:'10px 14px', border:`1.5px solid ${C.border}`, borderRadius:8, fontSize:13, fontFamily:'inherit', outline:'none' }} />
          <Btn variant="primary">Send</Btn>
        </div>
      </div>
    );
    return (
      <div className="page-fade">
        <h2 style={{ fontSize:18, fontWeight:800, color:C.navy, marginBottom:14 }}>Messages</h2>
        {MESSAGES.map(m=>(
          <Card key={m.id} style={{ marginBottom:10, cursor:'pointer', borderLeft:m.unread?`3px solid ${C.crimson}`:'' }} padding={14} onClick={()=>setSelected(m)}>
            <div style={{ display:'flex', justifyContent:'space-between', marginBottom:4 }}>
              <p style={{ fontWeight:700, fontSize:13, color:C.navy }}>{m.from}</p>
              <span style={{ fontSize:11, color:C.textMuted }}>{m.time}</span>
            </div>
            <p style={{ fontSize:12, color:C.textSecondary }}>{m.preview}</p>
          </Card>
        ))}
      </div>
    );
  }
  return (
    <div className="page-fade">
      <h2 style={{ fontSize:22, fontWeight:800, color:C.navy, marginBottom:20 }}>Messages</h2>
      <div style={{ display:'grid', gridTemplateColumns:'300px 1fr', gap:16, minHeight:480 }}>
        <Card padding={0}>
          {MESSAGES.map((m,i)=>(
            <div key={m.id} onClick={()=>setSelected(m)} style={{ padding:'14px 16px', borderBottom:i<MESSAGES.length-1?`1px solid ${C.border}`:'none', cursor:'pointer', background:selected?.id===m.id?C.bg:'', borderLeft:m.unread?`3px solid ${C.crimson}`:'' }}>
              <div style={{ display:'flex', justifyContent:'space-between', marginBottom:4 }}>
                <p style={{ fontWeight:700, fontSize:13, color:C.navy }}>{m.from}</p>
                <span style={{ fontSize:11, color:C.textMuted }}>{m.time}</span>
              </div>
              <p style={{ fontSize:12, color:C.textSecondary }}>{m.role}</p>
              <p style={{ fontSize:11, color:C.textMuted, marginTop:4 }}>{m.preview.slice(0,55)}…</p>
            </div>
          ))}
        </Card>
        {selected ? (
          <Card style={{ display:'flex', flexDirection:'column' }}>
            <div style={{ marginBottom:16, paddingBottom:16, borderBottom:`1px solid ${C.border}` }}>
              <p style={{ fontWeight:700, fontSize:16, color:C.navy }}>{selected.from}</p>
              <p style={{ fontSize:12, color:C.textSecondary }}>{selected.role}</p>
            </div>
            <p style={{ fontSize:14, color:C.textPrimary, lineHeight:1.7, flex:1 }}>{selected.body}</p>
            <div style={{ marginTop:20, paddingTop:16, borderTop:`1px solid ${C.border}`, display:'flex', gap:10 }}>
              <input value={reply} onChange={e=>setReply(e.target.value)} placeholder="Type your reply…" style={{ flex:1, padding:'10px 14px', border:`1.5px solid ${C.border}`, borderRadius:8, fontSize:13, fontFamily:'inherit', outline:'none' }} />
              <Btn variant="primary">Send Reply</Btn>
            </div>
          </Card>
        ) : <Card style={{ display:'flex', alignItems:'center', justifyContent:'center' }}><p style={{ color:C.textMuted }}>Select a conversation</p></Card>}
      </div>
    </div>
  );
};

// ── Admin Noticeboard ────────────────────────────────────────────────────────
const AdminNoticeboard = ({ mobile }) => {
  const [title, setTitle] = React.useState('');
  const [body, setBody] = React.useState('');
  return (
    <div className="page-fade">
      <h2 style={{ fontSize:mobile?18:22, fontWeight:800, color:C.navy, marginBottom:20 }}>Staff Noticeboard</h2>
      <div style={{ display:'grid', gridTemplateColumns:mobile?'1fr':'1fr 1.6fr', gap:16, alignItems:'start' }}>
        <Card>
          <p style={{ fontWeight:700, fontSize:14, color:C.navy, marginBottom:14 }}>Post a Notice</p>
          <Input label="Title" value={title} onChange={e=>setTitle(e.target.value)} placeholder="Notice title…" style={{ marginBottom:12 }} />
          <div style={{ marginBottom:14 }}>
            <label style={{ fontSize:12, fontWeight:600, color:C.textSecondary, display:'block', marginBottom:5 }}>Message</label>
            <textarea value={body} onChange={e=>setBody(e.target.value)} placeholder="Notice body…" rows={4} style={{ width:'100%', padding:'9px 12px', border:`1.5px solid ${C.border}`, borderRadius:8, fontSize:13, fontFamily:'inherit', resize:'vertical', outline:'none' }} />
          </div>
          <Btn variant="primary" style={{ width:'100%', justifyContent:'center' }}>Post to Noticeboard</Btn>
        </Card>
        <div style={{ display:'flex', flexDirection:'column', gap:12 }}>
          {NOTICES.map(n=>(
            <Card key={n.id}>
              <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:8 }}>
                <p style={{ fontWeight:700, fontSize:14, color:C.navy, flex:1 }}>{n.title}</p>
                <Badge variant={n.readCount===n.totalStaff?'green':'amber'}>{n.readCount}/{n.totalStaff} read</Badge>
              </div>
              <p style={{ fontSize:13, color:C.textSecondary, lineHeight:1.6, marginBottom:8 }}>{n.body}</p>
              <p style={{ fontSize:11, color:C.textMuted }}>Posted by {n.author} · {n.posted} Apr</p>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
};

// ── Admin Reports ────────────────────────────────────────────────────────────
const AdminReports = ({ mobile }) => {
  const statuses = { 1:'Sent', 2:'Reviewed', 3:'Draft', 4:'Sent', 5:'Draft', 6:'Sent', 7:'Reviewed', 8:'Draft', 9:'Draft', 10:'Sent' };
  return (
    <div className="page-fade">
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:20, flexWrap:'wrap', gap:12 }}>
        <div><h2 style={{ fontSize:mobile?18:22, fontWeight:800, color:C.navy }}>Term Reports</h2><p style={{ fontSize:13, color:C.textSecondary, marginTop:2 }}>Spring Term 2 · Deadline: 9 May 2026</p></div>
        <Btn variant="primary">Generate All Drafts</Btn>
      </div>
      <Card padding={0}>
        {STUDENTS.map((s,i)=>{
          const st = statuses[s.id];
          return (
            <div key={s.id} style={{ display:'flex', alignItems:'center', gap:12, padding:'12px 16px', borderBottom:i<STUDENTS.length-1?`1px solid ${C.border}`:'none' }}>
              <Avatar initials={s.initials} size={32} color={s.color} />
              <div style={{ flex:1 }}><p style={{ fontWeight:600, fontSize:13, color:C.navy }}>{s.name}</p><p style={{ fontSize:11, color:C.textSecondary }}>{s.year}</p></div>
              <Badge variant={st==='Sent'?'green':st==='Reviewed'?'blue':'grey'}>{st}</Badge>
              <div style={{ display:'flex', gap:6 }}>
                <Btn variant="secondary" size="sm">{st==='Draft'?'Review':'View'}</Btn>
                {st!=='Sent' && <Btn variant="primary" size="sm">Send</Btn>}
              </div>
            </div>
          );
        })}
      </Card>
    </div>
  );
};

// ── PACE Update Score Modal ──────────────────────────────────────────────────
const PaceUpdateModal = ({ student, pace, onClose, onSave }) => {
  const { useState, useEffect, useRef } = React;

  const [testType,    setTestType]    = useState(pace ? 'Self-Test' : 'Self-Test');
  const [score,       setScore]       = useState(pace ? String(pace.selfTest) : '');
  const [paceNumber,  setPaceNumber]  = useState(pace ? String(pace.paceNumber) : '');
  const [subject,     setSubject]     = useState(pace ? pace.subject : PACE_SUBJECTS[0].subject);
  const [supervisor,  setSupervisor]  = useState('Mrs Thompson');
  const [date,        setDate]        = useState('2026-05-01');
  const [notes,       setNotes]       = useState('');
  const [saving,      setSaving]      = useState(false);
  const [saved,       setSaved]       = useState(false);
  const [scoreError,  setScoreError]  = useState('');
  const overlayRef = useRef(null);

  const scoreNum = parseInt(score, 10);
  const validScore = !isNaN(scoreNum) && scoreNum >= 0 && scoreNum <= 100;
  const scoreColor = validScore
    ? (scoreNum >= 90 ? C.success : scoreNum >= 75 ? C.warning : C.danger)
    : C.textMuted;
  const scoreBg = validScore
    ? (scoreNum >= 90 ? C.successBg : scoreNum >= 75 ? C.warningBg : C.dangerBg)
    : C.bg;
  const scoreLabel = validScore
    ? (scoreNum >= 90 ? 'Excellent' : scoreNum >= 80 ? 'Good' : scoreNum >= 70 ? 'Satisfactory' : scoreNum >= 60 ? 'Needs support' : 'Below threshold')
    : '—';

  const supervisors = ['Mrs Thompson', 'Mr Osei'];
  const subjects    = ['Mathematics', 'English', 'Bible', 'Science', 'Social Studies'];
  const testTypes   = ['Self-Test', 'PACE Test'];

  // Close on Escape
  useEffect(() => {
    const handler = e => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, []);

  const handleOverlayClick = e => {
    if (e.target === overlayRef.current) onClose();
  };

  const handleSave = () => {
    if (!validScore) { setScoreError('Please enter a score between 0 and 100.'); return; }
    setScoreError('');
    setSaving(true);
    setTimeout(() => {
      setSaving(false);
      setSaved(true);
      setTimeout(() => { onSave && onSave({ subject, paceNumber, testType, score: scoreNum, supervisor, date, notes }); onClose(); }, 900);
    }, 900);
  };

  // Score ring SVG
  const r = 34, circ = 2 * Math.PI * r;
  const ringPct = validScore ? scoreNum / 100 : 0;

  return (
    <div
      ref={overlayRef}
      onClick={handleOverlayClick}
      style={{
        position: 'fixed', inset: 0, zIndex: 9000,
        background: 'rgba(10,18,40,0.55)', backdropFilter: 'blur(4px)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        padding: 20,
        animation: 'pageFadeIn 0.18s ease',
      }}
    >
      <div style={{
        width: '100%', maxWidth: 520,
        background: C.surface,
        borderRadius: 18,
        boxShadow: '0 32px 80px rgba(0,0,0,0.32)',
        overflow: 'hidden',
        display: 'flex', flexDirection: 'column',
        maxHeight: 'calc(100vh - 48px)',
      }}>

        {/* ── Header ── */}
        <div style={{
          background: `linear-gradient(130deg, ${C.navy} 0%, ${C.navyMid} 100%)`,
          padding: '20px 24px',
          display: 'flex', alignItems: 'center', gap: 14, flexShrink: 0,
        }}>
          <div style={{
            width: 42, height: 42, borderRadius: 12,
            background: 'rgba(255,255,255,0.12)',
            display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
          }}>
            <svg width={22} height={22} viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round">
              <path d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
            </svg>
          </div>
          <div style={{ flex: 1 }}>
            <p style={{ fontSize: 17, fontWeight: 800, color: '#fff', margin: 0 }}>Update PACE Score</p>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 4 }}>
              <Avatar initials={student.initials} size={18} color={student.color} />
              <p style={{ fontSize: 12, color: 'rgba(255,255,255,0.65)', margin: 0 }}>{student.name} · {student.year}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            style={{
              width: 32, height: 32, borderRadius: 8,
              background: 'rgba(255,255,255,0.12)', border: 'none',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              cursor: 'pointer', flexShrink: 0, color: '#fff',
            }}
          >
            <svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2.5} strokeLinecap="round">
              <path d="M18 6L6 18M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* ── Body ── */}
        <div style={{ overflowY: 'auto', padding: '24px 24px 0' }}>

          {/* Subject + PACE number row */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 16 }}>
            <div>
              <label style={{ fontSize: 11, fontWeight: 700, color: C.textSecondary, display: 'block', marginBottom: 6, textTransform: 'uppercase', letterSpacing: '0.4px' }}>Subject</label>
              <select
                value={subject}
                onChange={e => setSubject(e.target.value)}
                style={{ width: '100%', padding: '10px 12px', border: `1.5px solid ${C.border}`, borderRadius: 9, fontSize: 13, fontFamily: 'inherit', color: C.textPrimary, background: C.surface, outline: 'none', cursor: 'pointer' }}
              >
                {subjects.map(s => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>
            <div>
              <label style={{ fontSize: 11, fontWeight: 700, color: C.textSecondary, display: 'block', marginBottom: 6, textTransform: 'uppercase', letterSpacing: '0.4px' }}>PACE Number</label>
              <input
                type="text"
                value={paceNumber}
                onChange={e => setPaceNumber(e.target.value)}
                placeholder="e.g. 1097"
                style={{ width: '100%', padding: '10px 12px', border: `1.5px solid ${C.border}`, borderRadius: 9, fontSize: 13, fontFamily: 'inherit', color: C.textPrimary, background: C.surface, outline: 'none' }}
              />
            </div>
          </div>

          {/* Test type toggle */}
          <div style={{ marginBottom: 16 }}>
            <label style={{ fontSize: 11, fontWeight: 700, color: C.textSecondary, display: 'block', marginBottom: 8, textTransform: 'uppercase', letterSpacing: '0.4px' }}>Test Type</label>
            <div style={{ display: 'flex', background: C.bg, borderRadius: 10, padding: 4, gap: 4 }}>
              {testTypes.map(t => (
                <button
                  key={t}
                  onClick={() => setTestType(t)}
                  style={{
                    flex: 1, padding: '9px 0', borderRadius: 7, border: 'none', cursor: 'pointer', fontFamily: 'inherit',
                    fontSize: 13, fontWeight: 700, transition: 'all 0.15s',
                    background: testType === t ? C.navy : 'transparent',
                    color:      testType === t ? '#fff' : C.textSecondary,
                  }}
                >{t}</button>
              ))}
            </div>
            <p style={{ fontSize: 11, color: C.textMuted, marginTop: 6 }}>
              {testType === 'Self-Test'
                ? 'Student-marked check at end of each PACE section.'
                : 'Supervisor-administered test; recorded for the permanent record.'}
            </p>
          </div>

          {/* Score entry + live ring */}
          <div style={{ marginBottom: 16 }}>
            <label style={{ fontSize: 11, fontWeight: 700, color: C.textSecondary, display: 'block', marginBottom: 8, textTransform: 'uppercase', letterSpacing: '0.4px' }}>Score (%)</label>
            <div style={{ display: 'flex', gap: 16, alignItems: 'center' }}>
              {/* Ring */}
              <div style={{ position: 'relative', width: 80, height: 80, flexShrink: 0 }}>
                <svg width={80} height={80} viewBox="0 0 80 80">
                  <circle cx={40} cy={40} r={r} fill="none" stroke={C.border} strokeWidth={7} />
                  <circle
                    cx={40} cy={40} r={r} fill="none"
                    stroke={scoreColor}
                    strokeWidth={7}
                    strokeDasharray={`${ringPct * circ} ${circ}`}
                    strokeDashoffset={circ * 0.25}
                    strokeLinecap="round"
                    style={{ transition: 'stroke-dasharray 0.35s ease, stroke 0.25s ease' }}
                  />
                </svg>
                <div style={{ position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
                  <span style={{ fontSize: validScore ? 18 : 13, fontWeight: 800, color: scoreColor, lineHeight: 1, transition: 'color 0.25s' }}>
                    {validScore ? `${scoreNum}` : '—'}
                  </span>
                  {validScore && <span style={{ fontSize: 9, color: C.textMuted, marginTop: 1 }}>/ 100</span>}
                </div>
              </div>

              {/* Input + label */}
              <div style={{ flex: 1 }}>
                <input
                  type="number"
                  min={0} max={100}
                  value={score}
                  onChange={e => { setScore(e.target.value); setScoreError(''); }}
                  placeholder="0 – 100"
                  style={{
                    width: '100%', padding: '13px 16px',
                    border: `2px solid ${scoreError ? C.danger : validScore ? scoreColor : C.border}`,
                    borderRadius: 10, fontSize: 22, fontWeight: 800, fontFamily: 'inherit',
                    color: validScore ? scoreColor : C.textPrimary,
                    background: validScore ? scoreBg : C.surface,
                    outline: 'none', textAlign: 'center',
                    transition: 'border-color 0.2s, background 0.2s, color 0.2s',
                  }}
                />
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 6 }}>
                  {scoreError
                    ? <p style={{ fontSize: 11, color: C.danger, fontWeight: 600 }}>{scoreError}</p>
                    : <p style={{ fontSize: 12, fontWeight: 600, color: scoreColor }}>{scoreLabel}</p>
                  }
                  {/* Threshold legend */}
                  <div style={{ display: 'flex', gap: 8 }}>
                    {[[C.success,'≥90'],[C.warning,'≥75'],[C.danger,'<75']].map(([col,lbl]) => (
                      <div key={lbl} style={{ display: 'flex', alignItems: 'center', gap: 3 }}>
                        <div style={{ width: 7, height: 7, borderRadius: 2, background: col }} />
                        <span style={{ fontSize: 10, color: C.textMuted }}>{lbl}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Supervisor + Date row */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 16 }}>
            <div>
              <label style={{ fontSize: 11, fontWeight: 700, color: C.textSecondary, display: 'block', marginBottom: 6, textTransform: 'uppercase', letterSpacing: '0.4px' }}>Supervisor</label>
              <select
                value={supervisor}
                onChange={e => setSupervisor(e.target.value)}
                style={{ width: '100%', padding: '10px 12px', border: `1.5px solid ${C.border}`, borderRadius: 9, fontSize: 13, fontFamily: 'inherit', color: C.textPrimary, background: C.surface, outline: 'none', cursor: 'pointer' }}
              >
                {supervisors.map(s => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>
            <div>
              <label style={{ fontSize: 11, fontWeight: 700, color: C.textSecondary, display: 'block', marginBottom: 6, textTransform: 'uppercase', letterSpacing: '0.4px' }}>Date</label>
              <input
                type="date"
                value={date}
                onChange={e => setDate(e.target.value)}
                style={{ width: '100%', padding: '10px 12px', border: `1.5px solid ${C.border}`, borderRadius: 9, fontSize: 13, fontFamily: 'inherit', color: C.textPrimary, background: C.surface, outline: 'none' }}
              />
            </div>
          </div>

          {/* Optional notes */}
          <div style={{ marginBottom: 20 }}>
            <label style={{ fontSize: 11, fontWeight: 700, color: C.textSecondary, display: 'block', marginBottom: 6, textTransform: 'uppercase', letterSpacing: '0.4px' }}>
              Supervisor Note <span style={{ fontWeight: 400, textTransform: 'none', letterSpacing: 0 }}>(optional)</span>
            </label>
            <textarea
              value={notes}
              onChange={e => setNotes(e.target.value)}
              rows={2}
              placeholder="Any observations about this test — e.g. student seemed rushed, re-sit recommended…"
              style={{ width: '100%', padding: '10px 12px', border: `1.5px solid ${C.border}`, borderRadius: 9, fontSize: 13, fontFamily: 'inherit', color: C.textPrimary, resize: 'vertical', outline: 'none', background: C.surface }}
            />
          </div>

          {/* Summary strip */}
          {validScore && (
            <div style={{
              background: C.bg, borderRadius: 10, padding: '12px 16px',
              display: 'flex', gap: 16, flexWrap: 'wrap', marginBottom: 20,
              borderLeft: `4px solid ${scoreColor}`,
            }}>
              {[
                ['Student',   student.name],
                ['Subject',   subject],
                ['PACE #',    paceNumber || '—'],
                ['Type',      testType],
                ['Score',     validScore ? `${scoreNum}%` : '—'],
                ['Date',      date ? new Date(date + 'T00:00:00').toLocaleDateString('en-GB', { day:'numeric', month:'short', year:'numeric' }) : '—'],
              ].map(([label, val]) => (
                <div key={label} style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                  <span style={{ fontSize: 10, fontWeight: 700, color: C.textMuted, textTransform: 'uppercase', letterSpacing: '0.4px' }}>{label}</span>
                  <span style={{ fontSize: 13, fontWeight: 600, color: C.textPrimary }}>{val}</span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* ── Footer ── */}
        <div style={{
          padding: '16px 24px', borderTop: `1px solid ${C.border}`,
          display: 'flex', gap: 10, justifyContent: 'flex-end', flexShrink: 0,
          background: C.surface,
        }}>
          <Btn variant="secondary" onClick={onClose} disabled={saving}>Cancel</Btn>
          <button
            onClick={handleSave}
            disabled={saving || saved || !validScore}
            style={{
              padding: '10px 24px', borderRadius: 8, border: 'none', cursor: (saving || saved || !validScore) ? 'not-allowed' : 'pointer',
              fontFamily: 'inherit', fontSize: 14, fontWeight: 800,
              display: 'flex', alignItems: 'center', gap: 8,
              transition: 'all 0.2s',
              background: saved ? C.success : (!validScore || saving) ? '#9aaabf' : C.crimson,
              color: '#fff',
              opacity: !validScore && !saving ? 0.6 : 1,
            }}
          >
            {saved ? (
              <>
                <svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round"><path d="M20 6L9 17l-5-5"/></svg>
                Saved!
              </>
            ) : saving ? (
              <>
                <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" style={{ animation:'spin 0.8s linear infinite' }}>
                  <path d="M21 12a9 9 0 11-18 0 9 9 0 0118 0"/>
                </svg>
                Saving…
              </>
            ) : (
              <>
                <svg width={15} height={15} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2.2} strokeLinecap="round" strokeLinejoin="round"><path d="M19 21H5a2 2 0 01-2-2V5a2 2 0 012-2h11l5 5v11a2 2 0 01-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg>
                Save Score
              </>
            )}
          </button>
        </div>

        <style>{`
          @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
        `}</style>
      </div>
    </div>
  );
};

// ── Admin PACE ───────────────────────────────────────────────────────────────
const AdminPACE = ({ mobile }) => {
  const [studentId, setStudentId] = React.useState('1');
  const [modal,     setModal]     = React.useState(null); // null | { pace }
  const [scores,    setScores]    = React.useState({}); // overrides keyed by "subject"
  const student = STUDENTS.find(s=>String(s.id)===studentId);

  const handleSave = (data) => {
    setScores(prev => ({ ...prev, [data.subject]: data }));
  };

  const displayScores = PACE_SUBJECTS.map(p => ({
    ...p,
    selfTest: scores[p.subject]?.testType === 'Self-Test' ? scores[p.subject].score : p.selfTest,
    paceTest: scores[p.subject]?.testType === 'PACE Test' ? scores[p.subject].score : p.paceTest,
  }));

  return (
    <div className="page-fade">
      {modal && (
        <PaceUpdateModal
          student={student}
          pace={modal.pace}
          onClose={() => setModal(null)}
          onSave={handleSave}
        />
      )}

      <div style={{ display:'flex', alignItems:'center', gap:14, marginBottom:20, flexWrap:'wrap' }}>
        <h2 style={{ fontSize:mobile?18:22, fontWeight:800, color:C.navy }}>PACE Progress</h2>
        <Select value={studentId} onChange={e=>{ setStudentId(e.target.value); setScores({}); }} options={STUDENTS.map(s=>({value:String(s.id),label:s.name}))} style={{ width:200 }} />
        <Btn variant="primary" size="sm" onClick={() => setModal({ pace: null })}>+ Record New Score</Btn>
      </div>

      <div style={{ display:'flex', alignItems:'center', gap:12, marginBottom:16 }}>
        <Avatar initials={student.initials} size={40} color={student.color} />
        <div>
          <p style={{ fontWeight:700, fontSize:15, color:C.navy }}>{student.name}</p>
          <p style={{ fontSize:12, color:C.textSecondary }}>{student.year} · {student.pacesCompleted} PACEs completed this year</p>
        </div>
      </div>

      <Card padding={0}>
        <table style={{ width:'100%', borderCollapse:'collapse', fontSize:13 }}>
          <thead>
            <tr style={{ background:C.bg }}>
              {['Subject','PACE #','Self-Test','PACE Test','Completed','Status',''].map(h=>(
                <th key={h} style={{ padding:'10px 14px', textAlign:'left', fontSize:11, fontWeight:700, color:C.textSecondary, textTransform:'uppercase', letterSpacing:'0.5px' }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {displayScores.map((p,i)=>{
              const updated = !!scores[p.subject];
              return (
                <tr key={i} style={{ borderTop:`1px solid ${C.border}`, background: updated ? '#FAFFFE' : '' }}>
                  <td style={{ padding:'12px 14px', fontWeight:600, color:C.navy }}>
                    <div style={{ display:'flex', alignItems:'center', gap:6 }}>
                      {p.subject}
                      {updated && <Badge variant="green">Updated</Badge>}
                    </div>
                  </td>
                  <td style={{ padding:'12px 14px', color:C.blue, fontWeight:700 }}>
                    #{scores[p.subject]?.paceNumber || p.paceNumber}
                  </td>
                  <td style={{ padding:'12px 14px', fontWeight:600, color:p.selfTest>=90?C.success:p.selfTest>=75?C.warning:C.danger }}>
                    {p.selfTest}%
                  </td>
                  <td style={{ padding:'12px 14px', fontWeight:600, color:p.paceTest>=90?C.success:p.paceTest>=75?C.warning:C.danger }}>
                    {p.paceTest}%
                  </td>
                  <td style={{ padding:'12px 14px', color:C.textSecondary, fontSize:12 }}>{p.completedAt}</td>
                  <td style={{ padding:'12px 14px' }}>
                    <Badge variant={p.status==='Ahead'?'green':p.status==='On Track'?'blue':'red'}>{p.status}</Badge>
                  </td>
                  <td style={{ padding:'12px 14px' }}>
                    <Btn variant="secondary" size="sm" onClick={() => setModal({ pace: p })}>Update Score</Btn>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </Card>
    </div>
  );
};

// ── Admin Shop ─ Imported from shop.jsx via window.AdminShop

// ── Sidebar Icon SVG helper ──────────────────────────────────────────────────
const NavIcon = ({ path, active }) => (
  <svg width={18} height={18} viewBox="0 0 24 24" fill="none" stroke={active?'#fff':'rgba(255,255,255,0.6)'} strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" style={{ flexShrink:0 }}>
    <path d={path} />
  </svg>
);

// ── Admin Self-Profile ───────────────────────────────────────────────────────
const AdminSelfProfile = ({ mobile }) => {
  const ME = {
    firstName:'Margaret', lastName:'Thompson', initials:'MT',
    role:'Head of Centre', email:'head@oasis.school', phone:'07700 900123',
    address:'14 Elm Grove, Birmingham, B12 4PQ', dob:'1974-06-15',
    startDate:'2019-09-01', qualifications:'BA Education (Hons), PGCE, ACE Certified Supervisor',
    tags:['leaderboard-admin'], twoFA:true, status:'Active',
    subjects:['Mathematics','English','Bible'],
  };
  const [editing, setEditing] = React.useState(false);
  const [form, setForm]       = React.useState({ ...ME });
  const [saved, setSaved]     = React.useState(false);
  const [tab, setTab]         = React.useState('account');
  const set = (k,v) => setForm(f=>({...f,[k]:v}));
  const handleSave = () => { setSaved(true); setEditing(false); setTimeout(()=>setSaved(false),3000); };

  const FRow = ({ label, value, editKey, type='text', readOnly }) => (
    <div style={{ display:'grid', gridTemplateColumns: mobile?'1fr':'150px 1fr', gap: mobile?4:12, padding:'11px 0', borderBottom:`1px solid ${C.borderLight}`, alignItems: mobile?'flex-start':'center' }}>
      <p style={{ fontSize:11, fontWeight:700, color:C.textSecondary, textTransform:'uppercase', letterSpacing:'0.4px' }}>{label}</p>
      {editing && !readOnly
        ? <input type={type} value={form[editKey]||''} onChange={e=>set(editKey,e.target.value)}
            style={{ padding:'8px 10px', border:`1.5px solid ${C.border}`, borderRadius:7, fontSize:13, fontFamily:'inherit', color:C.textPrimary, outline:'none', width:'100%' }} />
        : <p style={{ fontSize:13, color: value?C.textPrimary:C.textMuted, fontStyle:value?'normal':'italic' }}>{value||'Not set'}</p>
      }
    </div>
  );

  const Toggle = ({ label, desc, val, onChange }) => (
    <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', padding:'12px 0', borderBottom:`1px solid ${C.borderLight}`, gap:12 }}>
      <div>
        <p style={{ fontSize:13, fontWeight:600, color:C.textPrimary }}>{label}</p>
        {desc && <p style={{ fontSize:11, color:C.textMuted, marginTop:2 }}>{desc}</p>}
      </div>
      <div style={{ width:40, height:22, borderRadius:11, background:val?C.success:C.border, position:'relative', flexShrink:0 }}>
        <div style={{ width:16, height:16, borderRadius:'50%', background:'#fff', position:'absolute', top:3, left:val?21:3, transition:'left 0.2s', boxShadow:'0 1px 3px rgba(0,0,0,0.2)' }} />
      </div>
    </div>
  );

  const tabs = [['account','My Account'],['role','Role & Access'],['security','Security']];

  return (
    <div className="page-fade">
      {/* Hero */}
      <Card style={{ background:`linear-gradient(130deg, ${C.navy} 0%, ${C.navyLight} 100%)`, border:'none', marginBottom:20 }} padding={mobile?16:24}>
        <div style={{ display:'flex', alignItems:'center', gap:16, flexWrap:'wrap' }}>
          <div style={{ position:'relative' }}>
            <Avatar initials="MT" size={mobile?48:60} color="rgba(255,255,255,0.18)" />
            {editing && <div style={{ position:'absolute', inset:0, borderRadius:'50%', background:'rgba(0,0,0,0.3)', display:'flex', alignItems:'center', justifyContent:'center', cursor:'pointer' }}><span style={{ fontSize:9, color:'#fff', fontWeight:700 }}>CHANGE</span></div>}
          </div>
          <div style={{ flex:1 }}>
            <p style={{ fontSize:mobile?18:22, fontWeight:800, color:'#fff', margin:0 }}>{form.firstName} {form.lastName}</p>
            <p style={{ fontSize:13, color:'rgba(255,255,255,0.65)', marginTop:3 }}>{form.role} · Oasis Learning Centre</p>
            <div style={{ display:'flex', gap:8, marginTop:10, flexWrap:'wrap' }}>
              <div style={{ background:'rgba(255,255,255,0.12)', borderRadius:6, padding:'4px 10px', fontSize:11, color:'rgba(255,255,255,0.9)', fontWeight:600 }}>Since {new Date(ME.startDate).toLocaleDateString('en-GB',{month:'short',year:'numeric'})}</div>
              {form.twoFA && <div style={{ background:'rgba(255,255,255,0.12)', borderRadius:6, padding:'4px 10px', fontSize:11, color:'rgba(255,255,255,0.9)', fontWeight:600 }}>🔒 2FA Active</div>}
              {(form.tags||[]).map(t=>(<div key={t} style={{ background:'rgba(255,255,255,0.12)', borderRadius:6, padding:'4px 10px', fontSize:11, color:'rgba(255,255,255,0.9)', fontWeight:600 }}>{{  'leaderboard-admin':'Leaderboard Admin','shopkeeper':'Shopkeeper','shopadmin':'Shop Admin'}[t]||t}</div>))}
            </div>
          </div>
          <div style={{ display:'flex', flexDirection:'column', gap:8, alignItems:'flex-end' }}>
            {!editing
              ? <button onClick={()=>setEditing(true)} style={{ padding:'8px 16px', background:'rgba(255,255,255,0.15)', border:'1.5px solid rgba(255,255,255,0.25)', borderRadius:8, color:'#fff', fontSize:12, fontWeight:700, cursor:'pointer', fontFamily:'inherit' }}>Edit Profile</button>
              : <div style={{ display:'flex', gap:8 }}>
                  <button onClick={()=>{ setForm({...ME}); setEditing(false); }} style={{ padding:'8px 14px', background:'rgba(255,255,255,0.1)', border:'1.5px solid rgba(255,255,255,0.2)', borderRadius:8, color:'rgba(255,255,255,0.8)', fontSize:12, fontWeight:700, cursor:'pointer', fontFamily:'inherit' }}>Cancel</button>
                  <button onClick={handleSave} style={{ padding:'8px 14px', background:C.success, border:'none', borderRadius:8, color:'#fff', fontSize:12, fontWeight:700, cursor:'pointer', fontFamily:'inherit' }}>Save</button>
                </div>
            }
            {saved && <span style={{ fontSize:11, color:'rgba(255,255,255,0.8)', fontWeight:600 }}>✓ Saved</span>}
          </div>
        </div>
      </Card>

      {/* Tabs */}
      <div style={{ display:'flex', gap:2, marginBottom:20, background:C.bg, borderRadius:10, padding:4, width:'fit-content' }}>
        {tabs.map(([id,label])=>(
          <button key={id} onClick={()=>setTab(id)} style={{ padding:'8px 18px', borderRadius:7, border:'none', cursor:'pointer', fontFamily:'inherit', fontWeight:600, fontSize:12, transition:'all 0.15s',
            background: tab===id ? C.navy : 'transparent', color: tab===id ? '#fff' : C.textSecondary }}>{label}</button>
        ))}
      </div>

      {/* My Account */}
      {tab==='account' && (
        <Card padding={16}>
          <FRow label="First name"      value={form.firstName}      editKey="firstName" />
          <FRow label="Last name"       value={form.lastName}       editKey="lastName" />
          <FRow label="Email"           value={form.email}          editKey="email"    type="email" />
          <FRow label="Phone"           value={form.phone}          editKey="phone"    type="tel" />
          <FRow label="Address"         value={form.address}        editKey="address" />
          <FRow label="Date of birth"   value={new Date(form.dob).toLocaleDateString('en-GB',{day:'numeric',month:'long',year:'numeric'})} readOnly />
          <FRow label="Qualifications"  value={form.qualifications} editKey="qualifications" />
          <FRow label="Start date"      value={new Date(form.startDate).toLocaleDateString('en-GB',{day:'numeric',month:'long',year:'numeric'})} readOnly />
        </Card>
      )}

      {/* Role & Access */}
      {tab==='role' && (
        <div style={{ display:'flex', flexDirection:'column', gap:14 }}>
          <Card padding={16}>
            <FRow label="Role"    value={form.role}   readOnly />
            <FRow label="Status"  value={form.status} readOnly />
            <div style={{ padding:'11px 0', borderBottom:`1px solid ${C.borderLight}` }}>
              <p style={{ fontSize:11, fontWeight:700, color:C.textSecondary, textTransform:'uppercase', letterSpacing:'0.4px', marginBottom:8 }}>Supervised subjects</p>
              <div style={{ display:'flex', flexWrap:'wrap', gap:6 }}>
                {(form.subjects||[]).map(s=><Badge key={s} variant="blue">{s}</Badge>)}
              </div>
            </div>
            <div style={{ padding:'11px 0' }}>
              <p style={{ fontSize:11, fontWeight:700, color:C.textSecondary, textTransform:'uppercase', letterSpacing:'0.4px', marginBottom:8 }}>Permission tags</p>
              <div style={{ display:'flex', flexWrap:'wrap', gap:6 }}>
                {(form.tags||[]).length > 0
                  ? (form.tags||[]).map(t=><Badge key={t} variant="navy">{{ 'leaderboard-admin':'Leaderboard Admin','shopkeeper':'Shopkeeper','shopadmin':'Shop Admin'}[t]||t}</Badge>)
                  : <span style={{ fontSize:13, color:C.textMuted, fontStyle:'italic' }}>No special tags</span>
                }
              </div>
              <p style={{ fontSize:11, color:C.textMuted, marginTop:8 }}>Tags are managed by the Head of Centre and cannot be self-edited.</p>
            </div>
          </Card>
        </div>
      )}

      {/* Security */}
      {tab==='security' && (
        <div style={{ display:'flex', flexDirection:'column', gap:14 }}>
          <Card padding={16}>
            <p style={{ fontSize:13, fontWeight:700, color:C.navy, marginBottom:14 }}>Account Security</p>
            <Toggle label="Two-factor authentication (2FA)" desc="Required for all staff accounts. Managed via authenticator app." val={form.twoFA} onChange={()=>{}} />
            <div style={{ padding:'12px 0', borderBottom:`1px solid ${C.borderLight}` }}>
              <p style={{ fontSize:12, fontWeight:700, color:C.navy }}>Last sign-in</p>
              <p style={{ fontSize:13, color:C.textSecondary, marginTop:3 }}>Today, 08:47 · Birmingham, UK</p>
            </div>
            <div style={{ padding:'12px 0' }}>
              <p style={{ fontSize:12, fontWeight:700, color:C.navy }}>Account email</p>
              <p style={{ fontSize:13, color:C.textSecondary, marginTop:3 }}>{form.email}</p>
            </div>
          </Card>
          <Card padding={16}>
            <p style={{ fontSize:13, fontWeight:700, color:C.navy, marginBottom:12 }}>Password & Access</p>
            <div style={{ display:'flex', gap:8, flexWrap:'wrap' }}>
              <button style={{ padding:'9px 16px', background:C.bg, border:`1.5px solid ${C.border}`, borderRadius:8, fontSize:12, fontWeight:700, color:C.navy, cursor:'pointer', fontFamily:'inherit' }}>Change Password</button>
              <button style={{ padding:'9px 16px', background:C.dangerBg, border:`1.5px solid ${C.dangerMid}`, borderRadius:8, fontSize:12, fontWeight:700, color:C.danger, cursor:'pointer', fontFamily:'inherit' }}>Sign Out of All Devices</button>
            </div>
          </Card>
        </div>
      )}
    </div>
  );
};

// ── Admin Profile Badge (sidebar) ─────────────────────────────────────────────
const AdminProfileBadge = ({ onClick, active }) => (
  <button onClick={onClick} style={{
    width: '100%', display: 'flex', alignItems: 'center', gap: 10,
    padding: '10px 12px', background: active ? 'rgba(255,255,255,0.15)' : 'rgba(255,255,255,0.06)',
    border: `1.5px solid ${active ? 'rgba(255,255,255,0.3)' : 'rgba(255,255,255,0.1)'}`,
    borderRadius: 10, cursor: 'pointer', fontFamily: 'inherit', transition: 'all 0.15s', marginBottom: 8,
  }}>
    <Avatar initials="MT" size={32} color={active ? C.blue : 'rgba(255,255,255,0.15)'} />
    <div style={{ flex: 1, textAlign: 'left' }}>
      <p style={{ fontSize: 12, fontWeight: 700, color: '#fff', margin: 0 }}>Mrs Thompson</p>
      <p style={{ fontSize: 10, color: 'rgba(255,255,255,0.5)', margin: 0 }}>Head of Centre · My Profile</p>
    </div>
    <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.4)" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
      <path d="M9 5l7 7-7 7" />
    </svg>
  </button>
);

// ── Admin Portal Shell ───────────────────────────────────────────────────────
const AdminPortal = ({ onLogout, mobileMode }) => {
  const [page, setPage] = React.useState('slips');
  const [showOwnProfile, setShowOwnProfile] = React.useState(false);

  const pages = { dashboard:AdminDashboard, students:AdminStudents, attendance:AdminAttendance, behaviour:AdminBehaviour, pace:AdminPACE, shop:window.AdminShop, leaderboard:AdminLeaderboard, slips:window.AdminPermissionSlips, reports:AdminReports, fees:window.AdminFees, messages:AdminMessages, noticeboard:AdminNoticeboard, snapshot:StudentSnapshot, profiles:ProfilePage, audit:AdminAuditLog };
  const PageComp = pages[page] || AdminDashboard;
  const mainContent = (mobile) => showOwnProfile
    ? <AdminSelfProfile mobile={mobile} />
    : <PageComp mobile={mobile} />;

  if (mobileMode) {
    const mobileNavItems = ADMIN_NAV.filter(n=>MOBILE_NAV.includes(n.id));
    return (
      <div style={{ display:'flex', flexDirection:'column', height:'100%', background:C.bg, overflow:'hidden' }}>
        {/* Mobile header */}
        <div style={{ background:C.navy, padding:'12px 16px', display:'flex', alignItems:'center', justifyContent:'space-between', flexShrink:0 }}>
          <div style={{ display:'flex', alignItems:'center', gap:10 }}>
            <img src="assets/oasis-logo.png" alt="Oasis" style={{ height:28, filter:'brightness(0) invert(1)' }} />
            <div>
              <p style={{ fontSize:11, color:'rgba(255,255,255,0.7)', margin:0 }}>Staff Portal</p>
            </div>
          </div>
          <div style={{ display:'flex', gap:8, alignItems:'center' }}>
            <button onClick={()=>setShowOwnProfile(s=>!s)} style={{ display:'flex', alignItems:'center', gap:7, background: showOwnProfile?'rgba(255,255,255,0.2)':'rgba(255,255,255,0.1)', border:'1.5px solid rgba(255,255,255,0.2)', borderRadius:8, padding:'5px 10px', cursor:'pointer', fontFamily:'inherit' }}>
              <Avatar initials="MT" size={22} color="rgba(255,255,255,0.2)" />
              <span style={{ fontSize:11, fontWeight:700, color:'#fff' }}>{showOwnProfile?'Close':'My Profile'}</span>
            </button>
            <button onClick={onLogout} style={{ background:'rgba(255,255,255,0.1)', border:'none', borderRadius:6, padding:'6px 10px', color:'#fff', fontSize:11, fontWeight:600, cursor:'pointer', fontFamily:'inherit' }}>Out</button>
          </div>
        </div>
        {/* Content */}
        <div style={{ flex:1, overflowY:'auto', padding:14 }}>
          {mainContent(true)}
        </div>
        {/* Bottom nav */}
        <div style={{ background:C.navy, display:'flex', flexShrink:0, borderTop:`1px solid ${C.navyLight}` }}>
          {mobileNavItems.map(n=>(
            <button key={n.id} onClick={()=>setPage(n.id)} style={{ flex:1, padding:'10px 4px 8px', border:'none', background:'none', cursor:'pointer', display:'flex', flexDirection:'column', alignItems:'center', gap:3 }}>
              <NavIcon path={n.icon} active={page===n.id} />
              <span style={{ fontSize:9, color:page===n.id?'#fff':'rgba(255,255,255,0.5)', fontWeight:600, fontFamily:'inherit' }}>{n.label}</span>
              {n.badge && <div style={{ position:'absolute', background:C.crimson, color:'#fff', fontSize:8, fontWeight:700, borderRadius:10, padding:'1px 4px', marginTop:-24, marginLeft:8 }}>{n.badge}</div>}
            </button>
          ))}
        </div>
      </div>
    );
  }

  // Desktop layout
  return (
    <div style={{ display:'flex', height:'100vh', background:C.bg, overflow:'hidden' }}>
      {/* Sidebar */}
      <div style={{ width:220, background:C.navy, display:'flex', flexDirection:'column', flexShrink:0, overflowY:'auto' }}>
        <div style={{ padding:'20px 16px 14px', borderBottom:'1px solid rgba(255,255,255,0.08)' }}>
          <img src="assets/oasis-logo.png" alt="Oasis" style={{ height:40, display:'block', margin:'0 auto 10px', filter:'brightness(0) invert(1)' }} />
          <p style={{ fontSize:10, color:'rgba(255,255,255,0.4)', margin:'0 0 10px', letterSpacing:'0.5px', textTransform:'uppercase', textAlign:'center' }}>Staff Portal</p>
          <AdminProfileBadge onClick={() => setShowOwnProfile(s=>!s)} active={showOwnProfile} />
        </div>
        <nav style={{ flex:1, padding:'12px 8px' }}>
          {ADMIN_NAV.map((n,idx)=>{
            const isActive = page===n.id;
            const isHighlight = n.highlight;
            return (
              <React.Fragment key={n.id}>
                {isHighlight && <div style={{ height:1, background:'rgba(255,255,255,0.08)', margin:'8px 4px 10px' }} />}
                <button onClick={()=>setPage(n.id)} style={{ width:'100%', display:'flex', alignItems:'center', gap:10, padding:'9px 10px', borderRadius:8, border:'none', background: isActive ? 'rgba(255,255,255,0.12)' : isHighlight ? 'rgba(91,144,197,0.12)' : 'transparent', cursor:'pointer', marginBottom:2, position:'relative', borderLeft: isActive ? `3px solid ${C.blue}` : isHighlight ? `3px solid rgba(91,144,197,0.4)` : '3px solid transparent', fontFamily:'inherit' }}>
                  <NavIcon path={n.icon} active={isActive} />
                  <span style={{ fontSize:13, fontWeight: isActive ? 700 : 500, color: isActive ? '#fff' : isHighlight ? 'rgba(255,255,255,0.85)' : 'rgba(255,255,255,0.65)' }}>{n.label}</span>
                  {n.badge && <span style={{ marginLeft:'auto', background:C.crimson, color:'#fff', fontSize:10, fontWeight:700, borderRadius:10, padding:'1px 6px' }}>{n.badge}</span>}
                  {isHighlight && !isActive && <span style={{ marginLeft:'auto', background:'rgba(91,144,197,0.25)', color:'rgba(255,255,255,0.7)', fontSize:9, fontWeight:700, borderRadius:6, padding:'2px 6px', letterSpacing:'0.3px' }}>NEW</span>}
                </button>
              </React.Fragment>
            );
          })}
        </nav>
        <div style={{ padding:'12px 16px', borderTop:'1px solid rgba(255,255,255,0.08)' }}>
          <button onClick={onLogout} style={{ width:'100%', padding:'9px', background:'rgba(255,255,255,0.08)', border:'none', borderRadius:8, color:'rgba(255,255,255,0.7)', fontSize:12, fontWeight:600, cursor:'pointer', fontFamily:'inherit' }}>Sign out</button>
        </div>
      </div>
      {/* Main content */}
      <div style={{ flex:1, overflowY:'auto', padding:'28px 32px' }}>
        {mainContent(false)}
      </div>
    </div>
  );
};

Object.assign(window, { AdminPortal, AdminProfileBadge, AdminSelfProfile });
