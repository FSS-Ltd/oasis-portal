// shared-data.jsx — Mock data + shared UI primitives

const C = {
  navy: '#1B2B5E',
  navyMid: '#243570',
  navyLight: '#2D3F72',
  blue: '#5B90C5',
  blueLight: '#D4E5F5',
  blueMid: '#A8C8E8',
  crimson: '#7D1C2C',
  crimsonLight: '#FCE8EA',
  bg: '#EEF2F9',
  surface: '#FFFFFF',
  border: '#DDE3F0',
  borderLight: '#EEF2F9',
  textPrimary: '#1B2B5E',
  textSecondary: '#5A6A8A',
  textMuted: '#8899BB',
  success: '#166534',
  successBg: '#DCFCE7',
  successMid: '#86EFAC',
  warning: '#92400E',
  warningBg: '#FEF3C7',
  danger: '#991B1B',
  dangerBg: '#FEE2E2',
  dangerMid: '#FCA5A5',
};

const STUDENTS = [
  { id: 1, name: 'Joshua Johnson',  initials: 'JJ', year: 'Y9',  tutor: 'Mrs Thompson', merits: { spend: 142, saving: 80,  investment: 95  }, tithe: 10, pacesCompleted: 8,  color: '#5B90C5' },
  { id: 2, name: 'Grace Williams',  initials: 'GW', year: 'Y8',  tutor: 'Mrs Thompson', merits: { spend: 238, saving: 150, investment: 200 }, tithe: 15, pacesCompleted: 12, color: '#7D3C98' },
  { id: 3, name: 'Samuel Okafor',   initials: 'SO', year: 'Y10', tutor: 'Mr Osei',      merits: { spend: 56,  saving: 20,  investment: 10  }, tithe: 10, pacesCompleted: 6,  color: '#1A7A4A' },
  { id: 4, name: 'Ruth Chen',       initials: 'RC', year: 'Y7',  tutor: 'Mrs Thompson', merits: { spend: 189, saving: 100, investment: 145 }, tithe: 20, pacesCompleted: 10, color: '#B45309' },
  { id: 5, name: 'Daniel Patel',    initials: 'DP', year: 'Y9',  tutor: 'Mr Osei',      merits: { spend: 67,  saving: 40,  investment: 0   }, tithe: 10, pacesCompleted: 7,  color: '#7D1C2C' },
  { id: 6, name: 'Esther Brown',    initials: 'EB', year: 'Y8',  tutor: 'Mrs Thompson', merits: { spend: 312, saving: 200, investment: 280 }, tithe: 15, pacesCompleted: 14, color: '#0E7490' },
  { id: 7, name: 'Caleb Smith',     initials: 'CS', year: 'Y10', tutor: 'Mr Osei',      merits: { spend: 94,  saving: 60,  investment: 45  }, tithe: 10, pacesCompleted: 9,  color: '#4338CA' },
  { id: 8, name: 'Hannah Davies',   initials: 'HD', year: 'Y7',  tutor: 'Mrs Thompson', merits: { spend: 175, saving: 120, investment: 160 }, tithe: 15, pacesCompleted: 11, color: '#BE185D' },
  { id: 9, name: 'Joseph Taylor',   initials: 'JT', year: 'Y9',  tutor: 'Mr Osei',      merits: { spend: 43,  saving: 15,  investment: 0   }, tithe: 10, pacesCompleted: 5,  color: '#065F46' },
  { id: 10,name: 'Faith Mensah',    initials: 'FM', year: 'Y8',  tutor: 'Mrs Thompson', merits: { spend: 267, saving: 180, investment: 220 }, tithe: 20, pacesCompleted: 13, color: '#9A3412' },
];

const ATTENDANCE_TODAY = { 1:'Present',2:'Present',3:'Absent',4:'Present',5:'Late',6:'Present',7:'Present',8:'Present',9:'Absent',10:'Present' };

const BEHAVIOUR_ENTRIES = [
  { id:1, studentId:2, studentName:'Grace Williams',  type:'Merit',   category:'Scripture Memory',    note:'Memorised Psalm 23 in full, word-perfect recitation',       delta:+10, visibility:'General',   recordedBy:'Mrs Thompson', time:'09:15' },
  { id:2, studentId:5, studentName:'Daniel Patel',    type:'Demerit', category:'Punctuality',          note:'Late to Morning Assembly without prior notification',        delta:-5,  visibility:'General',   recordedBy:'Mr Osei',      time:'09:02' },
  { id:3, studentId:6, studentName:'Esther Brown',    type:'Merit',   category:'Academic Excellence',  note:'Scored 95% on PACE 1097 Mathematics test',                  delta:+15, visibility:'General',   recordedBy:'Mrs Thompson', time:'10:45' },
  { id:4, studentId:1, studentName:'Joshua Johnson',  type:'Merit',   category:'Helpfulness',          note:'Assisted younger students during self-study session',        delta:+5,  visibility:'General',   recordedBy:'Mrs Thompson', time:'11:20' },
  { id:5, studentId:9, studentName:'Joseph Taylor',   type:'Demerit', category:'Conduct',              note:'Disruptive behaviour during quiet study period',             delta:-5,  visibility:'Sensitive', recordedBy:'Mr Osei',      time:'13:15' },
  { id:6, studentId:4, studentName:'Ruth Chen',       type:'Merit',   category:'Character',            note:'Displayed exceptional kindness and patience with a peer',   delta:+10, visibility:'General',   recordedBy:'Mrs Thompson', time:'14:00' },
];

const PACE_SUBJECTS = [
  { subject:'Mathematics',    paceNumber:1097, selfTest:88, paceTest:85, completedAt:'12 Apr',  status:'On Track' },
  { subject:'English',        paceNumber:1089, selfTest:92, paceTest:90, completedAt:'08 Apr',  status:'On Track' },
  { subject:'Bible',          paceNumber:1094, selfTest:100,paceTest:98, completedAt:'19 Apr',  status:'Ahead'    },
  { subject:'Science',        paceNumber:1086, selfTest:79, paceTest:76, completedAt:'03 Apr',  status:'On Track' },
  { subject:'Social Studies', paceNumber:1091, selfTest:85, paceTest:83, completedAt:'15 Apr',  status:'On Track' },
];

const MESSAGES = [
  { id:1, from:'Mrs Johnson',  role:'Parent of Joshua Johnson',  preview:"Quick question about Joshua's PACE 1097 algebra section — anything we can do at home?", time:'10:23', unread:true,  body:"Thank you for the update on Joshua's progress. I had a quick question about his PACE 1097 — is there anything we can do at home to support him? He's been finding the algebra section a bit challenging. We try to go over his notes in the evenings but would welcome any suggestions from you." },
  { id:2, from:'Mr Williams',  role:'Parent of Grace Williams',  preview:"Grace has a dentist appointment Thursday 28th — she will be ~30 mins late.", time:'Yesterday', unread:true,  body:"Grace has a dentist appointment on Thursday 28th April so she will arrive approximately 30 minutes late. I've already noted it on the absence form. Please let me know if you need anything else from my end." },
  { id:3, from:'Mrs Okafor',   role:'Parent of Samuel Okafor',   preview:"Wanted to discuss Samuel's recent behaviour entry when you have a moment.", time:'Mon', unread:false, body:"I wanted to discuss Samuel's recent behaviour entry with you when you have a moment. He mentioned feeling frustrated in the classroom and I think a conversation between all of us could help resolve things positively." },
];

const SHOP_ITEMS = [
  { id:1, name:'Stationery Pack',             price:50,  stock:12, active:true  },
  { id:2, name:'Book Token',                  price:100, stock:8,  active:true  },
  { id:3, name:'Hot Chocolate',               price:25,  stock:20, active:true  },
  { id:4, name:'Praise Postcard Home',        price:10,  stock:50, active:true  },
  { id:5, name:'Extra Break Time (15 min)',   price:75,  stock:5,  active:true  },
  { id:6, name:'Oasis Branded Hoodie',        price:300, stock:3,  active:false },
];

const CLUBS = [
  { id:1, name:'Drama Club',      day:'Tuesday',   time:'3:00–4:00pm', capacity:12, enrolled:8  },
  { id:2, name:'Chess Club',      day:'Wednesday', time:'1:00–2:00pm', capacity:10, enrolled:6  },
  { id:3, name:'Art & Craft',     day:'Thursday',  time:'2:00–3:30pm', capacity:15, enrolled:11 },
  { id:4, name:'Scripture Union', day:'Friday',    time:'8:30–9:00am', capacity:30, enrolled:16 },
];

const NOTICES = [
  { id:1, title:'End-of-Term Reports — Deadline Reminder', body:'Please ensure all PACE scores and behaviour summaries are entered by Friday 9 May so reports can be compiled over the weekend.', author:'Mrs Thompson', posted:'25 Apr', readCount:6, totalStaff:8 },
  { id:2, title:'Merit Shop Opens — Spring Term', body:'The Merit Shop will open on Monday 28 April. Shopkeepers please ensure stock levels are updated in the system before then.', author:'Mrs Thompson', posted:'23 Apr', readCount:8, totalStaff:8 },
  { id:3, title:'Staff Training Day — 2 May', body:'There will be a staff training morning on Friday 2 May, 8:00–10:30am. Students arrive at the usual time of 9:00am.', author:'Mr Osei', posted:'20 Apr', readCount:7, totalStaff:8 },
];

// ── Shared UI Components ─────────────────────────────────────────────────────

const Avatar = ({ initials, size = 36, color }) => (
  <div style={{
    width: size, height: size, borderRadius: '50%',
    background: color || C.navy, color: '#fff', flexShrink: 0,
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    fontSize: size * 0.33, fontWeight: 700, letterSpacing: '-0.5px', userSelect: 'none',
  }}>{initials}</div>
);

const Badge = ({ children, variant = 'blue' }) => {
  const v = { blue:{bg:C.blueLight,c:C.navy}, crimson:{bg:C.crimsonLight,c:C.crimson}, green:{bg:C.successBg,c:C.success}, amber:{bg:C.warningBg,c:C.warning}, red:{bg:C.dangerBg,c:C.danger}, grey:{bg:'#F1F5F9',c:C.textSecondary} };
  const s = v[variant] || v.blue;
  return <span style={{ display:'inline-flex', alignItems:'center', padding:'3px 10px', borderRadius:20, fontSize:11, fontWeight:700, background:s.bg, color:s.c, whiteSpace:'nowrap', letterSpacing:'0.2px' }}>{children}</span>;
};

const Btn = ({ children, onClick, variant = 'primary', size = 'md', style: xs, disabled }) => {
  const [h, setH] = React.useState(false);
  const vs = { primary:{bg:h?'#9B2235':C.crimson,c:'#fff',border:'none'}, secondary:{bg:h?C.bg:C.surface,c:C.navy,border:`1.5px solid ${C.border}`}, ghost:{bg:h?C.bg:'transparent',c:C.navy,border:'none'}, navy:{bg:h?C.navyLight:C.navy,c:'#fff',border:'none'}, blue:{bg:h?'#4A7DB5':C.blue,c:'#fff',border:'none'} };
  const ss = { sm:{p:'5px 12px',fs:12}, md:{p:'9px 18px',fs:13}, lg:{p:'12px 24px',fs:15} };
  const sv = vs[variant] || vs.primary; const sz = ss[size] || ss.md;
  return <button onClick={onClick} disabled={disabled} onMouseEnter={()=>setH(true)} onMouseLeave={()=>setH(false)} style={{ padding:sz.p, fontSize:sz.fs, background:sv.bg, color:sv.c, border:sv.border, borderRadius:8, fontWeight:600, cursor:disabled?'not-allowed':'pointer', fontFamily:'inherit', transition:'all 0.15s', display:'inline-flex', alignItems:'center', gap:6, opacity:disabled?0.5:1, ...xs }}>{children}</button>;
};

const Card = ({ children, style: xs, padding = 20 }) => (
  <div style={{ background:C.surface, borderRadius:12, padding, boxShadow:'0 1px 3px rgba(0,0,0,0.06)', border:`1px solid ${C.border}`, ...xs }}>{children}</div>
);

const StatCard = ({ label, value, sub, accent, icon }) => (
  <Card style={{ borderTop:`3px solid ${accent || C.blue}` }}>
    <p style={{ fontSize:11, fontWeight:700, color:C.textSecondary, textTransform:'uppercase', letterSpacing:'0.6px', marginBottom:8 }}>{label}</p>
    <p style={{ fontSize:30, fontWeight:800, color:accent || C.navy, lineHeight:1 }}>{value}</p>
    {sub && <p style={{ fontSize:12, color:C.textMuted, marginTop:6 }}>{sub}</p>}
  </Card>
);

const Divider = ({ style: xs }) => <div style={{ height:1, background:C.border, ...xs }} />;

const Input = ({ label, value, onChange, placeholder, type='text', style: xs }) => (
  <div style={{ ...xs }}>
    {label && <label style={{ fontSize:12, fontWeight:600, color:C.textSecondary, display:'block', marginBottom:5 }}>{label}</label>}
    <input value={value} onChange={onChange} placeholder={placeholder} type={type} style={{ width:'100%', padding:'9px 12px', border:`1.5px solid ${C.border}`, borderRadius:8, fontSize:13, fontFamily:'inherit', color:C.textPrimary, outline:'none', background:C.surface }} />
  </div>
);

const Select = ({ label, value, onChange, options, style: xs }) => (
  <div style={{ ...xs }}>
    {label && <label style={{ fontSize:12, fontWeight:600, color:C.textSecondary, display:'block', marginBottom:5 }}>{label}</label>}
    <select value={value} onChange={onChange} style={{ width:'100%', padding:'9px 12px', border:`1.5px solid ${C.border}`, borderRadius:8, fontSize:13, fontFamily:'inherit', color:C.textPrimary, background:C.surface, outline:'none' }}>
      {options.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
    </select>
  </div>
);

Object.assign(window, {
  C, STUDENTS, ATTENDANCE_TODAY, BEHAVIOUR_ENTRIES, PACE_SUBJECTS, MESSAGES, SHOP_ITEMS, CLUBS, NOTICES,
  Avatar, Badge, Btn, Card, StatCard, Divider, Input, Select,
});
